# Changelog

## 2.1.0 – universal local desktop agent (Stage 1)
Everything from 2.0.0 is kept. New:

- **New interface**: collapsible icon sidebar (New Chat, Chat History, AI Models, Applications, Tools, Files and Folders, Project Workspace, Task History, Image Generation, Settings), tooltips, quick-action toolbar next to the composer, local/offline model badge. Own bundled SVG icon set; all emoji replaced.
- **Applications**: launcher panel (VS Code, Chrome / default browser, File Explorer, PowerShell and Windows Terminal, your own apps). Click an icon or type "Open VS Code".
- **Connector framework** (`src/core/connectors`): discover, validate, execute, observe, verify, cancel. Every action is checked against Settings -> Permissions and authorized folders and is recorded in Task History with an honest result: verified / unverified / failed.
- **Approved command runner**: fixed allowlist (git status/branch/log/diff-stat, python/node/npm version, npm test, pytest/unittest). No shell, working folder must be authorized, timeout, 200 KB output limit, cancel, history. Running tests always asks first.
- **Natural-language control**: rule-based commands in chat; `/do ...` asks the local model for a proposal that you approve before anything runs. Cloud models are refused for this.
- **Shells**: PowerShell / Windows Terminal open only from the launcher icon, in a folder you granted. Chat and the AI cannot open them.
- **Tools** page (7 groups with Available / Not Installed / Needs Permission / Unavailable badges), **AI Models** page (text / vision / embedding), **Project Workspace**, **Task History**.
- Saving an edited file now reads it back and verifies it.
- Security: webview attach blocked, unwritable settings keys for projects/custom apps, IPC channel tests.
- Build: Windows installer `Tachyon-Setup-<version>-<arch>.exe` and portable `Tachyon-Portable-<version>-<arch>.exe` no longer share one file name; hardened workflow (blocking tests, `npm ci --ignore-scripts`, installer verification, smoke test).
- Not in this stage: planner extension, VS Code companion extension, browser page automation, screenshot understanding, folder indexing, NOVA features (/ask, /bigcsv, ComfyUI).

## 2.0.0 – the assistant that does things
Everything from 1.3.1 still works the same way; this release adds:

**Voice, offline**
- 🎤 push-to-talk (also Ctrl+M, and Ctrl+Shift+Space from anywhere), answers to spoken questions read aloud, optional “Hey Tachyon” wake phrase (or your own).
- Speech recognized on the computer with Vosk (vosk-browser 0.0.8, WebAssembly). Settings → Voice: download English (US), English (India) or Hindi once,
  or import any Vosk model .zip / .tar.gz. The recognizer runs in its own frame; the main window keeps its strict security policy.
- Voice and speed choice for read-aloud; the microphone is only granted to Tachyon's own window, audio only.

**Computer control**
- Reminders (“remind me in 20 minutes / tomorrow at 9am / at 5 pm to …”, list, cancel), desktop notifications, missed ones shown at start.
- Open apps from the Start menu; shells, script hosts, WSL and admin tools are always blocked.
- Window control on Windows: switch to, minimize, maximize, restore, show desktop, list windows (the window name is passed safely, never as script text).
- “find files named … / containing …” in the chat, with Attach, Open and Show.

**Multi-step tasks**
- `/task …` or any chained request → a plan you review → Run → per-step results → Undo for the whole task. 14 safe step types; no delete.
- Every step is checked against Settings → Permissions; only plans Tachyon showed you can run.

**Skills**
- “create a skill that …” → draft, automatic tests, preview, Install. `/command text` to use, `/skills` to list.
- Versions kept with Roll back; switch off; delete. Code skills run in a sandbox with no Node, no Tachyon API, no network and a 5-second limit.

**Safety and memory** (first shipped in this release)
- Settings → Permissions: Allow / Ask / Never per action type (files read/edit/create/move/open, cloud uploads, apps, windows, reminders, skills); delete and send always ask.
- Settings → Activity log of every action and AI request; Settings → Memory with “remember / forget / what do you remember about me”.

**Also**
- `/help` lists everything; new welcome suggestions; Settings cards for Voice, Reminders and Skills.
- Fixed: buttons on a chat card could stop working after the chat was saved in the background.
- Tests: 89 unit tests; app checks 45/45, 33/33, 15/15 and 44 new 2.0 checks.


## 1.3.1 – file access fix
Fixes "I added the folder but it says I'm not allowed to access the file":
- **NOVA AI 1.2 could not open files you named in the chat at all** (only files attached from the Files tab were read), so the model answered that it had no access. Tachyon 1.3+ opens them.
- **Edits were refused** ("Not one of the files you attached") when the model wrote the file path slightly differently: `/` instead of `\`, doubled `\\`, other letter case, quotes, or just the file name. Now matched safely to the attached file.
- **OneDrive folders**: `C:\Users\me\Documents\x.pdf` is now found when Windows keeps Documents/Desktop/Pictures in OneDrive (and the other way round).
- Folder checks now use the real Windows path (expands short names like `PROGRA~1`, real letter case); trailing `\` and `.`/`..` no longer matter.
- The "outside the folders you granted" message now names the path and says how to allow it.
- Tests: 72 unit tests (5 new file-access regression tests), 45/45 and 33/33 app checks pass.

## 1.3.0 – Tachyon
**Renamed** NOVA AI Desktop → **Tachyon**: package `tachyon`, product name, app ID `com.tachyon.desktop`, window/tray/panel titles,
installer names (`Tachyon-1.3.0-…`), system prompt ("You are Tachyon"), new icon and floating **T** button, build workflow and artifact names.
Settings, chats, keys and captures are copied from NOVA AI on first start. Backups keep the `.nova-bak` name so old backups still restore.

**Files from the chat**
- Name a path (`C:\…`, `D:\…`, `/…`, `~/…`, quoted paths), a file name (`budget.xlsx`) or a known folder (`my Downloads folder`) and Tachyon opens it.
- Read / summarize / ask (attaches it), edit (writes directly with `.nova-bak` backup + Undo, follow-ups like "now fix it" reuse the file),
  list a folder, convert documents (PDF/Word/Markdown/text/HTML) and images (PNG/JPEG), resize images, organize a folder (asks first), open, show in folder.
- Outside the granted folders: one prompt — Cancel / Allow for this session / Always allow this folder.
- 📎 attach button (any file on the computer), drag & drop files/folders, paste files or screenshots.

**Auto-save**
- "save it to X", "save this to my desktop as notes.md", "export this to PDF in D:\Reports" → saved without a dialog.
- "write … and save it to X" → answers, then saves.
- "from now on save answers to X" → every new answer in the chat is saved (badge shows it); "stop auto-saving" turns it off.
- Never overwrites (`name (1).pdf`), creates missing folders, "Show in folder" after each save.

**New look & extras**
- Redesigned dark theme, new light theme, follow-system option, text size setting.
- Copy button on code blocks, Read aloud, Edit last question, Export whole chat, chat search, keyboard shortcuts (Ctrl+N/K/O/,/L, Esc).

**Fixed**
- Text follow-ups after an image question now go to the Text model without re-sending the image (as the 1.2 notes described).

**Tests**
- Unit tests: 54 → 67, all passing. End-to-end: the 45 app checks pass (original 1.2 code: 43/45, the 2 failures were the bug above), plus 33 new feature checks.
