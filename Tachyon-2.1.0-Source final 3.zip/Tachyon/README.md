# Tachyon 2.1 (Windows first; also macOS and Linux)

## What's new in 2.1: a local desktop agent
- Icon sidebar with tooltips; Applications, Tools, AI Models, Project Workspace and Task History pages.
- Click the VS Code icon or type **Open VS Code**: Tachyon checks the request, launches it, checks whether a window appeared and tells you plainly if it could not confirm.
- Approved commands only (git status, versions, npm test, pytest ...): no shell, authorized folder, timeout, output limit, cancel.
- `/do <request>`: the local model proposes, you approve. Cloud models are never used for this.
- PowerShell / Windows Terminal open only when you click their icon; the AI cannot open shells.
- Details: docs/ARCHITECTURE.md, docs/SECURITY.md, docs/TEST-REPORT.md.

Tachyon (formerly **NOVA AI Desktop**) is a personal AI assistant for your laptop (Electron): chat, a floating screen-capture button,
local file tools, PDF/Office parsing, image tools and several AI back-ends. Every NOVA AI 1.2 and Tachyon 1.3 feature is still here and works the same way.
It works online (cloud models) and offline (Ollama models, offline speech).

## What's new in 2.0: an assistant that does things, safely
Type **/help** in the chat to see everything below.

### Talk to it (offline voice)
* 🎤 button, **Ctrl+M**, or **Ctrl+Shift+Space** from anywhere: speak, pause, and your words are sent. Answers to spoken questions are read aloud.
* Optional wake phrase **“Hey Tachyon”** (or your own phrase) while Tachyon is open.
* Speech is recognized **on your computer** with Vosk (English US, English India, Hindi; or import any Vosk model .zip). No audio leaves the computer.
  Download a model once in Settings → Voice (about 40 MB), then it works offline. Read-aloud uses your system voices (Windows voices work offline); pick voice and speed.

### Do things on the computer
* **Reminders**: “remind me in 20 minutes to stretch”, “remind me tomorrow at 9am to pay rent”, “show my reminders”, “cancel the reminder about rent”.
  Desktop notifications, also from the tray; missed ones appear at the next start.
* **Open apps**: “open Notepad”, “launch Spotify” (Start-menu apps). Shells, script hosts and system tools (cmd, PowerShell, regedit, …) are always blocked.
* **Windows**: “switch to Chrome”, “minimize Word”, “maximize Excel”, “show desktop”, “list open windows” (Windows).
* **Find files**: “find files named budget”, “find pdfs called invoice”, “find files containing total due”, with Attach / Open / Show buttons.

### Multi-step tasks with a plan you approve, and Undo
* “/task find my CV, convert it to PDF and copy it to my desktop”, or any request that chains several actions.
* Tachyon shows the **plan first** (each step and why). Nothing happens until you press **Run**. Each step follows your permissions.
* **Undo this task** reverses it: new files go to Tachyon's undo folder (nothing is deleted), edited files are restored, moved files go back, reminders are cancelled.
* Steps it can use: list, search, read, write with AI, save, edit, convert, create folder, copy, move, organize, open app, open file, remind. It cannot delete.

### Teach it new skills (it extends itself, safely)
* “create a skill that turns my notes into a to-do list” → Tachyon drafts the skill and **tests it**; you see the instructions or code and the test results, then **Install**.
* Use it with **/command your text**; list with **/skills**. Updating keeps the old version (**Roll back** in Settings → Skills); switch off or delete any time.
* Tachyon never changes its own program. Code skills run in a **locked sandbox** (no files, no network, no Tachyon access, 5-second limit); code that uses the network is refused.

### Understands you, and stays safe
* **Memory**: “remember that I prefer short answers”, “what do you remember about me”, “forget …”; stored only on this computer, viewable and deletable in Settings → Memory.
* **Permissions** (Settings → Permissions): Allow / Ask me every time / Never for reading, changing, creating, moving and opening files, sending files to cloud models,
  opening apps, window control, reminders and skills. Deleting and sending anything outside always ask.
* **Activity log** (Settings → Activity log): every file action, app launch, task step, skill run and AI request (local or cloud), on this computer only.


## What was new in 1.3
### Work with files straight from the chat
Name a file or folder in your message and Tachyon opens it for you. No need to go to the Files tab first.

| You type | What happens |
|---|---|
| `summarize C:\Users\me\Documents\report.pdf` | the file is attached and the Text model answers |
| `fix the typos in D:\notes\todo.txt` | the file is edited directly (a `.nova-bak` backup is made first, **Undo** is shown) |
| `now add a title to it` | follow-up edits reuse the file from the previous message |
| `summarize budget.xlsx` | a bare file name is looked up in your folders (and Desktop/Documents/Downloads) |
| `list the files in my Downloads folder` | a table of the folder, no AI needed |
| `convert report.docx to pdf` / `convert photo.png to jpg` | a converted copy next to the original |
| `resize photo.jpg to 1280 px` | resized in place, backup kept |
| `organize my Downloads folder by month` | asks once, then sorts into sub-folders (undo in Files → Organize) |
| `open plan.docx` / `show report.pdf in the folder` | opens it in its app / in Explorer/Finder (programs and scripts are never opened) |

Paths with spaces work when they end in a file extension, or put them in quotes. If the file is **outside** the folders you granted,
Tachyon asks first: *Cancel*, *Allow for this session*, or *Always allow this folder*. The 📎 button, drag & drop and pasting files
also attach files from anywhere (choosing them is your permission). Tachyon still never deletes files.

### Save answers where you say, without a dialog
* `save it to D:\Reports` saves the last answer there (PDF unless you say otherwise; a code-only answer keeps its language, e.g. `.py`).
* `save this to my desktop as notes.md`, `export this to PDF in D:\Reports`, `save it to "D:\My Files\summary.docx"`.
* `write a thank-you email and save it to my desktop` answers first, then saves.
* `from now on save answers to D:\AI` (or `auto-save to my documents folder as markdown`) saves **every** new answer in that chat;
  a green badge shows it, and `stop auto-saving` (or ✕ on the badge) turns it off.
* Existing files are never overwritten: `name (1).pdf`, `name (2).pdf`… Missing folders are created. A **Show in folder** button follows each save.
* Without a place (`Export this to PDF`) the Save dialog opens exactly as before.

### New look and everyday features
* Redesigned interface: new Tachyon theme, **light mode** (☀/☾ in the sidebar, or Settings → Appearance, incl. "follow my system"), adjustable text size,
  animated replies, cleaner tables and code blocks, suggestion cards on the start screen, new app icon and floating **T** button.
* 📎 attach from anywhere, **drag & drop** files or folders onto the chat, **paste screenshots** (Ctrl+V) straight into the chat (they go to the Vision model).
* **Copy** button on every code block, **🔊 Read aloud** on answers, **✎ Edit** your last question, **⬇ Export chat** (whole conversation to PDF/Word/Markdown/text/HTML).
* **Search chats** in the sidebar. Keyboard shortcuts: Ctrl+N new chat, Ctrl+K search, Ctrl+O attach, Ctrl+, settings, Ctrl+L focus the message box, Esc stop.
* Timestamps on hover; the chat title is shown above the conversation.

### Fixed
* A text follow-up after an image question now really goes to the **Text** model (with the Vision model's answer in the history), as described for 1.2.
  Before, the last image was re-sent and the question went to the Vision model again.

### Upgrading from NOVA AI
On the first start Tachyon copies your settings, chats, saved keys and recent captures from NOVA AI's data folder (the old folder is not changed).
On macOS the saved API keys are tied to the old app name in the keychain, so you may be asked to paste them again in Settings.
Backups keep the `.nova-bak` name so Undo still works for edits made by NOVA AI.

## What was new in 1.2
### 1. Two models, chosen automatically
Settings now has two model cards that can use different providers at the same time:

| Card | Handles | Example |
|---|---|---|
| **Text & chat model** | normal questions, coding, chat, file edits | Ollama `qwen2.5` |
| **Vision / OCR / screen-capture model** | every image: floating-button screenshots, image attachments, OCR, object detection, image analysis | Ollama `qwen2.5vl:3b` / `minicpm-v`, or a Gemini Flash model |

Tachyon picks the model from the input type, so you never switch by hand: text goes to the Text model, anything with an image
goes to the Vision model. Each card has its own provider (Ollama, Google Gemini, or any OpenAI-compatible cloud API), its own key,
"List models" and a real test ("Test with an image" sends a tiny red picture and checks that the model can see it).
"Use the Text model for images too" is available for models that can read images themselves (for example Gemini Flash).
Replies that came from the Vision model say so under the message. Follow-up text questions go to the Text model and see the Vision model's
answer in the conversation history (not the picture itself).

### 2. Files are created only when you ask
Replies never create, attach or offer a file. The old PDF buttons under every reply are gone. You get files only if you
* click **⬇ Export…** under a message (it appears when you hover; choose PDF, Word, Markdown, JSON, CSV, HTML, text, Python/JS), or
* ask in the chat, e.g. "Export this to PDF", "save that as a Word document", "convert the above to markdown"
  (exports the last answer), or "create a PDF report about X" (answers, then opens the Save dialog).
Questions such as "what is a PDF?" or "summarize this PDF" export nothing. Every export opens a Save dialog you can cancel.

### 3. Screen sharing & OCR
The floating button captures the whole screen or a chosen window (the window list refreshes each time you open the panel; minimized windows cannot be captured).
Screenshots and OCR go straight to the Vision model through chat completions only. They never use image-generation settings.
If an action is clicked while a capture is still running the panel now says so instead of ignoring it.

### 4. Answer style rules (built in)
Tachyon's system prompt enforces: answer in the first sentence with no filler ("Sure…", "Here is what I found…"); Markdown tables for
comparisons and timetables, short bullets for specs/features, numbered steps for sequences, fenced code for code; everything inline,
no unrequested files. Your own custom instructions are added after these rules. The chat now renders tables, lists, headings, bold,
inline code and code blocks properly (safe renderer, no HTML, no links).

### Also
* Optional **Gemini image generation** backend for `/image` (experimental; free-tier availability of image models changes, and it is not verified against the real service).
* Settings saved by version 1.0/1.1 are migrated automatically.

## Build the installers in the cloud (phone-friendly)
1. Create a NEW GitHub repository (or reuse your NOVA one: delete the old ZIP or leave it, the workflow picks the Tachyon one).
2. Upload `tachyon-source.zip` to the repo root.
3. Create (or replace) `.github/workflows/build-desktop.yml` with the contents of `build-desktop.yml`, commit.
4. Actions -> "Build Tachyon Desktop" -> Run workflow (5-10 minutes).
5. Download the artifact for your system (`tachyon-windows` / `tachyon-mac` / `tachyon-linux`), extract the ZIP, install/run (`Tachyon-1.3.0-….exe/.dmg/.AppImage`).
Local build (Node 22): `npm ci --ignore-scripts && npm test && npx electron-builder --publish never`

## Quick setup for your case (Ollama text + vision)
1. `ollama pull qwen2.5` and `ollama pull qwen2.5vl:3b` (about 3 GB, about 5 GB RAM; `minicpm-v` is also good at OCR).
2. Settings -> Text card: Ollama, model `qwen2.5` -> Test connection.
3. Settings -> Vision card: "Use a separate Vision model", Ollama, model `qwen2.5vl:3b` -> "Test with an image" -> Save settings.
Free cloud alternative: a Google AI Studio key works for both cards (choose a Gemini Flash model).

## What was and was not verified
Verified in the build environment (Linux):
* **2.0: 89 unit tests** pass (12 new: reminders, app matching and blocking, safe window control, task plans, chained-request detection,
  skills and their store, speech-model conversion, permissions), and **44 new end-to-end checks** (`test/e2e/v2.js`): reminders including a due
  notification, blocked shells and permissions, file search, a 7-step task with Run, result passing and full Undo, a task stopped by a permission,
  refused delete plans, skills (install, run, update, roll back, network refused, sandbox has no Node/Tachyon/network, endless code stopped after
  5 s, prompt skills, switch off), Settings cards, the activity log, and **offline speech recognition with a real Vosk model** (spoken test audio
  was recognized in the app), the microphone button and the wake-word listener. The 1.3 suites still pass: 45/45, 33/33 and 15/15 (memory, permissions, activity log).
* **67 unit tests** pass (`npm test`): the original 54 plus 13 new ones (file requests in the chat, "save it to …" parsing, save locations and
  never-overwrite naming, migration from NOVA AI, appearance settings, no leftover "NOVA AI" text).
* **45 end-to-end checks** pass in the real Electron app with separate mock Text and Vision servers (`test/e2e/run.js`): routing, output rules,
  Markdown rendering, no files or dialogs after normal replies, "Export this to PDF" with exactly one dialog and no model call, exports, edits with backups,
  organize/undo, two model cards, vision test, overlay capture and OCR. The original 1.2 code passes 43/45 on the same script; the 2 failures were the follow-up bug fixed above.
* **33 new end-to-end checks** (`test/e2e/new.js`): migration, typed paths inside and outside granted folders (with the permission prompt and Cancel),
  direct and follow-up edits, file-name lookup, list/convert/resize/organize/open/show, all auto-save phrases, never overwriting, auto-save on/off,
  📎 attach, pasted images to the Vision model, copy code, read aloud, edit last question, theme, chat search, export chat, shortcuts, and again no files
  or dialogs after normal questions. Run them with `npm i --no-save playwright` then `xvfb-run -a node test/e2e/run.js . Tachyon tachyon` and `xvfb-run -a node test/e2e/new.js .`
* A Linux package was built with electron-builder and starts as "Tachyon".

Not verified: Windows/macOS builds, window control and app launching on a real Windows PC (unit-tested with a stub), downloading the speech models (their host was not reachable here; the same pipeline was tested with an imported Vosk model), recognition quality with a real microphone, real Ollama/Gemini/other cloud models and their OCR quality, the real Gemini image API, the button over full-screen apps,
Windows drive paths on a real Windows machine (they are covered by unit tests only), read-aloud voices (they come from your operating system), and use on your computer.

## Known limitations
* Voice: the small offline models understand clear speech well but not perfectly; the wake phrase works best with common words if “Hey Tachyon” is missed.
  Listening for the wake phrase keeps the microphone on while Tachyon is open (Windows shows the microphone icon).
* Reminders only appear while Tachyon is running (it can stay in the tray).
* Window control and app launching are for Windows; on macOS/Linux, opening apps works but window control does not.
* Not code-signed. No auto-update. OCR quality depends entirely on your Vision model; there is no built-in OCR engine.
* PDFs: text-based only (screenshot a scanned page to OCR it). Editing a PDF creates a new PDF.
* Non-Latin text in created PDFs needs a suitable system font, otherwise characters become "?" (you are told).
* Models may not always obey the style rules perfectly (small models especially); the rules are sent with every request.
* InvokeAI generation is not supported (connection check only). Python checks need Python installed.
* Large files are truncated before being sent to the AI (about 60,000 characters per file, 150,000 total).
* Files allowed "for this session" from the chat must be allowed again after a restart (or choose "Always allow this folder").
* When you name a folder for a question, only up to 10 readable files directly inside it are attached.
* Paths with spaces must end in a file extension or be in quotes. Word/PDF files cannot be edited in place from the chat; ask for the corrected text and say "save it to …", or use Rewrite → PDF.
