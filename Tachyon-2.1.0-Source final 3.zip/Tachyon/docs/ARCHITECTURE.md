# Tachyon 2.1 architecture (agent layer)

Request path: chat text or UI click -> `parseAgentCommand` (rules) or `/do` (local model proposal, user approves) ->
`agent.run` -> `ConnectorRegistry.execute` ->
1. validate (JSON schema + connector hook; paths must be inside granted folders, symlinks resolved)
2. permission guard (Settings -> Permissions; `commands.run` always asks)
3. execute (timeout, AbortSignal cancel)
4. observe, verify (verified / unverified / failed)
5. activity record (Task History, `activity.jsonl`).

Connectors: apps, vscode, browser, terminal (UI-only), filesystem, git, devcmd, ollama, system, project.
Sources: `ui` (button), `chat` (typed rule), `model` (approved proposal). UI-only operations refuse any other source.
Main-process IPC channels are whitelisted in `src/preload.js`; the sender URL must be `file://`.
Task states: planned, awaiting approval, running, completed, failed, cancelled (partial completion is reported in step results).
