# Security review (Stage 1)

Electron: contextIsolation on, sandbox on, nodeIntegration off, webSecurity on, CSP `default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:`, window.open denied, navigation blocked, webview attach blocked. Checked by `test/agentSecurity.test.js`.

Agent: no shell anywhere in connectors (`shell:false`); fixed argument lists; environment whitelist (secrets stripped); authorized folders only; shells launch only from the launcher click; chat/AI cannot open them; cloud models refused for `/do`; nothing is sent externally.

Known limits (be aware):
- The window (renderer) is trusted for UI-button actions; a compromised renderer could call UI-only operations. Mitigated by CSP, no inline script, no remote content.
- `npm test`, `pytest`, `unittest` run the project's own code. They always ask first.
- Installers are not code-signed: SmartScreen / Gatekeeper warn.
- Launch verification relies on window listing; where unavailable the result is "unverified".
