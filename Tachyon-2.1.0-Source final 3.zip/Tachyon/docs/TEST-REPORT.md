# Test report (Tachyon 2.1.0)

Run in a Linux sandbox without access to the npm registry. Native/heavy libraries (pdfkit, pdfjs, fflate, vosk-browser) were replaced by stubs.

| Check | Result |
|---|---|
| `node --check` on all source and test files | pass |
| `npm test` (141 tests) | 133 pass, 8 fail |
| Headless UI check (`test/ui/ui-check.js`, real UI + real agent code, mocked processes) | 31/31 pass |

The 8 failures are the same 8 that failed before my changes: PDF creation, non-Latin PDF, docx export, pptx/xlsx extraction, export-by-extension, Office readable/searchable, analyzeFile, Vosk tar.gz. They depend on the stubbed libraries; they are expected to be checked by the real `npm ci` in GitHub Actions. Not proven to be only stub-related.

Not verified here (needs your machine / CI): launching the real Electron app, real VS Code / Chrome launch on Windows, real Ollama, `test/e2e` (updated but not run), the GitHub workflow itself (YAML syntax checked only), real Office/PDF parsing, installer builds.
Connector tests use mocked spawn/fs and are labelled as such; they do not prove real Windows behavior.
