'use strict';
// The "agent" layer: builds the connector registry for the running app and exposes what the UI needs
// (launcher cards, tool statuses, model status, projects, activity history). Contains no Electron imports so it can be tested.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createRegistry } = require('./connectors');
const U = require('./connectors/util');
const R = require('./connectors/runner');
const { classifyModel } = require('./connectors/tools');
const Perm = require('./permissions');
const Computer = require('./computer');
const { parseAgentCommand } = require('../renderer/agentIntent');

/** Activity history: one JSON line per finished action, newest last. Stays on this computer. */
class ActivityStore {
  constructor(dir, fsx = fs) { this.file = path.join(dir, 'activity.jsonl'); this.fs = fsx; }
  add(rec) {
    const slim = { ...rec };
    if (slim.result && typeof slim.result === 'object') slim.result = trimResult(slim.result);
    try {
      if (this.fs.existsSync(this.file) && this.fs.statSync(this.file).size > 3_000_000) this.fs.renameSync(this.file, this.file + '.1');
      this.fs.appendFileSync(this.file, JSON.stringify(slim) + '\n', 'utf8');
    } catch { /* best effort */ }
  }
  list(limit = 100) {
    let lines = [];
    try { lines = this.fs.readFileSync(this.file, 'utf8').split('\n').filter(Boolean); } catch { return []; }
    return lines.slice(-limit).reverse().map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  }
  clear() { for (const f of [this.file, this.file + '.1']) { try { this.fs.unlinkSync(f); } catch { /* none */ } } }
}
function trimResult(r) {
  const o = {};
  for (const [k, v] of Object.entries(r)) {
    if (k === 'info') continue;
    o[k] = typeof v === 'string' && v.length > 3000 ? v.slice(0, 3000) + '…' : v;
  }
  return o;
}

const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 30) || 'item';

/** deps: { userData, getSettings, saveSettings, guard, roots, emit, openExternal, openPath, platform, env, fetch, listWindows } */
function create(deps) {
  const ctx = {
    platform: deps.platform || process.platform, env: deps.env || process.env, fs: deps.fs || fs,
    roots: deps.roots, settings: deps.getSettings, guard: deps.guard, openExternal: deps.openExternal, openPath: deps.openPath,
    fetch: deps.fetch, spawn: deps.spawn,
    listWindows: deps.listWindows || null,
    ollamaBase() {
      const m = (deps.getSettings().models || {}).text;
      return m && m.provider !== 'cloud' && m.host ? `http://${m.host}:${m.port || 11434}` : 'http://127.0.0.1:11434';
    },
    emit: deps.emit,
  };
  const activity = new ActivityStore(deps.userData);
  const history = new R.RunHistory(deps.userData);
  ctx.history = history;
  const recent = new Map(); // full records (with command output) of the last runs, for “Explain this output”
  ctx.log = (rec) => {
    recent.set(rec.id, rec);
    while (recent.size > 30) recent.delete(recent.keys().next().value);
    activity.add(rec);
    if (deps.audit) deps.audit.log({ action: `${rec.connector}.${rec.op}`, category: 'agent', target: rec.target || rec.label, ok: rec.state === 'completed' || rec.state === 'partial', detail: `${rec.state}${rec.error ? ': ' + rec.error : ''}${rec.verification ? ' (' + rec.verification.status + ')' : ''}` });
  };
  const registry = createRegistry(ctx);
  const permOf = (cat) => Perm.effective(deps.getSettings())[cat];
  const cfgStatus = (cat, base) => (cat && permOf(cat) === 'deny' ? { ...base, status: 'needs_permission', detail: `“${Perm.CATEGORIES[cat].label}” is set to Never in Settings → Permissions.` } : base);

  // ---------------------------------------------------------------- projects
  const projects = () => (Array.isArray(deps.getSettings().projects) ? deps.getSettings().projects : []);
  function addProject(dir, name) {
    const p = U.authorizedPath(ctx, dir);
    if (!U.isDir(ctx, p)) throw new Error('Choose a folder.');
    const list = projects();
    const cmp = (x) => (ctx.platform === 'win32' ? x.toLowerCase() : x);
    if (list.some((x) => cmp(x.path) === cmp(p))) throw new Error('This project is already in your list.');
    if (list.length >= 30) throw new Error('You can keep up to 30 projects.');
    const nm = String(name || path.basename(p)).trim().slice(0, 60) || path.basename(p);
    let id = slug(nm);
    while (list.some((x) => x.id === id)) id = slug(nm) + '-' + crypto.randomBytes(2).toString('hex');
    const proj = { id, name: nm, path: p };
    deps.saveSettings({ projects: [...list, proj] });
    return proj;
  }
  function removeProject(id) { deps.saveSettings({ projects: projects().filter((x) => x.id !== id) }); return true; }
  /** "my project", "tachyon", a project id or the only project -> project. */
  function findProject(q) {
    const list = projects();
    const s = String(q || '').toLowerCase().trim();
    if (!list.length) return null;
    if (!s || /^(my |the |this |current )?(project|workspace|repo|repository|code)$/.test(s)) return list.find((x) => x.id === deps.getSettings().activeProject) || list[0];
    return list.find((x) => x.id === s || x.name.toLowerCase() === s) || list.find((x) => x.name.toLowerCase().includes(s) || s.includes(x.name.toLowerCase())) || null;
  }

  // ---------------------------------------------------------------- custom apps
  const customApps = () => (Array.isArray(deps.getSettings().customApps) ? deps.getSettings().customApps : []);
  function addCustomApp(exePath, name) {
    const p = String(exePath || '');
    if (!path.isAbsolute(p) || !U.isFile(ctx, p)) throw new Error('Choose the program file (.exe) of the app.');
    if (ctx.platform === 'win32' && !/\.exe$/i.test(p)) throw new Error('Choose a program file that ends in .exe.');
    const nm = String(name || path.basename(p).replace(/\.exe$/i, '')).trim().slice(0, 40);
    if (Computer.blocked(nm) || Computer.blocked(path.basename(p))) throw new Error('Shells and system tools cannot be added here. PowerShell and Windows Terminal have their own buttons.');
    const list = customApps();
    if (list.length >= 12) throw new Error('You can add up to 12 apps.');
    let id = slug(nm);
    while (list.some((x) => x.id === id)) id = slug(nm) + '-' + crypto.randomBytes(2).toString('hex');
    const a = { id, name: nm, path: p };
    deps.saveSettings({ customApps: [...list, a] });
    return a;
  }
  function removeCustomApp(id) { deps.saveSettings({ customApps: customApps().filter((x) => x.id !== id) }); return true; }


  // ---------------------------------------------------------------- chat commands
  /** Fills a path/cwd argument from a project name. Returns { args } or { message } (a plain-language problem). */
  function resolveProjectArgs(connector, op, base, projectName) {
    const entry = registry.catalog().find((o) => o.connector === connector && o.op === op);
    const props = (entry && entry.schema.properties) || {};
    const key = 'cwd' in props ? 'cwd' : 'path' in props ? 'path' : null;
    const args = { ...base };
    if (!key || args[key]) return { args };
    const required = (entry.schema.required || []).includes(key);
    if (projectName === undefined && !required) return { args };
    const list = projects();
    if (!list.length) return { message: 'I need a project for that. Open **Project Workspace** and add a project folder first.' };
    const proj = findProject(projectName);
    if (!proj) return { message: `I do not know a project called “${projectName}”. Your projects: ${list.map((x) => x.name).join(', ')}.` };
    args[key] = proj.path;
    return { args, project: proj };
  }

  /** “run the tests” -> the right test command for the project, or a message. */
  async function autoTestCommand(cwd) {
    const rec = await registry.execute({ connector: 'project', op: 'inspect', args: { path: cwd }, source: 'chat', label: 'Inspect project' });
    const r = rec.result;
    if (!r) return { message: rec.error || 'I could not look at that project.' };
    if (r.hasTestScript) return { command: 'npm.test' };
    if (r.kinds.includes('Python')) return { command: 'python.pytest' };
    return { message: `I could not find a test setup in “${r.name}” (no “test” script in package.json, no Python project files).` };
  }

  /**
   * A sentence typed in the chat. Returns { handled:false } when it is not an agent command, otherwise
   * { handled:true, message } (nothing ran) or { handled:true, record } (the finished action record).
   */
  async function chat(text) {
    const intent = parseAgentCommand(String(text || ''));
    if (!intent) return { handled: false };
    if (intent.kind === 'refuse') return { handled: true, refused: true, message: intent.message };
    let args = { ...intent.args };
    if (intent.project !== undefined || intent.needsProject) {
      const r = resolveProjectArgs(intent.connector, intent.op, args, intent.project === undefined ? '' : intent.project);
      if (r.message) return { handled: true, message: r.message };
      args = r.args;
    }
    if (args.command === 'auto') {
      const t = await autoTestCommand(args.cwd);
      if (t.message) return { handled: true, message: t.message };
      args.command = t.command;
    }
    return { handled: true, record: await registry.execute({ connector: intent.connector, op: intent.op, args, source: 'chat', label: intent.label }) };
  }

  // ---------------------------------------------------------------- UI data
  async function caps() { const m = {}; for (const c of await registry.discoverCapabilities()) m[c.id] = c; return m; }

  /** Cards for the Applications panel. */
  async function apps() {
    const c = await caps();
    const g = U.findGit(ctx); const py = U.findPython(ctx);
    const cards = [
      { id: 'vscode', label: 'Visual Studio Code', icon: 'code', ...cfgStatus('apps.open', { status: c.vscode.status, detail: c.vscode.detail || c.vscode.path || '' }), launch: { connector: 'vscode', op: 'open' }, projectAction: { label: 'Open project', connector: 'vscode', op: 'open' } },
      { id: 'chrome', label: 'Google Chrome', icon: 'globe', ...cfgStatus('browser.open', { status: U.findChrome(ctx) ? 'available' : 'not_installed', detail: U.findChrome(ctx) ? '' : 'Chrome was not found. Links open in your default browser.' }), launch: { connector: 'browser', op: 'open', needs: 'url' } },
      { id: 'explorer', label: 'File Explorer', icon: 'folder-open', ...cfgStatus('files.open', { status: ctx.platform === 'win32' || deps.openPath ? 'available' : 'unavailable', detail: '' }), launch: { connector: 'apps', op: 'openExplorer' }, projectAction: { label: 'Open project folder', connector: 'apps', op: 'openExplorer' } },
      { id: 'powershell', label: 'PowerShell', icon: 'terminal', ...cfgStatus('terminal.open', { status: U.findPowerShell(ctx) ? 'available' : ctx.platform === 'win32' ? 'not_installed' : 'unavailable', detail: 'Opens only when you click the button, in a folder you granted.' }), launch: { connector: 'terminal', op: 'openPowerShell', needs: 'folder' } },
      { id: 'wt', label: 'Windows Terminal', icon: 'square-terminal', ...cfgStatus('terminal.open', { status: U.findWindowsTerminal(ctx) ? 'available' : ctx.platform === 'win32' ? 'not_installed' : 'unavailable', detail: 'Opens only when you click the button, in a folder you granted.' }), launch: { connector: 'terminal', op: 'openWindowsTerminal', needs: 'folder' } },
      { id: 'git', label: 'Git', icon: 'git-branch', ...cfgStatus('commands.read', { status: g ? 'available' : 'not_installed', detail: g ? 'Read-only: status, branch, log.' : 'Git was not found.' }), launch: { connector: 'git', op: 'read', command: 'git.status', needs: 'project', label: 'Status' } },
      { id: 'python', label: 'Python', icon: 'terminal', ...cfgStatus('commands.read', { status: py ? 'available' : 'not_installed', detail: py ? 'Shows the installed version; tests run from Project Workspace.' : 'Python was not found.' }), launch: { connector: 'devcmd', op: 'version', command: 'python.version', needs: 'project', label: 'Version' } },
    ];
    for (const a of customApps()) {
      cards.push({ id: 'custom-' + a.id, label: a.name, icon: 'app-window', custom: true, customId: a.id, ...cfgStatus('apps.open', { status: U.isFile(ctx, a.path) ? 'available' : 'unavailable', detail: U.isFile(ctx, a.path) ? a.path : 'File not found: ' + a.path }), launch: { connector: 'apps', op: 'launchCustom' } });
    }
    return cards;
  }

  async function modelStatus() {
    const s = deps.getSettings();
    const slot = (m, key) => ({ slot: key, provider: m.provider, model: m.model || '', ready: Boolean(m.model && (m.provider === 'cloud' ? m.baseUrl : m.host && m.port)), local: m.provider !== 'cloud' });
    // Read directly (not through the activity history): the window polls this, and a status check is not an "action".
    let res = null; let failure = null;
    try { res = await registry.get('ollama').operations.status.execute({}, ctx, { signal: AbortSignal.timeout(5000) }); } catch (e) { failure = e.message; }
    const rec = { result: res, error: failure };
    const installed = rec.result ? rec.result.models : [];
    const has = (name) => installed.some((m) => m.name === name || m.name.split(':')[0] === String(name).split(':')[0]);
    const text = slot(s.models.text, 'text'); const vision = slot(s.models.vision, 'vision');
    if (vision.model === '' && s.models.vision.mode !== 'separate') { vision.model = text.model; vision.shared = true; vision.ready = text.ready; }
    for (const x of [text, vision]) x.installed = x.local && rec.result && rec.result.running ? has(x.model) : null;
    return { ollama: rec.result ? { running: rec.result.running, base: rec.result.base, error: rec.result.error || null } : { running: false, error: rec.error }, text, vision, installed,
      embedding: installed.filter((m) => m.kind === 'embedding'), offlineReady: text.local && text.ready && Boolean(rec.result && rec.result.running && text.installed) };
  }

  /** The 7 tool groups. Anything without a real backend is shown as Unavailable, with the reason. */
  async function tools() {
    const c = await caps(); const s = deps.getSettings();
    const hasFolders = ctx.roots().length > 0;
    const textReady = Boolean(s.models.text.model);
    const visionReady = s.models.vision.mode === 'separate' ? Boolean(s.models.vision.model) : textReady;
    const T = (id, label, status, detail, action) => ({ id, label, status, detail: detail || '', action: action || null });
    const folderTool = (id, label, detail, action) => (hasFolders ? T(id, label, 'available', detail, action) : T(id, label, 'needs_permission', 'Add a folder in Files & PDFs first.', { view: 'files' }));
    const modelTool = (id, label, detail, action) => (textReady ? T(id, label, 'available', detail, action) : T(id, label, 'unavailable', 'No text model is set (Settings).', { view: 'settings' }));
    const cap = (id, label, key, detail, action) => { const k = c[key]; return T(id, label, k.status === 'available' ? 'available' : k.status, k.status === 'available' ? detail : k.detail, k.status === 'available' ? action : null); };
    const imgOn = s.imageBackend && s.imageBackend !== 'none';
    return [
      { id: 'apps', label: 'Application tools', items: [
        T('launcher', 'Application launcher', 'available', 'Start installed apps with one click.', { view: 'apps' }),
        T('discovery', 'Application discovery', ctx.platform === 'win32' ? 'available' : 'unavailable', ctx.platform === 'win32' ? 'Finds apps from the Start Menu and common install folders.' : 'Windows only.', { view: 'apps' }),
        folderTool('project-opener', 'Project opener', 'Open a configured project in VS Code or File Explorer.', { view: 'projects' }),
      ] },
      { id: 'files', label: 'File tools', items: [
        folderTool('search', 'File search', 'Find files by name or by what is inside.', { view: 'files' }),
        folderTool('read', 'File reading', 'Read text, PDF and Office files you granted.', { view: 'files' }),
        folderTool('edit', 'File editing', 'Edit with the built-in editor or ask the AI to change a file.', { view: 'files' }),
        folderTool('save', 'Save changes', 'Every change keeps a .nova-bak backup.', { view: 'files' }),
        T('indexing', 'Folder indexing', 'unavailable', 'Not part of this version yet (planned for a later stage).'),
        modelTool('summarize', 'Document summarization', 'Attach a document in Chat and ask for a summary.', { view: 'chat' }),
      ] },
      { id: 'dev', label: 'Developer tools', items: [
        cap('vscode', 'VS Code integration', 'vscode', 'Open VS Code on a project or file.', { view: 'apps' }),
        cap('git', 'Git status', 'git', 'Read-only status, branch and log.', { view: 'projects' }),
        cap('python', 'Python diagnostics', 'devcmd', 'Python, Node and npm versions.', { view: 'projects' }),
        cap('tests', 'Test execution', 'devcmd', 'npm test, pytest or unittest — always asks first.', { view: 'projects' }),
        modelTool('errors', 'Error-log analysis', 'The AI explains the output of a command you ran.', { view: 'projects' }),
      ] },
      { id: 'browser', label: 'Browser tools', items: [
        cfgStatusItem(T('url', 'Open URL', 'available', 'Open an http/https page in Chrome.', { view: 'apps' }), 'browser.open'),
        T('nav', 'Browser navigation', 'unavailable', 'Clicking and typing in pages is not part of this version yet.'),
        T('inspect', 'Page inspection', 'unavailable', 'Reading the open page is not part of this version yet.'),
        T('shot', 'Screenshot capture', 'available', 'Use the screen button in Chat; it needs a vision model to be understood.', { view: 'chat' }),
      ] },
      { id: 'ai', label: 'AI tools', items: [
        modelTool('text-model', 'Text model', s.models.text.model || '', { view: 'models' }),
        visionReady ? T('vision-model', 'Vision model', 'available', s.models.vision.mode === 'separate' ? s.models.vision.model : 'Uses the text model.', { view: 'models' }) : T('vision-model', 'Vision model', 'unavailable', 'No vision model is set.', { view: 'models' }),
        T('embedding-model', 'Embedding model', 'unavailable', 'Models are detected and listed, but this version has no feature that uses embeddings yet.', { view: 'models' }),
        cap('model-status', 'Model status', 'ollama', 'Is Ollama running, which models are installed.', { view: 'models' }),
        T('switch', 'Model switching', 'available', 'Choose another installed model in Settings.', { view: 'settings' }),
      ] },
      { id: 'data', label: 'Data and media tools', items: [
        folderTool('csv', 'CSV analysis', 'Attach a CSV to ask questions about it.', { view: 'files' }),
        folderTool('docs', 'Document processing', 'Convert, rewrite to PDF, extract text.', { view: 'files' }),
        imgOn ? T('image', 'Image generation', 'available', 'Backend: ' + s.imageBackend, { view: 'image' }) : T('image', 'Image generation', 'unavailable', 'No image backend is set (Settings → Images).', { view: 'settings' }),
        visionReady ? T('screen-understanding', 'Screenshot understanding', 'available', 'Needs a vision-capable model.', { view: 'chat' }) : T('screen-understanding', 'Screenshot understanding', 'unavailable', 'No vision model is set.', { view: 'models' }),
      ] },
      { id: 'system', label: 'System tools', items: [
        T('hardware', 'Hardware information', 'available', 'CPU and memory.', { run: { connector: 'system', op: 'info' } }),
        T('resources', 'Resource monitoring', 'available', 'A snapshot of memory use (no background monitor).', { run: { connector: 'system', op: 'info' } }),
        T('diagnostics', 'Application diagnostics', 'available', 'Shows which connectors can run on this computer.', { run: { diagnostics: true } }),
        cfgStatusItem(T('terminals', 'Approved terminal operations', U.findPowerShell(ctx) || U.findWindowsTerminal(ctx) ? 'available' : ctx.platform === 'win32' ? 'not_installed' : 'unavailable', 'Terminals open only from their button; commands come from a fixed allowlist.', { view: 'apps' }), 'terminal.open'),
      ] },
    ];
    function cfgStatusItem(item, cat) { return permOf(cat) === 'deny' ? { ...item, status: 'needs_permission', detail: 'Set to Never in Settings → Permissions.' } : item; }
  }

  return {
    registry, ctx, activity, history, run: (a) => registry.execute(a), cancel: (id) => registry.cancelAction(id),
    chat, resolveProjectArgs, projects, addProject, removeProject, findProject, customApps, addCustomApp, removeCustomApp,
    apps, tools, modelStatus, caps, classifyModel, getRecord: (id) => recent.get(String(id)) || null,
    diagnostics: async () => (await registry.discoverCapabilities()).map((c) => ({ id: c.id, label: c.label, status: c.status, detail: c.detail || c.path || '' })),
  };
}

module.exports = { create, ActivityStore };
