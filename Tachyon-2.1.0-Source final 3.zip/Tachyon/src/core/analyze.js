'use strict';
// Local file analysis (no AI): document parsing summaries and code/data checks.
const fsp = require('fs/promises');
const path = require('path');
const F = require('./fsTools');
const { checkText, formatDiagnostics } = require('./debugTools');
const { parseCsv, jsonShape } = require('./docs');

const words = (t) => (t.match(/\S+/g) || []).length;

async function analyzeFile(roots, p) {
  F.assertInside(roots, p);
  const e = path.extname(p).slice(1).toLowerCase();
  const st = await fsp.stat(p);
  const lines = [`File: ${path.basename(p)}`, `Size: ${st.size} bytes`, `Modified: ${new Date(st.mtimeMs).toISOString()}`];
  let preview = '';
  let diagnostics = [];
  let kind = e || 'file';

  if (e === 'pdf' || F.OFFICE_EXT.has(e)) {
    const r = await F.readForAI(roots, p, { maxChars: 400000 });
    kind = 'document';
    lines.push(`Type: ${r.note}`, `Words (approx.): ${words(r.text)}`, r.truncated ? 'Note: only the first part was analysed (very large file).' : '');
    if (!r.text) lines.push('No extractable text (it may be a scanned image).');
    preview = r.text.slice(0, 1500);
  } else if (F.TEXT_EXT.has(e)) {
    const text = await F.readEditable(roots, p);
    const res = await checkText(p, text);
    diagnostics = res.diagnostics;
    kind = ['json', 'csv', 'tsv'].includes(e) ? 'data' : 'code';
    lines.push(`Lines: ${text.split('\n').length}`, `Check: ${res.ok ? 'no problems found' : res.diagnostics.length + ' problem(s) found'}`);
    if (res.note) lines.push(res.note);
    if (e === 'json' && res.ok) lines.push('Structure: ' + jsonShape(JSON.parse(text)));
    if (e === 'csv' || e === 'tsv') {
      const { rows } = parseCsv(text);
      lines.push(`Header: ${(rows[0] || []).join(' | ')}`);
    }
    if (!res.ok) lines.push('', formatDiagnostics(res));
    preview = text.slice(0, 1500);
  } else {
    lines.push('No built-in analysis for this file type.');
  }
  return { kind, title: path.basename(p), report: lines.filter((l) => l !== '').join('\n'), preview, diagnostics };
}

module.exports = { analyzeFile };
