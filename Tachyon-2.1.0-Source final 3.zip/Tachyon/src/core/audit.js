'use strict';
// Action audit log: one JSON line per action Tachyon takes on your computer (read, edit, create, move, open, AI request…).
// Stored only on this computer, in the app data folder. The log is append-only; you can view or clear it in Settings.
const fs = require('fs');
const path = require('path');

const MAX_BYTES = 5_000_000;

class AuditLog {
  constructor(dir) {
    this.file = path.join(dir, 'audit.log.jsonl');
  }

  /** entry: { action, category, target?, detail?, ok?, decision? } */
  log(entry) {
    const row = { ts: Date.now(), ok: true, ...entry };
    for (const k of ['target', 'detail']) if (row[k] != null) row[k] = String(row[k]).slice(0, 500);
    try {
      if (fs.existsSync(this.file) && fs.statSync(this.file).size > MAX_BYTES) fs.renameSync(this.file, this.file + '.1');
      fs.appendFileSync(this.file, JSON.stringify(row) + '\n', 'utf8');
    } catch { /* logging must never break an action */ }
    return row;
  }

  /** Newest first. */
  list({ limit = 300, category = null } = {}) {
    let lines = [];
    try { lines = fs.readFileSync(this.file, 'utf8').split('\n').filter(Boolean); } catch { return []; }
    const out = [];
    for (let i = lines.length - 1; i >= 0 && out.length < limit; i--) {
      try { const r = JSON.parse(lines[i]); if (!category || r.category === category) out.push(r); } catch { /* damaged line */ }
    }
    return out;
  }

  clear() {
    for (const f of [this.file, this.file + '.1']) { try { fs.unlinkSync(f); } catch { /* none */ } }
  }
}

module.exports = { AuditLog };
