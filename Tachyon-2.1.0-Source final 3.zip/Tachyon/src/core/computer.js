'use strict';
// Computer control: open installed apps and manage windows. Windows first (Start Menu shortcuts, PowerShell + user32),
// with macOS/Linux fallbacks for opening apps. Shells, script hosts and admin tools are never launched.
const fs = require('fs');
const path = require('path');
const { execFile, spawn } = require('child_process');

// Apps that are not Start Menu shortcuts on Windows: started by executable name or a Windows URI.
const BUILTIN = {
  notepad: { win: { exe: 'notepad.exe' } },
  calculator: { win: { uri: 'calculator:' }, aliases: ['calc'] },
  paint: { win: { exe: 'mspaint.exe' }, aliases: ['mspaint', 'ms paint'] },
  'file explorer': { win: { exe: 'explorer.exe' }, aliases: ['explorer', 'files', 'file manager', 'my computer', 'this pc'] },
  settings: { win: { uri: 'ms-settings:' }, aliases: ['windows settings', 'system settings'] },
  'microsoft store': { win: { uri: 'ms-windows-store:' }, aliases: ['store', 'app store'] },
  camera: { win: { uri: 'microsoft.windows.camera:' } },
  'snipping tool': { win: { uri: 'ms-screenclip:' }, aliases: ['snip', 'screenshot tool'] },
  clock: { win: { uri: 'ms-clock:' }, aliases: ['alarms', 'timer', 'stopwatch'] },
  mail: { win: { uri: 'mailto:' }, aliases: ['email', 'outlook mail'] },
  'task manager': { win: { exe: 'taskmgr.exe' } },
  wordpad: { win: { exe: 'write.exe' } },
};
// Never started from the chat: shells, script hosts, registry and system administration tools.
const DENY = /^(cmd|command prompt|powershell|pwsh|windows terminal|terminal|wt|bash|wsl|regedit|registry|wscript|cscript|mshta|rundll32|regsvr32|msiexec|certutil|bitsadmin|diskpart|format|gpedit|secpol|mmc|control panel|services|sh|zsh|python|node)(\.exe)?$/i;

// Shortcut names that open a shell or system tool ("Windows PowerShell", "Developer Command Prompt", "Git Bash", "Ubuntu" for WSL…).
const DENY_ANY = /\b(power ?shell|pwsh|cmd|command prompt|terminal|console|regedit|registry editor|wscript|cscript|mshta|windows script host|bash|wsl|ubuntu|debian|kali|opensuse|python|node ?js|git cmd|group policy|computer management|disk management|diskpart|task scheduler|event viewer|local security|services|recovery drive)\b/i;
const blocked = (s) => DENY.test(norm(s)) || DENY_ANY.test(String(s).replace(/[._-]+/g, ' '));

const norm = (s) => String(s || '').toLowerCase().replace(/\.(lnk|url|exe|app|desktop)$/i, '').replace(/[^a-z0-9+#]+/g, ' ').trim();

/** Scores how well a shortcut name matches what the user said (0 = no match). */
function matchScore(query, name) {
  const q = norm(query);
  const n = norm(name);
  if (!q || !n) return 0;
  if (n === q) return 100;
  if (n.startsWith(q + ' ') || n.endsWith(' ' + q)) return 80;
  const qw = q.split(' ');
  const nw = n.split(' ');
  if (qw.every((w) => nw.includes(w))) return 60 - Math.min(20, nw.length - qw.length);
  if (n.includes(q)) return 40;
  if (qw.length === 1 && nw.some((w) => w.startsWith(q) && q.length >= 3)) return 30;
  return 0;
}

/** Picks the best shortcut [{name, path}] for the query; uninstall/help/readme shortcuts are skipped. */
function bestShortcut(query, entries) {
  let best = null;
  for (const e of entries) {
    if (/uninstall|readme|help|documentation|release notes|website|license/i.test(e.name)) continue;
    const s = matchScore(query, e.name);
    if (s && (!best || s > best.score || (s === best.score && e.name.length < best.name.length))) best = { ...e, score: s };
  }
  return best;
}

function walkShortcuts(dir, exts, out = [], depth = 0) {
  let items = [];
  try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const it of items) {
    const p = path.join(dir, it.name);
    if (it.isDirectory() && depth < 4) walkShortcuts(p, exts, out, depth + 1);
    else if (exts.test(it.name)) out.push({ name: it.name.replace(exts, ''), path: p });
  }
  return out;
}

/** Installed apps the user could open, per platform. */
function listApps(env = process.env, platform = process.platform) {
  if (platform === 'win32') {
    const dirs = [env.ProgramData && path.join(env.ProgramData, 'Microsoft', 'Windows', 'Start Menu', 'Programs'),
      env.APPDATA && path.join(env.APPDATA, 'Microsoft', 'Windows', 'Start Menu', 'Programs')].filter(Boolean);
    return dirs.flatMap((d) => walkShortcuts(d, /\.(lnk|url)$/i));
  }
  if (platform === 'darwin') return ['/Applications', '/System/Applications', path.join(env.HOME || '', 'Applications')].flatMap((d) => walkShortcuts(d, /\.app$/i, [], 3));
  const out = [];
  for (const d of ['/usr/share/applications', path.join(env.HOME || '', '.local/share/applications')]) {
    for (const e of walkShortcuts(d, /\.desktop$/i)) {
      try { const m = /^Name=(.+)$/m.exec(fs.readFileSync(e.path, 'utf8')); out.push({ name: m ? m[1].trim() : e.name, path: e.path, id: path.basename(e.path) }); } catch { /* unreadable */ }
    }
  }
  return out;
}

/** Decides how to open an app. Returns { kind: 'exe'|'uri'|'shortcut'|'mac'|'desktop', target, name } or throws. */
function resolveApp(name, { platform = process.platform, apps = null } = {}) {
  const q = norm(name);
  if (!q) throw new Error('Which app should I open?');
  if (blocked(name)) throw new Error(`For safety Tachyon does not open ${name} (shells, script hosts and system tools are blocked).`);
  for (const [key, b] of Object.entries(BUILTIN)) {
    if ((q === key || (b.aliases || []).includes(q)) && platform === 'win32' && b.win) return { kind: b.win.exe ? 'exe' : 'uri', target: b.win.exe || b.win.uri, name: key };
  }
  const list = apps || listApps(process.env, platform);
  const hit = bestShortcut(q, list);
  if (!hit) throw new Error(`I could not find an app called “${name}”. Check the name as it appears in your Start menu.`);
  if (blocked(hit.name)) throw new Error(`For safety Tachyon does not open ${hit.name} (shells, script hosts and system tools are blocked).`);
  if (platform === 'darwin') return { kind: 'mac', target: hit.path, name: hit.name };
  if (platform === 'win32') return { kind: 'shortcut', target: hit.path, name: hit.name };
  return { kind: 'desktop', target: hit.id || path.basename(hit.path), name: hit.name };
}

/** Starts the resolved app. shell: Electron's shell module. */
async function launch(r, shell) {
  if (r.kind === 'uri') { await shell.openExternal(r.target); return; }
  if (r.kind === 'shortcut' || r.kind === 'mac') { const err = await shell.openPath(r.target); if (err) throw new Error(err); return; }
  const cmd = r.kind === 'exe' ? r.target : 'gtk-launch';
  const args = r.kind === 'exe' ? [] : [r.target];
  await new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { detached: true, stdio: 'ignore', windowsHide: false, shell: false });
    child.once('error', reject);
    child.once('spawn', () => { child.unref(); resolve(); });
  });
}

// ---------------------------------------------------------------- windows (Windows only)
const WIN_PS = String.raw`
$ErrorActionPreference = 'Stop'
Add-Type @"
using System; using System.Runtime.InteropServices;
public class TachyonWin { [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h); }
"@
$action = $env:TACHYON_ACTION; $target = $env:TACHYON_TARGET
if ($action -eq 'minimizeAll') { (New-Object -ComObject Shell.Application).MinimizeAll(); 'ok'; exit }
if ($action -eq 'restoreAll') { (New-Object -ComObject Shell.Application).UndoMinimizeAll(); 'ok'; exit }
$wins = Get-Process | Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -ne '' }
if ($action -eq 'list') { $wins | ForEach-Object { $_.ProcessName + "` + '\t' + String.raw`" + $_.MainWindowTitle }; exit }
$t = $target.ToLower()
$hit = $wins | Where-Object { $_.ProcessName.ToLower() -eq $t } | Select-Object -First 1
if (-not $hit) { $hit = $wins | Where-Object { $_.MainWindowTitle.ToLower().Contains($t) -or $_.ProcessName.ToLower().Contains($t) } | Select-Object -First 1 }
if (-not $hit) { throw "No open window matches '$target'." }
$h = $hit.MainWindowHandle
switch ($action) {
  'focus'    { [TachyonWin]::ShowWindow($h, 9) | Out-Null; [TachyonWin]::SetForegroundWindow($h) | Out-Null }
  'minimize' { [TachyonWin]::ShowWindow($h, 6) | Out-Null }
  'maximize' { [TachyonWin]::ShowWindow($h, 3) | Out-Null; [TachyonWin]::SetForegroundWindow($h) | Out-Null }
  'restore'  { [TachyonWin]::ShowWindow($h, 9) | Out-Null }
}
$hit.MainWindowTitle
`;
const WINDOW_ACTIONS = ['list', 'focus', 'minimize', 'maximize', 'restore', 'minimizeAll', 'restoreAll'];

/** Runs a window action. The target travels in an environment variable, never inside the script text. */
function windowAction(action, target = '', { platform = process.platform, run = execFile } = {}) {
  if (!WINDOW_ACTIONS.includes(action)) return Promise.reject(new Error('Unknown window action.'));
  if (platform !== 'win32') return Promise.reject(new Error('Window control is available on Windows.'));
  return new Promise((resolve, reject) => {
    run('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', WIN_PS],
      { env: { ...process.env, TACHYON_ACTION: action, TACHYON_TARGET: String(target).slice(0, 120) }, windowsHide: true, timeout: 15000 },
      (err, stdout, stderr) => {
        if (err) reject(new Error((String(stderr).split('\n').find((l) => l.trim()) || err.message).replace(/^.*?:\s*/, '').trim()));
        else resolve(String(stdout).trim());
      });
  });
}

const { parseComputerCommand } = require('../renderer/commands');

module.exports = { BUILTIN, DENY, DENY_ANY, blocked, matchScore, bestShortcut, listApps, resolveApp, launch, windowAction, WINDOW_ACTIONS, parseComputerCommand, WIN_PS };
