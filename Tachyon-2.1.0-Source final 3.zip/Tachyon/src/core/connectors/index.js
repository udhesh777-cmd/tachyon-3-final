'use strict';
const { ConnectorRegistry } = require('./registry');
const L = require('./launchers');
const T = require('./tools');

/** A registry with every Tachyon connector registered. */
function createRegistry(ctx) {
  const reg = new ConnectorRegistry(ctx);
  for (const c of [L.apps, L.vscode, L.browser, L.terminal, T.filesystem, T.git, T.devcmd, T.ollama, T.system, T.project]) reg.register(c);
  return reg;
}

module.exports = { createRegistry, ConnectorRegistry };
