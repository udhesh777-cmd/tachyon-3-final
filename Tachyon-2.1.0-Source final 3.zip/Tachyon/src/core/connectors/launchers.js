'use strict';
// Connectors that start programs: apps (File Explorer, user-configured apps), VS Code, Chrome / default browser, terminals (click only).
const path = require('path');
const U = require('./util');
const Computer = require('../computer');

const projectArg = { type: 'string', maxLength: 1000 };

/** Common verification for a launched GUI program: look for its window; say so honestly if that cannot be checked. */
async function verifyLaunch(ctx, label, procNames, info) {
  if (!ctx.listWindows) {
    return { status: 'unverified', evidence: `${label} was started (process ${info.pid}). Window checks are only available on Windows.` };
  }
  const w = await U.waitForWindow(ctx, procNames);
  if (w.found) return { status: 'verified', evidence: `${label} is open (window “${String(w.window.title).slice(0, 80)}”).` };
  if (info.exited && info.exitCode && info.exitCode !== 0) return { status: 'failed', evidence: `${label} exited immediately with code ${info.exitCode}.` };
  return { status: 'unverified', evidence: `${label} was started (process ${info.pid}), but no window showed up within a few seconds. It may still be starting.` };
}

const vscode = {
  id: 'vscode', label: 'Visual Studio Code',
  discoverCapabilities(ctx) {
    const exe = U.findVsCode(ctx);
    return exe ? { status: 'available', path: exe } : { status: 'not_installed', detail: 'Visual Studio Code was not found in the usual install folders.' };
  },
  operations: {
    open: {
      describe: 'Open Visual Studio Code, optionally on a folder or file inside a granted folder.',
      category: 'apps.open',
      schema: { type: 'object', additionalProperties: false, properties: { path: projectArg } },
      validate(args, ctx) {
        if (!U.findVsCode(ctx)) return { error: 'Visual Studio Code is not installed (Tachyon looked in the usual install folders). Install it from code.visualstudio.com.' };
        return args.path ? { args: { path: U.authorizedPath(ctx, args.path) } } : null;
      },
      describeTarget: (a) => 'Open Visual Studio Code' + (a.path ? ' on ' + a.path : ''),
      timeoutMs: 25000,
      async execute(a, ctx) {
        const exe = U.findVsCode(ctx);
        const info = await U.spawnDetached(ctx, exe, a.path ? [a.path] : []);
        return { app: 'Visual Studio Code', pid: info.pid, path: a.path || null, info };
      },
      observe: (a, r) => ({ app: r.app, pid: r.pid, path: r.path, info: r.info }),
      verify: (a, r, ctx) => verifyLaunch(ctx, 'Visual Studio Code', ['Code'], r.info),
    },
  },
};

const browser = {
  id: 'browser', label: 'Chrome / browser',
  discoverCapabilities(ctx) {
    const exe = U.findChrome(ctx);
    return exe ? { status: 'available', path: exe } : { status: 'available', detail: 'Chrome was not found; links open in your default browser.', fallback: 'default-browser' };
  },
  operations: {
    open: {
      describe: 'Open a web page (http or https only) in Chrome, or in the default browser when Chrome is not installed.',
      category: 'browser.open',
      schema: { type: 'object', additionalProperties: false, properties: { url: { type: 'string', minLength: 4, maxLength: 2000 } } },
      validate(args, ctx) {
        if (!args.url) return U.findChrome(ctx) ? null : { error: 'Chrome was not found. Give me a web address and I will open it in your default browser.' };
        let u;
        try { u = new URL(/^[a-z][a-z0-9+.-]*:/i.test(args.url) ? args.url : 'https://' + args.url); } catch { return { error: 'That is not a valid web address.' }; }
        if (u.protocol !== 'http:' && u.protocol !== 'https:') return { error: 'Only http and https addresses can be opened.' };
        if (u.username || u.password) return { error: 'Addresses that contain a user name or password are not opened.' };
        return { args: { url: u.toString() } };
      },
      describeTarget: (a) => (a.url ? 'Open ' + a.url : 'Open Google Chrome'),
      timeoutMs: 20000,
      async execute(a, ctx) {
        const exe = U.findChrome(ctx);
        if (exe) {
          const info = await U.spawnDetached(ctx, exe, a.url ? [a.url] : []);
          return { app: 'Google Chrome', url: a.url || null, pid: info.pid, info };
        }
        if (!ctx.openExternal || !a.url) throw new Error('No browser could be started.');
        await ctx.openExternal(a.url);
        return { app: 'default browser', url: a.url, info: null };
      },
      observe: (a, r) => r,
      async verify(a, r, ctx) {
        if (!r.info) return { status: 'unverified', evidence: 'The link was handed to your default browser; Tachyon cannot see whether it loaded.' };
        return verifyLaunch(ctx, 'Chrome', ['chrome'], r.info);
      },
    },
  },
};

const apps = {
  id: 'apps', label: 'Windows apps',
  discoverCapabilities: () => ({ status: 'available' }),
  operations: {
    openExplorer: {
      describe: 'Open File Explorer, optionally on a folder inside a granted folder.',
      category: 'files.open',
      schema: { type: 'object', additionalProperties: false, properties: { path: projectArg } },
      validate: (args, ctx) => (args.path ? { args: { path: U.authorizedPath(ctx, args.path) } } : null),
      describeTarget: (a) => 'Open File Explorer' + (a.path ? ' on ' + a.path : ''),
      async execute(a, ctx) {
        const dir = a.path || null;
        if (ctx.openPath) {
          const err = await ctx.openPath(dir || (ctx.env && ctx.env.USERPROFILE) || '');
          if (err) throw new Error(err);
          return { app: 'File Explorer', path: dir, info: null };
        }
        const exe = U.findExplorer(ctx);
        if (!exe) throw new Error('File Explorer is only available on Windows.');
        const info = await U.spawnDetached(ctx, exe, dir ? [dir] : []);
        return { app: 'File Explorer', path: dir, info };
      },
      async verify(a, r, ctx) {
        if (!ctx.listWindows) return { status: 'unverified', evidence: 'File Explorer was asked to open; window checks are only available on Windows.' };
        const w = await U.waitForWindow(ctx, ['explorer'], { timeoutMs: 5000 });
        return w.found ? { status: 'verified', evidence: `A File Explorer window is open (“${String(w.window.title).slice(0, 80)}”).` } : { status: 'unverified', evidence: 'The OS accepted the request, but no Explorer window was detected yet.' };
      },
    },
    launchCustom: {
      describe: 'Open an app the user added to the Applications panel.',
      category: 'apps.open',
      schema: { type: 'object', additionalProperties: false, required: ['id'], properties: { id: { type: 'string', pattern: '^[a-z0-9-]{1,40}$' }, path: projectArg } },
      validate(args, ctx) {
        const app = ((ctx.settings && ctx.settings().customApps) || []).find((x) => x.id === args.id);
        if (!app) return { error: 'That app is not in your Applications list.' };
        if (!U.isFile(ctx, app.path)) return { error: `“${app.name}” was not found at ${app.path}. Update its path in the Applications panel.` };
        if (Computer.blocked(path.basename(app.path)) || Computer.blocked(app.name)) return { error: 'Shells and system tools cannot be added as apps.' };
        return { args: { id: args.id, path: args.path ? U.authorizedPath(ctx, args.path) : undefined, _app: { name: app.name, exe: app.path } } };
      },
      describeTarget: (a) => `Open ${a._app ? a._app.name : 'app'}`,
      async execute(a, ctx) {
        const info = await U.spawnDetached(ctx, a._app.exe, a.path ? [a.path] : []);
        return { app: a._app.name, pid: info.pid, info, proc: path.basename(a._app.exe).replace(/\.exe$/i, '') };
      },
      verify: (a, r, ctx) => verifyLaunch(ctx, r.app, [r.proc], r.info),
    },
  },
};

// Shells open only when the user clicks their button in Applications (uiOnly): neither the chat nor a model can start them.
function terminalOp(kind) {
  const isWt = kind === 'windowsTerminal';
  return {
    uiOnly: true,
    describe: isWt ? 'Open Windows Terminal in a granted folder (button only).' : 'Open PowerShell in a granted folder (button only).',
    category: 'terminal.open',
    schema: { type: 'object', additionalProperties: false, required: ['cwd'], properties: { cwd: projectArg } },
    validate(args, ctx) {
      if (!U.isWin(ctx)) return { error: 'Terminals are launched from Tachyon on Windows only.' };
      if (isWt ? !U.findWindowsTerminal(ctx) : !U.findPowerShell(ctx)) return { error: isWt ? 'Windows Terminal is not installed. Install it from the Microsoft Store.' : 'PowerShell was not found.' };
      const dir = U.authorizedPath(ctx, args.cwd);
      if (!U.isDir(ctx, dir)) return { error: 'Choose a folder.' };
      return { args: { cwd: dir } };
    },
    describeTarget: (a) => `Open ${isWt ? 'Windows Terminal' : 'PowerShell'} in ${a.cwd}`,
    async execute(a, ctx) {
      let info;
      if (isWt) info = await U.spawnDetached(ctx, U.findWindowsTerminal(ctx), ['-d', a.cwd]);
      else info = await U.spawnDetached(ctx, 'cmd.exe', ['/d', '/c', 'start', '', U.findPowerShell(ctx), '-NoExit'], { cwd: a.cwd, windowsHide: true });
      return { app: isWt ? 'Windows Terminal' : 'PowerShell', cwd: a.cwd, info };
    },
    verify: (a, r, ctx) => verifyLaunch(ctx, r.app, isWt ? ['WindowsTerminal'] : ['powershell', 'pwsh'], r.info),
    timeoutMs: 20000,
  };
}
const terminal = {
  id: 'terminal', label: 'Terminals (click only)',
  discoverCapabilities(ctx) {
    if (!U.isWin(ctx)) return { status: 'unavailable', detail: 'Windows only.' };
    return { status: U.findPowerShell(ctx) || U.findWindowsTerminal(ctx) ? 'available' : 'not_installed', powershell: Boolean(U.findPowerShell(ctx)), windowsTerminal: Boolean(U.findWindowsTerminal(ctx)) };
  },
  operations: { openPowerShell: terminalOp('powershell'), openWindowsTerminal: terminalOp('windowsTerminal') },
};

module.exports = { vscode, browser, apps, terminal, verifyLaunch };
