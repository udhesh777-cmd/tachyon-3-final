'use strict';
// Connector registry: the single door through which Tachyon (the UI, the chat or a local model) acts on this computer.
//
// Every action goes through the same pipeline:
//   validateAction  -> schema + connector rules (paths must be inside granted folders, URLs must be http/https, ...)
//   permission      -> Settings → Permissions category (a native dialog for "ask")
//   executeAction   -> runs with a timeout and an AbortSignal (cancelAction aborts it)
//   observeResult   -> what happened, in plain data
//   verifyOutcome   -> checks the outcome where that is practical, and says honestly when it cannot
// The model may only choose from registered operations; anything else is rejected before it reaches a connector.
const crypto = require('crypto');
const { validate } = require('./schema');

const STATES = ['planned', 'awaiting_approval', 'running', 'completed', 'failed', 'cancelled', 'partial'];

class ActionError extends Error {
  constructor(message, state = 'failed') { super(message); this.state = state; }
}

class ConnectorRegistry {
  /**
   * ctx: { guard(category, target) -> Promise (throws when refused), log(record) , now(), emit(record) }
   * plus anything connectors need (platform, env, fs, spawn, roots(), settings() ...).
   */
  constructor(ctx = {}) {
    this.ctx = ctx;
    this.connectors = new Map();
    this.running = new Map(); // record id -> AbortController
  }

  register(c) {
    if (!c || !/^[a-z][a-z0-9-]*$/.test(c.id || '')) throw new Error('A connector needs a lowercase id.');
    if (this.connectors.has(c.id)) throw new Error(`Connector “${c.id}” is already registered.`);
    if (!c.operations || !Object.keys(c.operations).length) throw new Error(`Connector “${c.id}” has no operations.`);
    for (const [name, op] of Object.entries(c.operations)) {
      if (typeof op.execute !== 'function') throw new Error(`${c.id}.${name} has no execute().`);
      if (!op.schema || op.schema.type !== 'object') throw new Error(`${c.id}.${name} needs an object schema.`);
      if (!op.category) throw new Error(`${c.id}.${name} needs a permission category.`);
    }
    this.connectors.set(c.id, c);
    return c;
  }

  get(id) { return this.connectors.get(id); }

  /** The operations a model or the UI may ask for (UI-only operations are listed for the UI but flagged). */
  catalog({ forModel = false } = {}) {
    const out = [];
    for (const c of this.connectors.values()) {
      for (const [name, op] of Object.entries(c.operations)) {
        if (forModel && op.uiOnly) continue;
        out.push({ connector: c.id, op: name, describe: op.describe || '', schema: op.schema, category: op.category, uiOnly: Boolean(op.uiOnly) });
      }
    }
    return out;
  }

  /** What each connector can do right now (installed? permitted?). Never throws. */
  async discoverCapabilities() {
    const out = [];
    for (const c of this.connectors.values()) {
      let cap;
      try { cap = c.discoverCapabilities ? await c.discoverCapabilities(this.ctx) : { status: 'available' }; } catch (e) { cap = { status: 'unavailable', detail: e.message }; }
      out.push({ id: c.id, label: c.label || c.id, status: 'available', ...cap, operations: Object.keys(c.operations) });
    }
    return out;
  }

  /** Returns { ok, args, errors }. Unknown connectors/operations and invalid arguments never reach execute(). */
  async validateAction(connector, opName, args, { source = 'ui' } = {}) {
    const c = this.connectors.get(connector);
    if (!c) return { ok: false, errors: [`Unknown connector “${connector}”.`] };
    const op = Object.prototype.hasOwnProperty.call(c.operations, opName) ? c.operations[opName] : null;
    if (!op) return { ok: false, errors: [`“${connector}” has no operation “${opName}”.`] };
    if (op.uiOnly && source !== 'ui') {
      return { ok: false, errors: [`“${connector}.${opName}” can only be started by clicking its button in Tachyon — the chat and the AI cannot start it.`] };
    }
    const input = args == null ? {} : args;
    const errors = validate(op.schema, input);
    if (errors.length) return { ok: false, errors };
    if (op.validate) {
      try {
        const r = await op.validate(input, this.ctx);
        if (r && r.error) return { ok: false, errors: [r.error] };
        if (r && r.args) return { ok: true, args: r.args, op };
      } catch (e) { return { ok: false, errors: [e.message] }; }
    }
    return { ok: true, args: input, op };
  }

  /**
   * Runs one action through the whole pipeline and returns the final activity record
   * { id, ts, connector, op, label, source, state, steps[], args, result, verification, error, durationMs }.
   */
  async execute({ connector, op: opName, args, source = 'ui', label } = {}) {
    const now = this.ctx.now || Date.now;
    const rec = {
      id: crypto.randomBytes(6).toString('hex'), ts: now(), connector, op: opName, label: label || `${connector}.${opName}`,
      source, state: 'planned', steps: [], args: summarize(args), result: null, verification: null, error: null,
    };
    const step = (state, note) => { rec.state = state; rec.steps.push({ state, note: note || '', ts: now() }); this._emit(rec); };
    step('planned', 'Request received');
    const v = await this.validateAction(connector, opName, args, { source });
    if (!v.ok) { rec.error = v.errors.join(' '); step('failed', 'Rejected before running: ' + rec.error); return this._finish(rec, now); }
    const op = v.op;
    const target = op.describeTarget ? op.describeTarget(v.args, this.ctx) : `${connector}.${opName}`;
    rec.target = String(target).slice(0, 500);
    const ac = new AbortController();
    this.running.set(rec.id, ac);
    try {
      step('awaiting_approval', `Checking permission: ${op.category}`);
      if (this.ctx.guard) await this.ctx.guard(op.category, rec.target);
      if (ac.signal.aborted) throw new ActionError('Cancelled before it started.', 'cancelled');
      step('running', 'Started');
      const result = await withTimeout((signal) => op.execute(v.args, this.ctx, { signal, record: rec }), op.timeoutMs || 30000, ac);
      rec.result = op.observe ? await op.observe(v.args, result, this.ctx) : result;
      let ver = { status: 'unverified', evidence: 'This action has no automatic check.' };
      if (op.verify) {
        try { ver = await op.verify(v.args, rec.result, this.ctx, { signal: ac.signal }); } catch (e) { ver = { status: 'unverified', evidence: 'The check itself failed: ' + e.message }; }
      }
      rec.verification = ver;
      const partial = rec.result && rec.result.partial;
      step(partial ? 'partial' : ver.status === 'failed' ? 'failed' : 'completed', ver.evidence || '');
      if (ver.status === 'failed') rec.error = ver.evidence;
    } catch (e) {
      const cancelled = e.state === 'cancelled' || (!e.state && ac.signal.aborted) || /^Cancelled/.test(e.message);
      rec.error = e.message;
      step(cancelled ? 'cancelled' : 'failed', e.message);
    } finally { this.running.delete(rec.id); }
    return this._finish(rec, now);
  }

  /** Aborts a running action. Returns true when something was running. */
  cancelAction(id) {
    const ac = this.running.get(id);
    if (!ac) return false;
    ac.abort();
    return true;
  }

  _emit(rec) { if (this.ctx.emit) { try { this.ctx.emit(JSON.parse(JSON.stringify(rec))); } catch { /* ui gone */ } } }
  _finish(rec, now) {
    rec.durationMs = now() - rec.ts;
    if (this.ctx.log) { try { this.ctx.log(rec); } catch { /* logging must not break actions */ } }
    return rec;
  }
}

function summarize(args) {
  try { return JSON.parse(JSON.stringify(args == null ? {} : args, (k, v) => (typeof v === 'string' && v.length > 300 ? v.slice(0, 300) + '…' : v))); } catch { return {}; }
}

function withTimeout(fn, ms, ac) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { ac.signal.removeEventListener('abort', onAbort); reject(new ActionError(`Timed out after ${Math.round(ms / 1000)} s.`, 'failed')); ac.abort(); }, ms);
    const onAbort = () => { clearTimeout(timer); reject(new ActionError('Cancelled.', 'cancelled')); };
    ac.signal.addEventListener('abort', onAbort, { once: true });
    Promise.resolve().then(() => fn(ac.signal)).then(
      (r) => { clearTimeout(timer); ac.signal.removeEventListener('abort', onAbort); resolve(r); },
      (e) => { clearTimeout(timer); ac.signal.removeEventListener('abort', onAbort); reject(e); });
  });
}

module.exports = { ConnectorRegistry, ActionError, STATES };
