'use strict';
// Approved-command runner. There is no shell and no free text: only the commands in this allowlist can run,
// each with fixed arguments, inside a folder the user granted, with a timeout and capped output.
const path = require('path');
const nodeFs = require('fs');
const { spawn: nodeSpawn, execFile } = require('child_process');
const U = require('./util');

const MAX_OUT = 200_000; // bytes kept per stream

/** id -> how to run it. `finder` locates the program; `args(ctx)` builds the fixed argument list. */
const COMMANDS = {
  'git.status': { label: 'git status', group: 'read', finder: U.findGit, args: () => ['-c', 'core.fsmonitor=false', 'status', '--short', '--branch'], timeoutMs: 20000 },
  'git.branch': { label: 'git branch', group: 'read', finder: U.findGit, args: () => ['-c', 'core.fsmonitor=false', 'branch', '--show-current'], timeoutMs: 15000 },
  'git.log': { label: 'git log (last 20)', group: 'read', finder: U.findGit, args: () => ['-c', 'core.fsmonitor=false', 'log', '--oneline', '--decorate', '-n', '20'], timeoutMs: 20000 },
  'git.diffStat': { label: 'git diff --stat', group: 'read', finder: U.findGit, args: () => ['-c', 'core.fsmonitor=false', 'diff', '--stat'], timeoutMs: 30000 },
  'python.version': { label: 'python --version', group: 'read', finder: U.findPython, args: () => ['--version'], timeoutMs: 15000 },
  'node.version': { label: 'node --version', group: 'read', finder: U.findNode, args: () => ['--version'], timeoutMs: 15000 },
  'npm.version': { label: 'npm --version', group: 'read', finder: U.findNpmCli, viaNode: true, args: () => ['--version'], timeoutMs: 20000 },
  // These start code that lives in the project, so every run needs the user's confirmation.
  'npm.test': { label: 'npm test', group: 'run', finder: U.findNpmCli, viaNode: true, args: () => ['test'], timeoutMs: 300000, needsFile: 'package.json' },
  'python.pytest': { label: 'python -m pytest -q', group: 'run', finder: U.findPython, args: () => ['-m', 'pytest', '-q'], timeoutMs: 300000 },
  'python.unittest': { label: 'python -m unittest discover', group: 'run', finder: U.findPython, args: () => ['-m', 'unittest', 'discover'], timeoutMs: 300000 },
};

// Only these variables reach a command; tokens, API keys and the like in the environment do not.
const ENV_KEEP = ['PATH', 'Path', 'PATHEXT', 'SystemRoot', 'windir', 'SYSTEMDRIVE', 'TEMP', 'TMP', 'TMPDIR', 'USERPROFILE', 'HOME', 'HOMEDRIVE', 'HOMEPATH', 'APPDATA', 'LOCALAPPDATA',
  'ProgramData', 'ProgramFiles', 'ProgramFiles(x86)', 'ProgramW6432', 'COMSPEC', 'LANG', 'LC_ALL', 'NUMBER_OF_PROCESSORS', 'OS', 'PROCESSOR_ARCHITECTURE'];
function cleanEnv(src) {
  const out = {};
  for (const k of ENV_KEEP) if (src[k] != null) out[k] = src[k];
  out.GIT_TERMINAL_PROMPT = '0';
  out.GIT_OPTIONAL_LOCKS = '0';
  out.NoDefaultCurrentDirectoryInExePath = '1';
  out.CI = '1';
  out.NO_COLOR = '1';
  return out;
}

function list(ctx) {
  return Object.entries(COMMANDS).map(([id, c]) => ({ id, label: c.label, group: c.group, installed: Boolean(c.finder(ctx)) }));
}

function killTree(ctx, child) {
  try {
    if (U.isWin(ctx) && child.pid) execFile('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true }, () => {});
    else child.kill('SIGKILL');
  } catch { /* already gone */ }
}

/**
 * Runs one allowlisted command. Resolves with { exitCode, stdout, stderr, truncated, timedOut, cancelled, durationMs, command }.
 * Never rejects for a non-zero exit code; rejects only for things that stop it from starting.
 */
function runCommand(ctx, id, cwd, opts = {}) {
  try { return runChecked(ctx, id, cwd, opts); } catch (e) { return Promise.reject(e); }
}

function runChecked(ctx, id, cwd, { signal, timeoutMs } = {}) {
  const spec = Object.prototype.hasOwnProperty.call(COMMANDS, id) ? COMMANDS[id] : null;
  if (!spec) return Promise.reject(new Error(`“${id}” is not an approved command.`));
  const dir = U.authorizedPath(ctx, cwd);
  if (!U.isDir(ctx, dir)) return Promise.reject(new Error('The working folder must be a folder.'));
  if (spec.needsFile && !U.isFile(ctx, path.join(dir, spec.needsFile))) return Promise.reject(new Error(`No ${spec.needsFile} in this folder, so ${spec.label} cannot run here.`));
  const exe = spec.finder(ctx);
  if (!exe) return Promise.reject(new Error(`${spec.label.split(' ')[0]} is not installed (or Tachyon could not find it). Install it, then try again.`));
  const file = spec.viaNode ? U.findNode(ctx) : exe;
  const args = (spec.viaNode ? [exe] : []).concat(spec.args(ctx));
  const spawn = ctx.spawn || nodeSpawn;
  const limit = timeoutMs || spec.timeoutMs || 60000;
  const t0 = Date.now();
  return new Promise((resolve, reject) => {
    let child;
    try { child = spawn(file, args, { cwd: dir, env: cleanEnv(U.envOf(ctx)), shell: false, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] }); } catch (e) { reject(e); return; }
    const res = { command: spec.label, id, cwd: dir, exitCode: null, stdout: '', stderr: '', truncated: false, timedOut: false, cancelled: false };
    const take = (key) => (buf) => {
      if (res[key].length >= MAX_OUT) { res.truncated = true; return; }
      res[key] += buf.toString('utf8');
      if (res[key].length > MAX_OUT) { res[key] = res[key].slice(0, MAX_OUT); res.truncated = true; }
    };
    if (child.stdout) child.stdout.on('data', take('stdout'));
    if (child.stderr) child.stderr.on('data', take('stderr'));
    const timer = setTimeout(() => { res.timedOut = true; killTree(ctx, child); }, limit);
    const onAbort = () => { res.cancelled = true; killTree(ctx, child); };
    if (signal) { if (signal.aborted) onAbort(); else signal.addEventListener('abort', onAbort, { once: true }); }
    child.once('error', (e) => { clearTimeout(timer); reject(new Error(`Could not start ${spec.label}: ${e.message}`)); });
    child.once('close', (code) => {
      clearTimeout(timer);
      if (signal) signal.removeEventListener('abort', onAbort);
      res.exitCode = code;
      res.durationMs = Date.now() - t0;
      resolve(res);
    });
  });
}

/** Last N command runs, kept on this computer only (summaries, not full output). */
class RunHistory {
  constructor(dir, fsx = nodeFs) { this.file = path.join(dir, 'command-history.jsonl'); this.fs = fsx; }
  add(r) {
    const row = { ts: Date.now(), id: r.id, command: r.command, cwd: r.cwd, exitCode: r.exitCode, durationMs: r.durationMs, timedOut: r.timedOut, cancelled: r.cancelled, truncated: r.truncated,
      output: (String(r.stdout || '') + (r.stderr ? '\n' + r.stderr : '')).slice(0, 4000) };
    try { this.fs.appendFileSync(this.file, JSON.stringify(row) + '\n', 'utf8'); } catch { /* best effort */ }
    return row;
  }
  list(limit = 50) {
    let lines = [];
    try { lines = this.fs.readFileSync(this.file, 'utf8').split('\n').filter(Boolean); } catch { return []; }
    return lines.slice(-limit).reverse().map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  }
  clear() { try { this.fs.unlinkSync(this.file); } catch { /* none */ } }
}

module.exports = { COMMANDS, MAX_OUT, ENV_KEEP, cleanEnv, list, runCommand, RunHistory };
