'use strict';
// A small JSON-schema subset used to validate every action before it can run.
// Supported: type (string|integer|number|boolean|array|object), required, enum, minLength, maxLength, pattern,
// minimum, maximum, items, maxItems, properties, additionalProperties:false.

function validate(schema, value, at = 'args') {
  const errors = [];
  walk(schema, value, at, errors);
  return errors;
}

function typeOf(v) {
  if (v === null) return 'null';
  if (Array.isArray(v)) return 'array';
  return typeof v;
}

function walk(s, v, at, errors) {
  if (!s) return;
  const t = typeOf(v);
  if (s.type) {
    const ok = s.type === 'integer' ? Number.isInteger(v) : s.type === 'number' ? (t === 'number' && Number.isFinite(v)) : t === s.type;
    if (!ok) { errors.push(`${at} must be ${s.type}`); return; }
  }
  if (s.enum && !s.enum.includes(v)) errors.push(`${at} must be one of: ${s.enum.join(', ')}`);
  if (t === 'string') {
    if (s.minLength != null && v.length < s.minLength) errors.push(`${at} is too short`);
    if (s.maxLength != null && v.length > s.maxLength) errors.push(`${at} is too long (max ${s.maxLength})`);
    if (s.pattern && !new RegExp(s.pattern).test(v)) errors.push(`${at} has an invalid format`);
    if (v.includes('\0')) errors.push(`${at} contains an invalid character`);
  }
  if (t === 'number') {
    if (s.minimum != null && v < s.minimum) errors.push(`${at} must be at least ${s.minimum}`);
    if (s.maximum != null && v > s.maximum) errors.push(`${at} must be at most ${s.maximum}`);
  }
  if (t === 'array') {
    if (s.maxItems != null && v.length > s.maxItems) errors.push(`${at} has too many items`);
    if (s.items) v.forEach((x, i) => walk(s.items, x, `${at}[${i}]`, errors));
  }
  if (t === 'object' && (s.properties || s.required || s.additionalProperties === false)) {
    for (const k of s.required || []) if (!(k in v) || v[k] === undefined) errors.push(`${at}.${k} is required`);
    for (const [k, x] of Object.entries(v)) {
      if (s.properties && s.properties[k]) walk(s.properties[k], x, `${at}.${k}`, errors);
      else if (s.additionalProperties === false) errors.push(`${at}.${k} is not allowed`);
    }
  }
}

module.exports = { validate };
