'use strict';
// Connectors that read things: Git and approved developer commands, the local Ollama server, granted folders, hardware, project inspection.
const os = require('os');
const path = require('path');
const U = require('./util');
const R = require('./runner');

const cwdSchema = { type: 'string', minLength: 1, maxLength: 1000 };

function runnerOp(ids, { category, describe, kind }) {
  return {
    describe, category,
    schema: { type: 'object', additionalProperties: false, required: ['command', 'cwd'], properties: { command: { type: 'string', enum: ids }, cwd: cwdSchema } },
    validate: (args, ctx) => ({ args: { command: args.command, cwd: U.authorizedPath(ctx, args.cwd) } }),
    describeTarget: (a) => `${R.COMMANDS[a.command].label}\nin ${a.cwd}` + (kind === 'run' ? '\n\nThis starts code that belongs to the project.' : ''),
    timeoutMs: 310000,
    execute: (a, ctx, { signal }) => R.runCommand(ctx, a.command, a.cwd, { signal }),
    observe(a, r, ctx) { if (ctx.history) ctx.history.add(r); return r; },
    verify(a, r) {
      if (r.cancelled) return { status: 'failed', evidence: 'Cancelled.' };
      if (r.timedOut) return { status: 'failed', evidence: `${r.command} timed out and was stopped.` };
      if (r.exitCode === 0) return { status: 'verified', evidence: `${r.command} finished with exit code 0 in ${(r.durationMs / 1000).toFixed(1)} s.` };
      const first = (r.stderr || r.stdout || '').split('\n').find((l) => l.trim()) || '';
      return { status: 'failed', evidence: `${r.command} exited with code ${r.exitCode}.${first ? ' ' + first.slice(0, 160) : ''}` };
    },
  };
}

const gitIds = ['git.status', 'git.branch', 'git.log', 'git.diffStat'];
const git = {
  id: 'git', label: 'Git',
  discoverCapabilities(ctx) { const g = U.findGit(ctx); return g ? { status: 'available', path: g, detail: 'Read-only: status, branch, log, diff summary.' } : { status: 'not_installed', detail: 'Git was not found.' }; },
  operations: { read: runnerOp(gitIds, { category: 'commands.read', describe: 'Run a read-only git command (status, branch, log, diff --stat) in a granted project folder.', kind: 'read' }) },
};

const devcmd = {
  id: 'devcmd', label: 'Developer commands',
  discoverCapabilities(ctx) {
    const have = R.list(ctx).filter((c) => !c.id.startsWith('git.'));
    return { status: have.some((c) => c.installed) ? 'available' : 'not_installed', commands: have };
  },
  operations: {
    version: runnerOp(['python.version', 'node.version', 'npm.version'], { category: 'commands.read', describe: 'Show the installed version of Python, Node.js or npm.', kind: 'read' }),
    test: runnerOp(['npm.test', 'python.pytest', 'python.unittest'], { category: 'commands.run', describe: 'Run the project’s tests (npm test, pytest or unittest). Always asks first because it starts project code.', kind: 'run' }),
  },
};

// ---- Ollama ---------------------------------------------------------------------------------
const EMBED_RE = /embed|bge-|minilm|nomic|(^|[-_:/])e5-|gte-|arctic-embed|mxbai/i;
const VISION_RE = /vl([-_:.]|$)|llava|vision|minicpm-v|moondream|bakllava|pixtral|granite3.2-vision|gemma3/i;
function classifyModel(m) {
  const name = m.name || m.model || '';
  const fam = (m.details && m.details.families) || [];
  if (EMBED_RE.test(name)) return 'embedding';
  if (fam.includes('clip') || fam.includes('mllama') || VISION_RE.test(name)) return 'vision';
  return 'text';
}
const ollama = {
  id: 'ollama', label: 'Ollama (local AI)',
  async discoverCapabilities(ctx) { const base = ctx.ollamaBase && ctx.ollamaBase(); return base ? { status: 'available', detail: base } : { status: 'unavailable', detail: 'No local Ollama model is configured.' }; },
  operations: {
    status: {
      describe: 'Check whether the local Ollama server is running and list the models installed on it. Never downloads anything.',
      category: 'status',
      schema: { type: 'object', additionalProperties: false, properties: {} },
      timeoutMs: 8000,
      async execute(a, ctx, { signal }) {
        const base = (ctx.ollamaBase && ctx.ollamaBase()) || 'http://127.0.0.1:11434';
        const f = ctx.fetch || globalThis.fetch;
        try {
          const res = await f(base.replace(/\/$/, '') + '/api/tags', { signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(4000)]) : AbortSignal.timeout(4000) });
          if (!res.ok) return { running: false, base, models: [], error: `Ollama answered ${res.status}.` };
          const j = await res.json();
          const models = (j.models || []).map((m) => ({ name: m.name || m.model, kind: classifyModel(m), sizeGB: m.size ? Math.round(m.size / 1e8) / 10 : null }));
          return { running: true, base, models };
        } catch (e) {
          if (signal && signal.aborted) throw e;
          return { running: false, base, models: [], error: 'Ollama is not running at ' + base + '. Start Ollama, then try again.' };
        }
      },
      verify: (a, r) => (r.running ? { status: 'verified', evidence: `Ollama is running with ${r.models.length} model(s).` } : { status: 'failed', evidence: r.error }),
    },
  },
};

// ---- Files ----------------------------------------------------------------------------------
const MAX_READ = 200000;
const filesystem = {
  id: 'filesystem', label: 'Files and folders',
  discoverCapabilities: (ctx) => { const n = ctx.roots ? ctx.roots().length : 0; return n ? { status: 'available', detail: `${n} granted folder(s)` } : { status: 'needs_permission', detail: 'Add a folder in Files & PDFs to grant access.' }; },
  operations: {
    list: {
      describe: 'List files and folders inside a granted folder.',
      category: 'files.read',
      schema: { type: 'object', additionalProperties: false, required: ['path'], properties: { path: cwdSchema } },
      validate: (a, ctx) => ({ args: { path: U.authorizedPath(ctx, a.path) } }),
      describeTarget: (a) => 'List ' + a.path,
      execute(a, ctx) {
        const fsx = U.fsOf(ctx);
        const items = fsx.readdirSync(a.path, { withFileTypes: true }).slice(0, 500).map((d) => {
          let size = null; try { if (d.isFile()) size = fsx.statSync(path.join(a.path, d.name)).size; } catch { /* skip */ }
          return { name: d.name, dir: d.isDirectory(), size };
        });
        return { path: a.path, items };
      },
      verify: (a, r) => ({ status: 'verified', evidence: `${r.items.length} entr${r.items.length === 1 ? 'y' : 'ies'} read.` }),
    },
    read: {
      describe: 'Read a text file inside a granted folder (up to 200 KB).',
      category: 'files.read',
      schema: { type: 'object', additionalProperties: false, required: ['path'], properties: { path: cwdSchema, maxBytes: { type: 'integer', minimum: 1, maximum: MAX_READ } } },
      validate(a, ctx) {
        const p = U.authorizedPath(ctx, a.path);
        if (!U.isFile(ctx, p)) return { error: 'That is not a file.' };
        return { args: { path: p, maxBytes: a.maxBytes || MAX_READ } };
      },
      describeTarget: (a) => 'Read ' + a.path,
      execute(a, ctx) {
        const buf = U.fsOf(ctx).readFileSync(a.path);
        if (buf.subarray(0, 4000).includes(0)) throw new Error('This looks like a binary file, not text.');
        return { path: a.path, text: buf.subarray(0, a.maxBytes).toString('utf8'), truncated: buf.length > a.maxBytes, bytes: buf.length };
      },
      verify: (a, r) => ({ status: 'verified', evidence: `${r.bytes} bytes read${r.truncated ? ' (shortened)' : ''}.` }),
    },
  },
};

// ---- System ---------------------------------------------------------------------------------
const system = {
  id: 'system', label: 'This computer',
  discoverCapabilities: () => ({ status: 'available' }),
  operations: {
    info: {
      describe: 'Read basic hardware information (CPU count, memory) to help choose a suitable local model.',
      category: 'status',
      schema: { type: 'object', additionalProperties: false, properties: {} },
      execute: (a, ctx) => {
        const o = ctx.os || os;
        const gb = (n) => Math.round((n / 1073741824) * 10) / 10;
        return { platform: o.platform(), release: o.release(), arch: o.arch(), cpus: o.cpus().length, cpuModel: (o.cpus()[0] || {}).model || '', totalMemGB: gb(o.totalmem()), freeMemGB: gb(o.freemem()), gpu: 'not detected by Tachyon' };
      },
      verify: () => ({ status: 'verified', evidence: 'Read from the operating system.' }),
    },
  },
};

// ---- Project inspection ----------------------------------------------------------------------
const project = {
  id: 'project', label: 'Project workspace',
  discoverCapabilities: (ctx) => ({ status: ctx.roots && ctx.roots().length ? 'available' : 'needs_permission', detail: 'Reads package.json, README and folder layout.' }),
  operations: {
    inspect: {
      describe: 'Summarize a project folder: type, scripts, git repository, README, top-level files.',
      category: 'files.read',
      schema: { type: 'object', additionalProperties: false, required: ['path'], properties: { path: cwdSchema } },
      validate(a, ctx) { const p = U.authorizedPath(ctx, a.path); return U.isDir(ctx, p) ? { args: { path: p } } : { error: 'Choose a folder.' }; },
      describeTarget: (a) => 'Inspect project ' + a.path,
      execute(a, ctx) {
        const fsx = U.fsOf(ctx);
        let names = [];
        try { names = fsx.readdirSync(a.path, { withFileTypes: true }); } catch (e) { throw new Error('The folder cannot be read: ' + e.message); }
        const has = (n) => names.some((d) => d.name.toLowerCase() === n.toLowerCase());
        const out = { path: a.path, name: path.basename(a.path), kinds: [], scripts: {}, git: has('.git'), readme: names.find((d) => /^readme(\.|$)/i.test(d.name))?.name || null, files: names.filter((d) => !d.name.startsWith('.')).slice(0, 60).map((d) => (d.isDirectory() ? d.name + '/' : d.name)) };
        if (has('package.json')) {
          out.kinds.push('Node.js');
          try {
            const pkg = JSON.parse(fsx.readFileSync(path.join(a.path, 'package.json'), 'utf8'));
            out.packageName = pkg.name; out.packageVersion = pkg.version;
            out.scripts = Object.fromEntries(Object.entries(pkg.scripts || {}).slice(0, 30).map(([k, v]) => [k, String(v).slice(0, 200)]));
            out.hasTestScript = Boolean(pkg.scripts && pkg.scripts.test);
          } catch { out.packageError = 'package.json could not be parsed.'; }
        }
        if (has('pyproject.toml') || has('requirements.txt') || has('setup.py')) out.kinds.push('Python');
        if (names.some((d) => /\.sln$|\.csproj$/i.test(d.name))) out.kinds.push('.NET');
        if (has('Cargo.toml')) out.kinds.push('Rust');
        if (has('go.mod')) out.kinds.push('Go');
        return out;
      },
      verify: (a, r) => ({ status: 'verified', evidence: `Read ${r.files.length} entries${r.kinds.length ? ' — ' + r.kinds.join(', ') : ''}.` }),
    },
  },
};

module.exports = { git, devcmd, ollama, filesystem, system, project, classifyModel };
