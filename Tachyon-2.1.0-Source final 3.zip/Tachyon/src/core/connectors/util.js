'use strict';
// Shared helpers for connectors: finding installed programs without a shell, path authorization, detached launching.
const nodeFs = require('fs');
const path = require('path');
const { spawn: nodeSpawn } = require('child_process');

const isWin = (ctx) => (ctx.platform || process.platform) === 'win32';
const envOf = (ctx) => ctx.env || process.env;
const fsOf = (ctx) => ctx.fs || nodeFs;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function isFile(ctx, p) { try { return fsOf(ctx).statSync(p).isFile(); } catch { return false; } }
function isDir(ctx, p) { try { return fsOf(ctx).statSync(p).isDirectory(); } catch { return false; } }

/** First existing file out of the candidate paths (undefined entries from missing env variables are skipped). */
function firstFile(ctx, list) { return list.filter(Boolean).find((p) => isFile(ctx, p)) || null; }

/** Looks a program up on PATH without running anything. Windows: .exe/.com only (never .bat/.cmd/.ps1). */
function which(ctx, name) {
  const env = envOf(ctx);
  const win = isWin(ctx);
  // PATH entries are separated by the HOST's separator (';' on a Windows computer, ':' elsewhere), even when a test pretends the platform is 'linux'.
  const sep = (win || process.platform === 'win32') ? ';' : ':';
  const pathVar = env.PATH || env.Path || '';
  const exts = win ? ['.exe', '.com'] : [''];
  for (const dir of pathVar.split(sep).filter(Boolean)) {
    for (const e of exts) {
      const p = path.join(dir.replace(/^"|"$/g, ''), name + e);
      if (isFile(ctx, p)) return p;
    }
  }
  return null;
}

/** Where installed programs normally live on this computer (built only from environment variables, never from fixed user names). */
function winRoots(ctx) {
  const e = envOf(ctx);
  return { local: e.LOCALAPPDATA, pf: e.ProgramFiles, pf86: e['ProgramFiles(x86)'], win: e.SystemRoot || e.windir };
}

const J = (ctx, ...parts) => (isWin(ctx) ? path.win32.join(...parts) : path.join(...parts));

function findVsCode(ctx) {
  if (isWin(ctx)) {
    const r = winRoots(ctx);
    return firstFile(ctx, [r.local && J(ctx, r.local, 'Programs', 'Microsoft VS Code', 'Code.exe'), r.pf && J(ctx, r.pf, 'Microsoft VS Code', 'Code.exe'), r.pf86 && J(ctx, r.pf86, 'Microsoft VS Code', 'Code.exe')]);
  }
  return which(ctx, 'code');
}
function findChrome(ctx) {
  if (isWin(ctx)) {
    const r = winRoots(ctx);
    return firstFile(ctx, [r.pf && J(ctx, r.pf, 'Google', 'Chrome', 'Application', 'chrome.exe'), r.pf86 && J(ctx, r.pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'), r.local && J(ctx, r.local, 'Google', 'Chrome', 'Application', 'chrome.exe')]);
  }
  return which(ctx, 'google-chrome') || which(ctx, 'chromium') || which(ctx, 'chrome');
}
function findGit(ctx) {
  if (isWin(ctx)) {
    const r = winRoots(ctx);
    return firstFile(ctx, [r.pf && J(ctx, r.pf, 'Git', 'cmd', 'git.exe'), r.pf86 && J(ctx, r.pf86, 'Git', 'cmd', 'git.exe'), r.local && J(ctx, r.local, 'Programs', 'Git', 'cmd', 'git.exe')]) || which(ctx, 'git');
  }
  return which(ctx, 'git');
}
function findPython(ctx) {
  if (isWin(ctx)) {
    const r = winRoots(ctx);
    const found = [];
    if (r.local) {
      const base = J(ctx, r.local, 'Programs', 'Python');
      try { for (const d of fsOf(ctx).readdirSync(base).sort().reverse()) if (/^Python\d+/i.test(d)) found.push(J(ctx, base, d, 'python.exe')); } catch { /* none */ }
    }
    return firstFile(ctx, found) || which(ctx, 'python') || (r.win && firstFile(ctx, [J(ctx, r.win, 'py.exe')])) || which(ctx, 'py');
  }
  return which(ctx, 'python3') || which(ctx, 'python');
}
function findNode(ctx) {
  if (isWin(ctx)) {
    const r = winRoots(ctx);
    return firstFile(ctx, [r.pf && J(ctx, r.pf, 'nodejs', 'node.exe'), r.pf86 && J(ctx, r.pf86, 'nodejs', 'node.exe')]) || which(ctx, 'node');
  }
  return which(ctx, 'node');
}
/** npm is a .cmd file on Windows, which cannot be started without a shell. Run its JavaScript entry point with node instead. */
function findNpmCli(ctx) {
  const node = findNode(ctx);
  if (!node) return null;
  const dir = (isWin(ctx) ? path.win32 : path).dirname(node);
  return firstFile(ctx, [J(ctx, dir, 'node_modules', 'npm', 'bin', 'npm-cli.js'), J(ctx, dir, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js')]);
}
function findWindowsTerminal(ctx) {
  const r = winRoots(ctx);
  return isWin(ctx) ? firstFile(ctx, [r.local && J(ctx, r.local, 'Microsoft', 'WindowsApps', 'wt.exe')]) : null;
}
function findPowerShell(ctx) {
  if (!isWin(ctx)) return null;
  const r = winRoots(ctx);
  return firstFile(ctx, [r.win && J(ctx, r.win, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')]);
}
function findExplorer(ctx) {
  if (!isWin(ctx)) return null;
  const r = winRoots(ctx);
  return firstFile(ctx, [r.win && J(ctx, r.win, 'explorer.exe')]);
}

/** Is `target` the same as, or inside, one of the granted folders? Resolves links so a shortcut cannot escape. */
function authorizedPath(ctx, target, { mustExist = true } = {}) {
  const fsx = fsOf(ctx);
  if (typeof target !== 'string' || !target.trim()) throw new Error('A path is required.');
  const win = isWin(ctx);
  const P = win ? path.win32 : path;
  if (!P.isAbsolute(target)) throw new Error('Use a full path inside a folder you granted to Tachyon.');
  let real = P.resolve(target);
  try { real = fsx.realpathSync(real); } catch { if (mustExist) throw new Error('That path does not exist.'); }
  const norm = (p) => { const r = P.resolve(p); return win ? r.toLowerCase() : r; };
  const t = norm(real);
  for (const root of (ctx.roots ? ctx.roots() : [])) {
    let rr = root;
    try { rr = fsx.realpathSync(root); } catch { /* use as is */ }
    const r = norm(rr);
    if (t === r || t.startsWith(r.endsWith(P.sep) ? r : r + P.sep)) return real;
  }
  throw new Error('That path is not inside a folder you granted to Tachyon. Add the folder in Files & PDFs first.');
}

/** Starts a program detached (no shell, arguments passed as an array). Resolves once the OS has created the process. */
function spawnDetached(ctx, exe, args = [], { cwd, windowsHide = false } = {}) {
  const spawn = ctx.spawn || nodeSpawn;
  return new Promise((resolve, reject) => {
    let child;
    try { child = spawn(exe, args, { cwd, detached: true, stdio: 'ignore', shell: false, windowsHide }); } catch (e) { reject(e); return; }
    const info = { pid: child.pid, exited: false, exitCode: null };
    child.once('error', (e) => reject(new Error(`Could not start ${path.basename(exe)}: ${e.message}`)));
    child.once('exit', (code) => { info.exited = true; info.exitCode = code; });
    child.once('spawn', () => { if (child.unref) child.unref(); resolve(info); });
  });
}

/** Polls the open-window list (injected) until a window of one of the processes shows up. */
async function waitForWindow(ctx, names, { timeoutMs = 8000, every = 700 } = {}) {
  if (!ctx.listWindows) return { checked: false };
  const want = names.map((n) => n.toLowerCase());
  const end = Date.now() + timeoutMs;
  while (Date.now() < end) {
    let wins = [];
    try { wins = await ctx.listWindows(); } catch { return { checked: false }; }
    const hit = wins.find((w) => want.includes(String(w.app).toLowerCase()));
    if (hit) return { checked: true, found: true, window: hit };
    await sleep(every);
  }
  return { checked: true, found: false };
}

module.exports = { isWin, envOf, fsOf, sleep, isFile, isDir, firstFile, which, findVsCode, findChrome, findGit, findPython, findNode, findNpmCli, findWindowsTerminal, findPowerShell, findExplorer, authorizedPath, spawnDetached, waitForWindow };
