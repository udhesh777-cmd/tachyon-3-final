'use strict';
// Document parsing: Word/PowerPoint/Excel text extraction, CSV and JSON analysis.
const { unzipSync, strFromU8 } = require('fflate');

const entities = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&apos;': "'" };
const decodeXml = (s) => s.replace(/&(amp|lt|gt|quot|apos);|&#(\d+);|&#x([0-9a-f]+);/gi, (m, n, d, h) => (n ? entities['&' + n + ';'] : String.fromCodePoint(d ? Number(d) : parseInt(h, 16))));

function unzip(buf, filter) {
  return unzipSync(new Uint8Array(buf), { filter: (f) => filter(f.name) && f.originalSize < 40_000_000 });
}
const read = (files, name) => (files[name] ? strFromU8(files[name]) : '');

function extractDocx(buf) {
  const files = unzip(buf, (n) => n === 'word/document.xml');
  const xml = read(files, 'word/document.xml');
  if (!xml) throw new Error('Not a valid .docx file (word/document.xml missing).');
  return xml.split(/<\/w:p>/).map((p) =>
    decodeXml(p.replace(/<w:tab\/>/g, '\t').replace(/<w:br\/>/g, '\n').match(/<w:t[ >][^]*?<\/w:t>|\t|\n/g)?.map((t) => (t.startsWith('<') ? t.replace(/<[^>]+>/g, '') : t)).join('') || '')
  ).join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

function extractPptx(buf) {
  const files = unzip(buf, (n) => /^ppt\/slides\/slide\d+\.xml$/.test(n));
  const names = Object.keys(files).sort((a, b) => Number(a.match(/(\d+)\.xml/)[1]) - Number(b.match(/(\d+)\.xml/)[1]));
  if (!names.length) throw new Error('Not a valid .pptx file (no slides found).');
  return names.map((n, i) => `--- Slide ${i + 1} ---\n` + (read(files, n).match(/<a:t>[^]*?<\/a:t>/g) || []).map((t) => decodeXml(t.replace(/<[^>]+>/g, ''))).join('\n')).join('\n\n');
}

function colIndex(ref) { // "AB12" -> 27
  let n = 0;
  for (const ch of ref.replace(/\d+/g, '')) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

function extractXlsx(buf, { maxRows = 2000 } = {}) {
  const files = unzip(buf, (n) => n === 'xl/sharedStrings.xml' || n === 'xl/workbook.xml' || /^xl\/worksheets\/sheet\d+\.xml$/.test(n));
  const sheets = Object.keys(files).filter((n) => n.startsWith('xl/worksheets/')).sort((a, b) => Number(a.match(/(\d+)\.xml/)[1]) - Number(b.match(/(\d+)\.xml/)[1]));
  if (!sheets.length) throw new Error('Not a valid .xlsx file (no worksheets found).');
  const shared = (read(files, 'xl/sharedStrings.xml').match(/<si>[^]*?<\/si>/g) || []).map((si) => decodeXml((si.match(/<t[^>]*>[^]*?<\/t>/g) || []).map((t) => t.replace(/<[^>]+>/g, '')).join('')));
  const names = (read(files, 'xl/workbook.xml').match(/<sheet [^>]*name="([^"]*)"/g) || []).map((s) => decodeXml(s.match(/name="([^"]*)"/)[1]));
  const out = [];
  sheets.forEach((sn, si) => {
    out.push(`--- Sheet: ${names[si] || 'Sheet' + (si + 1)} ---`);
    const rows = read(files, sn).match(/<row[ >][^]*?<\/row>/g) || [];
    rows.slice(0, maxRows).forEach((row) => {
      const cells = [];
      for (const c of row.match(/<c [^>]*?(?:\/>|>[^]*?<\/c>)/g) || []) {
        const ref = c.match(/ r="([A-Z]+\d+)"/)?.[1];
        const t = c.match(/ t="([^"]+)"/)?.[1];
        let val = '';
        if (t === 's') val = shared[Number(c.match(/<v>(\d+)<\/v>/)?.[1])] ?? '';
        else if (t === 'inlineStr') val = decodeXml((c.match(/<t[^>]*>([^]*?)<\/t>/)?.[1]) || '');
        else val = decodeXml(c.match(/<v>([^]*?)<\/v>/)?.[1] || '');
        if (ref) cells[colIndex(ref)] = val;
      }
      out.push(Array.from(cells, (v) => v ?? '').join('\t'));
    });
    if (rows.length > maxRows) out.push(`… (${rows.length - maxRows} more rows)`);
  });
  return out.join('\n');
}

function extractOffice(buf, ext) {
  if (ext === 'docx') return extractDocx(buf);
  if (ext === 'pptx') return extractPptx(buf);
  if (ext === 'xlsx') return extractXlsx(buf);
  throw new Error(`.${ext} files cannot be parsed. Supported Office formats: docx, pptx, xlsx.`);
}

function parseCsv(text) {
  const first = text.split(/\r?\n/, 1)[0] || '';
  const delim = [',', ';', '\t'].map((d) => [d, first.split(d).length]).sort((a, b) => b[1] - a[1])[0][0];
  const rows = [];
  let row = [], field = '', q = false, unclosed = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') q = false;
      else field += c;
    } else if (c === '"' && field === '') q = true;
    else if (c === delim) { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.length > 1 || row[0] !== '') rows.push(row);
      row = [];
    } else field += c;
  }
  if (q) unclosed = true;
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return { rows, delimiter: delim, unclosedQuote: unclosed };
}

function jsonShape(v, depth = 0) {
  if (Array.isArray(v)) return `array(${v.length})` + (v.length && depth < 2 ? ' of ' + jsonShape(v[0], depth + 1) : '');
  if (v && typeof v === 'object') {
    const keys = Object.keys(v);
    return depth >= 2 ? `object(${keys.length} keys)` : '{ ' + keys.slice(0, 12).map((k) => `${k}: ${jsonShape(v[k], depth + 1)}`).join(', ') + (keys.length > 12 ? ', …' : '') + ' }';
  }
  return v === null ? 'null' : typeof v;
}

module.exports = { extractDocx, extractPptx, extractXlsx, extractOffice, parseCsv, jsonShape, decodeXml };
