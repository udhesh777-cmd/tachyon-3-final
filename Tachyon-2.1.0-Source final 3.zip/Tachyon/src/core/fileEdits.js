'use strict';
// Lets the AI edit attached files directly. The model answers with edit blocks; Tachyon validates them,
// refuses anything that is not an attached, editable file, backs the file up (.nova-bak) and then writes it.
const path = require('path');
const F = require('./fsTools');
const { checkJson } = require('./debugTools');

const BLOCK = /<<<NOVA_EDIT path="([^"]+)">>>\r?\n([\s\S]*?)\r?\n?<<<END_EDIT>>>/g;

function editSystemPrompt(paths) {
  return [
    'The user has allowed you to edit the files listed below. Answer normally and briefly.',
    'To change a file, output the COMPLETE new content of that file in exactly this format, once per edited file:',
    '<<<NOVA_EDIT path="THE_EXACT_PATH">>>',
    '(full new file content here)',
    '<<<END_EDIT>>>',
    'Rules: use only the exact paths listed; never output partial content; do not wrap the block in code fences; only edit when the user asks for a change.',
    'Editable files:',
    ...paths.map((p) => '- ' + p),
  ].join('\n');
}

function parseEditBlocks(reply) {
  const blocks = [];
  for (const m of reply.matchAll(BLOCK)) blocks.push({ path: m[1], content: m[2] });
  return blocks;
}

function stripEditBlocks(reply) {
  return reply.replace(BLOCK, (_m, p) => `[Edited ${path.basename(p)}]`).trim();
}

function validateContent(file, content) {
  if (!content.trim()) return 'The proposed content is empty; refusing to blank the file.';
  if (path.extname(file).toLowerCase() === '.json') {
    const r = checkJson(content);
    if (!r.ok) return 'The proposed JSON is invalid: ' + r.diagnostics[0].message;
  }
  return null;
}

/**
 * Finds which attached file an edit block means. Models often change the path a little: "/" instead of "\\",
 * doubled backslashes, other letter case on Windows, quotes, or only the file name. Returns the attached path or null.
 */
function matchAllowedPath(allowedPaths, raw, P = path) {
  const winLike = P === path.win32 || P.sep === '\\';
  let v = String(raw || '').trim().replace(/^["'`]+|["'`]+$/g, '');
  if (winLike) v = v.replace(/\\\\+/g, '\\').replace(/\//g, '\\');
  const key = (p) => (winLike ? P.resolve(p).toLowerCase() : P.resolve(p));
  if (P.isAbsolute(v)) {
    const hit = allowedPaths.find((a) => key(a) === key(v));
    if (hit) return hit;
  }
  // only a file name: accept it when exactly one attached file has that name
  const base = (winLike ? P.basename(v).toLowerCase() : P.basename(v));
  const same = allowedPaths.filter((a) => (winLike ? P.basename(a).toLowerCase() : P.basename(a)) === base);
  if (same.length === 1 && !P.isAbsolute(v)) return same[0];
  return null;
}

/** allowedPaths: absolute paths the user attached. Returns [{path, ok, backup?, error?}] */
async function applyEdits(roots, allowedPaths, blocks) {
  const results = [];
  for (const b of blocks) {
    const hit = matchAllowedPath(allowedPaths, b.path);
    if (!hit) { results.push({ path: b.path, ok: false, error: 'Not one of the files you attached; ignored.' }); continue; }
    const p = path.resolve(hit);
    const bad = validateContent(p, b.content);
    if (bad) { results.push({ path: p, ok: false, error: bad }); continue; }
    try {
      const { backup } = await F.writeText(roots, p, b.content.endsWith('\n') ? b.content : b.content + '\n');
      results.push({ path: p, ok: true, backup });
    } catch (e) { results.push({ path: p, ok: false, error: e.message }); }
  }
  return results;
}

module.exports = { editSystemPrompt, parseEditBlocks, stripEditBlocks, applyEdits, validateContent, matchAllowedPath };
