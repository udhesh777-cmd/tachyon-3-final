'use strict';
// File operations for Tachyon. Every function that touches the disk first checks that the
// path is inside a folder the user granted ("roots"). Nothing here ever deletes a file.
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const { extractPdfText } = require('./pdf');
const { extractOffice } = require('./docs');

const IMAGE_EXT = new Set(['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'heic', 'tiff', 'svg']);
const TEXT_EXT = new Set([
  'txt', 'md', 'csv', 'tsv', 'json', 'xml', 'html', 'htm', 'css', 'js', 'ts', 'jsx', 'tsx', 'py', 'java', 'kt',
  'c', 'cpp', 'h', 'cs', 'go', 'rs', 'rb', 'php', 'sh', 'bat', 'ps1', 'sql', 'yml', 'yaml', 'toml', 'ini', 'cfg',
  'log', 'tex', 'gradle', 'properties', 'rtf',
]);
const DOC_EXT = new Set([...TEXT_EXT, 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'odp', 'epub']);
const CATEGORIES = {
  Images: IMAGE_EXT,
  PDFs: new Set(['pdf']),
  Documents: new Set(['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'odp', 'epub', 'txt', 'md', 'rtf', 'csv']),
  Audio: new Set(['mp3', 'wav', 'flac', 'aac', 'm4a', 'ogg']),
  Video: new Set(['mp4', 'mkv', 'avi', 'mov', 'wmv', 'webm']),
  Archives: new Set(['zip', 'rar', '7z', 'tar', 'gz']),
  Code: new Set(['js', 'ts', 'py', 'java', 'kt', 'c', 'cpp', 'h', 'cs', 'go', 'rs', 'rb', 'php', 'sh', 'html', 'css', 'json', 'xml']),
};
const SKIP_DIRS = new Set(['node_modules', '$RECYCLE.BIN', 'System Volume Information', '__pycache__']);
const MAX_EDIT_BYTES = 1_000_000;
const MAX_SCAN_BYTES = 2_000_000;
const MAX_PDF_BYTES = 40_000_000;
const OFFICE_EXT = new Set(['docx', 'pptx', 'xlsx']);

const ext = (p) => path.extname(p).slice(1).toLowerCase();

// ---------------------------------------------------------------- path safety
function realpathNearest(p) {
  let cur = path.resolve(p);
  const rest = [];
  for (;;) {
    try {
      // The native call also expands Windows 8.3 short names (PROGRA~1) and returns the real letter case.
      let real;
      try { real = fs.realpathSync.native(cur); } catch { real = fs.realpathSync(cur); }
      return rest.length ? path.join(real, ...rest.reverse()) : real;
    } catch {
      const parent = path.dirname(cur);
      if (parent === cur) return path.resolve(p);
      rest.push(path.basename(cur));
      cur = parent;
    }
  }
}

/** Pure path check (no disk access). On Windows the comparison ignores letter case and / vs \\. */
function insideLexical(root, target, P = path) {
  const rel = P.relative(root, target);
  return rel === '' || (!rel.startsWith('..') && !P.isAbsolute(rel));
}

function isInside(root, target) {
  return insideLexical(realpathNearest(root), realpathNearest(target));
}

function assertInside(roots, target) {
  if (!roots || !roots.length) throw new Error('No folders granted yet. Add a folder first.');
  if (typeof target !== 'string' || !path.isAbsolute(target)) throw new Error('Invalid path.');
  if (!roots.some((r) => isInside(r, target))) {
    throw new Error(`That path is outside the folders you granted (${target}). Name it in the chat and choose “Allow”, or add its folder in Files & PDFs.`);
  }
}

// ---------------------------------------------------------------- walking
async function* walk(root, { maxDepth = 14, token } = {}) {
  const stack = [[root, 0]];
  let n = 0;
  while (stack.length) {
    const [dir, depth] = stack.pop();
    let entries;
    try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch { continue; }
    for (const e of entries) {
      if (token && token.cancelled) return;
      if (e.name.startsWith('.') && e.name !== '.') continue;
      const full = path.join(dir, e.name);
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) {
        if (depth < maxDepth && !SKIP_DIRS.has(e.name)) stack.push([full, depth + 1]);
      } else if (e.isFile()) {
        yield full;
      }
      if (++n % 500 === 0) await new Promise((r) => setImmediate(r));
    }
  }
}

async function statItem(p) {
  const s = await fsp.stat(p);
  return { path: p, name: path.basename(p), size: s.size, mtime: s.mtimeMs };
}

async function listDir(roots, dir) {
  assertInside(roots, dir);
  const entries = await fsp.readdir(dir, { withFileTypes: true });
  const out = [];
  for (const e of entries) {
    if (e.name.startsWith('.') || e.isSymbolicLink()) continue;
    const full = path.join(dir, e.name);
    try {
      const s = await fsp.stat(full);
      out.push({ name: e.name, path: full, isDir: e.isDirectory(), size: s.size, mtime: s.mtimeMs });
    } catch { /* unreadable */ }
    if (out.length >= 2000) break;
  }
  out.sort((a, b) => (a.isDir === b.isDir ? a.name.localeCompare(b.name) : a.isDir ? -1 : 1));
  return out;
}

// ---------------------------------------------------------------- search
async function searchByName(roots, { q = '', kind = 'all', limit = 300, token } = {}) {
  const needle = q.trim().toLowerCase();
  const results = [];
  for (const root of roots) {
    for await (const f of walk(root, { token })) {
      const e = ext(f);
      const ok = kind === 'images' ? IMAGE_EXT.has(e) : kind === 'docs' ? DOC_EXT.has(e) : kind === 'pdf' ? e === 'pdf' : true;
      if (ok && (!needle || path.basename(f).toLowerCase().includes(needle))) {
        try { results.push(await statItem(f)); } catch { /* vanished */ }
        if (results.length >= limit) return results;
      }
    }
  }
  return results;
}

const pdfCache = new Map(); // path -> { mtime, text }
async function cachedPdfText(p, maxChars) {
  const s = await fsp.stat(p);
  const hit = pdfCache.get(p);
  if (hit && hit.mtime === s.mtimeMs) return hit.result;
  if (s.size > MAX_PDF_BYTES) throw new Error('PDF is larger than 40 MB.');
  const result = await extractPdfText(await fsp.readFile(p), { maxChars });
  if (pdfCache.size > 200) pdfCache.clear();
  pdfCache.set(p, { mtime: s.mtimeMs, result });
  return result;
}

const officeCache = new Map();
async function cachedOfficeText(p) {
  const s = await fsp.stat(p);
  const hit = officeCache.get(p);
  if (hit && hit.mtime === s.mtimeMs) return hit.text;
  if (s.size > MAX_PDF_BYTES) throw new Error('File is larger than 40 MB.');
  const text = extractOffice(await fsp.readFile(p), ext(p));
  if (officeCache.size > 200) officeCache.clear();
  officeCache.set(p, { mtime: s.mtimeMs, text });
  return text;
}

function snippetAround(text, needleLower) {
  const i = text.toLowerCase().indexOf(needleLower);
  if (i < 0) return null;
  return text.slice(Math.max(0, i - 60), i + needleLower.length + 100).replace(/\s+/g, ' ').trim();
}

/** Searches inside plain-text files and (optionally) PDFs. */
async function searchContent(roots, { q = '', includePdf = true, limit = 100, maxPdfs = 300, token } = {}) {
  const needle = q.trim().toLowerCase();
  const items = [];
  let scannedPdfs = 0;
  let skippedPdfs = 0;
  if (!needle) return { items, scannedPdfs, skippedPdfs };
  for (const root of roots) {
    for await (const f of walk(root, { token })) {
      const e = ext(f);
      try {
        if (TEXT_EXT.has(e)) {
          const s = await fsp.stat(f);
          if (s.size > MAX_SCAN_BYTES) continue;
          const snip = snippetAround(await fsp.readFile(f, 'utf8'), needle);
          if (snip) items.push({ ...(await statItem(f)), snippet: snip });
        } else if ((e === 'pdf' || OFFICE_EXT.has(e)) && includePdf) {
          if (scannedPdfs >= maxPdfs) { skippedPdfs++; continue; }
          scannedPdfs++;
          const text = e === 'pdf' ? (await cachedPdfText(f, 400000)).text : await cachedOfficeText(f);
          const snip = snippetAround(text, needle);
          if (snip) items.push({ ...(await statItem(f)), snippet: snip });
        }
      } catch { /* unreadable or corrupt file: skip */ }
      if (items.length >= limit) return { items, scannedPdfs, skippedPdfs };
    }
  }
  return { items, scannedPdfs, skippedPdfs };
}

// ---------------------------------------------------------------- read / write
async function readForAI(roots, p, { maxChars = 60000 } = {}) {
  assertInside(roots, p);
  const e = ext(p);
  if (e === 'pdf') {
    const r = await cachedPdfText(p, Math.max(maxChars, 1000));
    if (!r.text) return { text: '', truncated: false, note: 'This PDF has no extractable text (it may be a scanned image).' };
    return { text: r.text.slice(0, maxChars), truncated: r.truncated || r.text.length > maxChars, note: `PDF, ${r.pages} page(s)` };
  }
  if (OFFICE_EXT.has(e)) {
    const t = await cachedOfficeText(p);
    return { text: t.slice(0, maxChars), truncated: t.length > maxChars, note: e.toUpperCase() + ' document' };
  }
  if (TEXT_EXT.has(e)) {
    const s = await fsp.stat(p);
    if (s.size > 5_000_000) throw new Error('This text file is larger than 5 MB.');
    const t = await fsp.readFile(p, 'utf8');
    return { text: t.slice(0, maxChars), truncated: t.length > maxChars, note: 'Text file' };
  }
  throw new Error(`Reading .${e || '(no extension)'} files is not supported yet. Supported: PDF, Word (.docx), PowerPoint (.pptx), Excel (.xlsx) and plain-text files.`);
}

async function readEditable(roots, p) {
  assertInside(roots, p);
  if (!TEXT_EXT.has(ext(p))) throw new Error('Only plain-text files can be edited.');
  const s = await fsp.stat(p);
  if (s.size > MAX_EDIT_BYTES) throw new Error('This file is larger than 1 MB; the editor only opens smaller text files.');
  return fsp.readFile(p, 'utf8');
}

async function writeText(roots, p, text) {
  assertInside(roots, p);
  if (!TEXT_EXT.has(ext(p))) throw new Error('Only plain-text files can be edited.');
  if (typeof text !== 'string' || text.length > 3_000_000) throw new Error('Invalid or too large text.');
  let backup = null;
  try {
    await fsp.access(p);
    backup = p + '.nova-bak';
    await fsp.copyFile(p, backup);
  } catch { backup = null; }
  const tmp = p + '.nova-tmp';
  await fsp.writeFile(tmp, text, 'utf8');
  await fsp.rename(tmp, p);
  // Read the file back and compare, so “saved” is a checked fact and not an assumption.
  const back = await fsp.readFile(p, 'utf8');
  if (back !== text) throw new Error(`The file was written but reading it back did not match what was saved. ${backup ? 'Your previous version is kept as ' + path.basename(backup) + '.' : ''}`);
  return { backup, verified: true, bytes: Buffer.byteLength(text, 'utf8') };
}

/** Swaps the file with its .nova-bak copy (so the restore itself can be undone by restoring again). */
async function restoreBackup(roots, p) {
  assertInside(roots, p);
  const bak = p + '.nova-bak';
  assertInside(roots, bak);
  try { await fsp.access(bak); } catch { throw new Error('There is no backup (.nova-bak) for this file.'); }
  const tmp = p + '.nova-swap';
  try { await fsp.copyFile(p, tmp); } catch { /* current file may be missing */ }
  await fsp.copyFile(bak, p);
  if (fs.existsSync(tmp)) { await fsp.rename(tmp, bak); }
  return { restored: true };
}

/** name.edited.pdf, name.edited_1.pdf ... in the same folder. */
function uniqueSibling(p, tag, newExt) {
  const dir = path.dirname(p);
  const base = path.basename(p, path.extname(p));
  const e = newExt || path.extname(p);
  return uniqueDest(dir, `${base}.${tag}${e}`);
}

// ---------------------------------------------------------------- organize (move only)
function categoryOf(e) {
  for (const [name, set] of Object.entries(CATEGORIES)) if (set.has(e)) return name;
  return 'Other';
}

async function planSort(roots, folder, { mode = 'type', onlyImages = false } = {}) {
  assertInside(roots, folder);
  const entries = await fsp.readdir(folder, { withFileTypes: true });
  const plan = [];
  for (const e of entries) {
    if (!e.isFile() || e.isSymbolicLink() || e.name.startsWith('.') || e.name.endsWith('.nova-bak')) continue;
    const full = path.join(folder, e.name);
    const x = ext(full);
    if (onlyImages && !IMAGE_EXT.has(x)) continue;
    let sub;
    if (mode === 'month') {
      const d = new Date((await fsp.stat(full)).mtimeMs);
      sub = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    } else if (mode === 'ext') sub = x || 'no-extension';
    else sub = categoryOf(x);
    plan.push({ from: full, toDir: path.join(folder, sub) });
  }
  return plan;
}

function uniqueDest(dir, name) {
  const base = path.basename(name, path.extname(name));
  const e = path.extname(name);
  let dest = path.join(dir, name);
  for (let i = 1; fs.existsSync(dest); i++) dest = path.join(dir, `${base}_${i}${e}`);
  return dest;
}

async function moveFile(from, to) {
  try { await fsp.rename(from, to); } catch (err) {
    if (err.code !== 'EXDEV') throw err;
    await fsp.copyFile(from, to, fs.constants.COPYFILE_EXCL);
    await fsp.unlink(from); // only after a verified copy; this is a move, not a delete
  }
}

async function applySort(roots, plan, journalPath) {
  const moves = [];
  let failed = 0;
  for (const item of plan) {
    try {
      assertInside(roots, item.from);
      assertInside(roots, item.toDir);
      await fsp.mkdir(item.toDir, { recursive: true });
      const to = uniqueDest(item.toDir, path.basename(item.from)); // never overwrites
      await moveFile(item.from, to);
      moves.push({ from: item.from, to });
    } catch { failed++; }
  }
  if (moves.length) await fsp.writeFile(journalPath, JSON.stringify({ time: Date.now(), moves }), 'utf8');
  return { moved: moves.length, failed };
}

async function undoLastSort(roots, journalPath) {
  let journal;
  try { journal = JSON.parse(await fsp.readFile(journalPath, 'utf8')); } catch { throw new Error('There is nothing to undo.'); }
  let restored = 0;
  let skipped = 0;
  for (const m of [...journal.moves].reverse()) {
    try {
      assertInside(roots, m.from);
      assertInside(roots, m.to);
      if (!fs.existsSync(m.to) || fs.existsSync(m.from)) { skipped++; continue; }
      await fsp.mkdir(path.dirname(m.from), { recursive: true });
      await moveFile(m.to, m.from);
      restored++;
    } catch { skipped++; }
  }
  await fsp.unlink(journalPath).catch(() => {});
  return { restored, skipped };
}

module.exports = {
  IMAGE_EXT, TEXT_EXT, isInside, insideLexical, assertInside, realpathNearest, listDir, searchByName, searchContent,
  readForAI, readEditable, writeText, restoreBackup, uniqueSibling, OFFICE_EXT, planSort, applySort, undoLastSort, uniqueDest, categoryOf,
};
