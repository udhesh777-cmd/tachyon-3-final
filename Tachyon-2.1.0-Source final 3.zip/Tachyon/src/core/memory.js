'use strict';
// Personal memory: short facts you ask Tachyon to remember ("remember that I prefer short answers").
// Stored only on this computer (memory.json). You can view, delete or clear them in Settings → Memory, or say "forget …".
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const MAX_ITEMS = 200;
const MAX_LEN = 400;

class Memory {
  constructor(dir) { this.file = path.join(dir, 'memory.json'); }

  list() {
    try { const a = JSON.parse(fs.readFileSync(this.file, 'utf8')); return Array.isArray(a) ? a : []; } catch { return []; }
  }
  _write(items) {
    const tmp = this.file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(items), 'utf8');
    fs.renameSync(tmp, this.file);
  }
  add(text, source = 'chat') {
    const t = String(text || '').replace(/\s+/g, ' ').trim().slice(0, MAX_LEN);
    if (!t) throw new Error('Nothing to remember.');
    const items = this.list();
    const dup = items.find((m) => m.text.toLowerCase() === t.toLowerCase());
    if (dup) return dup;
    const item = { id: crypto.randomUUID(), text: t, createdAt: Date.now(), source };
    items.push(item);
    this._write(items.slice(-MAX_ITEMS));
    return item;
  }
  remove(id) {
    const items = this.list();
    const next = items.filter((m) => m.id !== id);
    this._write(next);
    return items.length - next.length;
  }
  /** Removes every memory that contains all the words of the query. Returns the removed items. */
  forget(query) {
    const words = String(query || '').toLowerCase().split(/\W+/).filter((w) => w.length > 2 && !STOP.has(w));
    if (!words.length) return [];
    const items = this.list();
    const gone = items.filter((m) => words.every((w) => m.text.toLowerCase().includes(w)));
    if (gone.length) this._write(items.filter((m) => !gone.includes(m)));
    return gone;
  }
  clear() { this._write([]); }

  /** The block added to the system prompt, or '' when there is nothing to add. */
  promptBlock() {
    const items = this.list();
    if (!items.length) return '';
    return 'Things the user asked you to remember about them (use them when relevant, do not repeat them back unprompted):\n' + items.map((m) => '- ' + m.text).join('\n');
  }
}
const STOP = new Set(['that', 'the', 'about', 'what', 'you', 'remember', 'my', 'and', 'this', 'please']);

module.exports = { Memory, MAX_ITEMS };
