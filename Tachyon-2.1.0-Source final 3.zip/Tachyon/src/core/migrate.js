'use strict';
// Tachyon was called NOVA AI. On the first start, copy settings, chats and keys from the old app's data folder
// so nothing is lost. The old folder is left untouched.
const fs = require('fs');
const path = require('path');

const FILES = ['settings.json', 'conversations.json', 'apikey.bin', 'apikey-vision.bin', 'last-sort.json'];
const DIRS = ['captures', 'generated'];
const OLD_NAMES = ['NOVA AI', 'nova-ai-desktop'];

/** Returns the folder it migrated from, or null. newDir: Tachyon's data folder; appData: the OS app-data folder. */
function migrateUserData(newDir, appData, oldNames = OLD_NAMES) {
  if (FILES.slice(0, 2).some((f) => fs.existsSync(path.join(newDir, f)))) return null;
  for (const name of oldNames) {
    const old = path.join(appData, name);
    if (path.resolve(old) === path.resolve(newDir)) continue;
    if (!FILES.slice(0, 2).some((f) => fs.existsSync(path.join(old, f)))) continue;
    fs.mkdirSync(newDir, { recursive: true });
    for (const f of FILES) {
      try { if (fs.existsSync(path.join(old, f))) fs.copyFileSync(path.join(old, f), path.join(newDir, f), fs.constants.COPYFILE_EXCL); } catch { /* best effort */ }
    }
    for (const d of DIRS) {
      try { if (fs.existsSync(path.join(old, d))) fs.cpSync(path.join(old, d), path.join(newDir, d), { recursive: true, errorOnExist: false, force: false }); } catch { /* best effort */ }
    }
    return old;
  }
  return null;
}

module.exports = { migrateUserData, OLD_NAMES };
