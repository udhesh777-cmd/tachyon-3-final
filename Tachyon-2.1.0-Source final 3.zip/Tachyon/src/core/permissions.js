'use strict';
// Per-category permissions: 'allow' (do it), 'ask' (confirm every time) or 'deny' (never).
// Defaults keep Tachyon 1.3 behaviour; deleting files and sending anything outside always ask.

const CATEGORIES = {
  'files.read': { label: 'Read files you name, attach or drop', def: 'allow' },
  'files.edit': { label: 'Change files (AI edits, editor, resize; a .nova-bak backup is always kept)', def: 'allow' },
  'files.create': { label: 'Create new files (auto-save, convert, Rewrite → PDF)', def: 'allow' },
  'files.move': { label: 'Move files (Organize and its Undo)', def: 'allow' },
  'files.open': { label: 'Open files and folders in other apps', def: 'allow' },
  'cloud.files': { label: 'Send file contents and images to a cloud AI model', def: 'allow' },
  'apps.open': { label: 'Open apps on this computer (shells and system tools are always blocked)', def: 'allow' },
  'windows': { label: 'Switch, minimise and maximise windows', def: 'allow' },
  'reminders': { label: 'Set reminders (shown as desktop notifications)', def: 'allow' },
  'skills': { label: 'Run skills you installed (code skills run in a locked sandbox)', def: 'allow' },
  'commands.read': { label: 'Run read-only developer commands in your project folders (git status, versions)', def: 'allow' },
  'browser.open': { label: 'Open web pages (http/https) in Chrome or your default browser', def: 'allow' },
  'terminal.open': { label: 'Open PowerShell or Windows Terminal when you click their button in Applications', def: 'allow' },
  'commands.run': { label: 'Run project tests (npm test, pytest, unittest) — they start code from the project', def: 'ask', noAllow: true },
  'files.delete': { label: 'Delete files', def: 'ask', noAllow: true },
  'send': { label: 'Send anything outside this computer (e-mail, messages, uploads)', def: 'ask', noAllow: true },
};
const VALUES = ['allow', 'ask', 'deny'];

/** The permission map in effect: defaults merged with the user's choices. */
function effective(settings) {
  const saved = (settings && settings.permissions) || {};
  const out = {};
  for (const [k, c] of Object.entries(CATEGORIES)) {
    let v = VALUES.includes(saved[k]) ? saved[k] : c.def;
    if (c.noAllow && v === 'allow') v = 'ask';
    out[k] = v;
  }
  return out;
}

/** Cleans a permissions object coming from the Settings page. */
function sanitize(p) {
  const out = {};
  for (const [k, c] of Object.entries(CATEGORIES)) {
    if (p && VALUES.includes(p[k])) out[k] = c.noAllow && p[k] === 'allow' ? 'ask' : p[k];
  }
  return out;
}

module.exports = { CATEGORIES, VALUES, effective, sanitize };
