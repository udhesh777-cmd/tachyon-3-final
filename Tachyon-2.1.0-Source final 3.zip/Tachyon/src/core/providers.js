'use strict';
// AI providers: OpenAI-compatible cloud API and Ollama (local or on another machine).

class AiError extends Error {}

function validate(cfg) {
  const t = Number(cfg.timeoutSec);
  if (!Number.isFinite(t) || t < 5 || t > 300) return 'Request timeout must be between 5 and 300 seconds.';
  if (cfg.kind === 'cloud') {
    let u;
    try { u = new URL((cfg.baseUrl || '').trim()); } catch { return 'Enter a valid API base URL.'; }
    if (u.protocol !== 'https:') return 'The cloud API URL must start with https:// (plain http is not allowed).';
    if (!cfg.apiKey || !cfg.apiKey.trim()) return 'Enter your API key.';
    if (/[^\x21-\x7e]/.test(cfg.apiKey.trim())) return 'The API key contains spaces or invalid characters.';
    if (!cfg.model || !cfg.model.trim()) return 'Enter a model identifier.';
  } else {
    const host = (cfg.host || '').trim();
    if (!host) return 'Enter the Ollama host (use 127.0.0.1 for this computer).';
    if (/[\/\s]/.test(host) || host.includes('://')) return 'Enter only the host name or IP address (no http:// and no path).';
    const p = Number(cfg.port);
    if (!Number.isInteger(p) || p < 1 || p > 65535) return 'Enter a valid port (1-65535).';
    if (!cfg.model || !cfg.model.trim()) return 'Enter the model name installed in Ollama.';
  }
  return null;
}

/** Messages may carry images: [base64 JPEG strings]. */
function toOpenAiMessages(messages) {
  return messages.map((m) => {
    if (!m.images || !m.images.length) return { role: m.role, content: m.content };
    return {
      role: m.role,
      content: [
        { type: 'text', text: m.content },
        ...m.images.map((b64) => ({ type: 'image_url', image_url: { url: 'data:image/jpeg;base64,' + b64 } })),
      ],
    };
  });
}
function toOllamaMessages(messages) {
  return messages.map((m) => (m.images && m.images.length ? { role: m.role, content: m.content, images: m.images } : { role: m.role, content: m.content }));
}

function openAiBase(base) {
  return base.trim().replace(/\/+$/, '').replace(/\/chat\/completions$/, '');
}

function openAiUrl(base) {
  const b = base.trim().replace(/\/+$/, '');
  return b.endsWith('/chat/completions') ? b : b + '/chat/completions';
}
const ollamaUrl = (host, port, path) => `http://${host.trim()}:${String(port).trim()}${path}`;

function parseOpenAi(body) {
  let text;
  try {
    const msg = JSON.parse(body)?.choices?.[0]?.message;
    text = msg && msg.content != null ? msg.content : null;
  } catch { throw new AiError('The provider returned a malformed response.'); }
  if (text === null) throw new AiError('Malformed response: no message content found.');
  if (typeof text !== 'string' || !text.trim()) throw new AiError('The model returned an empty response.');
  return text.trim();
}

function parseOllama(body) {
  let text;
  try {
    const msg = JSON.parse(body)?.message;
    text = msg && msg.content != null ? msg.content : null;
  } catch { throw new AiError('The server returned a malformed response.'); }
  if (text === null) throw new AiError('Malformed response: no message content found.');
  if (typeof text !== 'string' || !text.trim()) throw new AiError('The model returned an empty response.');
  return text.trim();
}

function ollamaModelNames(body) {
  try {
    const arr = JSON.parse(body).models || [];
    return arr.map((m) => m && m.name).filter(Boolean);
  } catch { throw new AiError('The server returned a malformed response (is this an Ollama server?).'); }
}

function errorDetail(body) {
  try {
    const e = JSON.parse(body).error;
    const s = typeof e === 'string' ? e : e && e.message;
    return s ? String(s).slice(0, 200) : null;
  } catch { return null; }
}

function httpMessage(code, body) {
  let base;
  if (code === 400) base = 'The provider rejected the request (HTTP 400). Check the model identifier.';
  else if (code === 401 || code === 403) base = `Authentication failed (HTTP ${code}). Check your API key.`;
  else if (code === 404) base = 'Endpoint or model not found (HTTP 404). Check the base URL and model.';
  else if (code === 408) base = 'The provider timed out (HTTP 408).';
  else if (code === 429) base = 'Rate limit or quota reached (HTTP 429). Wait a bit and retry, or try another model.';
  else if (code >= 500) base = `The provider had a server error (HTTP ${code}). Try again later.`;
  else base = `Request failed (HTTP ${code}).`;
  const d = errorDetail(body);
  return d ? `${base} Provider says: ${d}` : base;
}

function describeNetworkError(e) {
  const code = e?.cause?.code || e?.code || '';
  if (code === 'ENOTFOUND' || code === 'EAI_AGAIN') return 'Cannot reach the server. Check your internet connection and the address.';
  if (code === 'ECONNREFUSED') return 'Connection refused. Check the address/port and that the server is running.';
  if (code === 'ETIMEDOUT' || code === 'UND_ERR_CONNECT_TIMEOUT') return 'The connection timed out. Check the address and your network.';
  if (/CERT|SSL|TLS/i.test(code) || /certificate/i.test(String(e?.cause?.message || ''))) return 'Secure (TLS) connection failed. Check the URL and your computer date/time.';
  return 'Network error: ' + (e?.cause?.message || e?.message || 'unknown');
}

async function request(url, { method = 'GET', headers = {}, body, timeoutSec, signal, binary = false }) {
  const ctrl = new AbortController();
  let timedOut = false;
  let cancelled = false;
  const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutSec * 1000);
  const onAbort = () => { cancelled = true; ctrl.abort(); };
  if (signal) {
    if (signal.aborted) onAbort();
    else signal.addEventListener('abort', onAbort, { once: true });
  }
  try {
    const res = await fetch(url, { method, headers, body, signal: ctrl.signal, redirect: 'error' });
    if (binary) {
      const buf = Buffer.from(await res.arrayBuffer());
      if (!res.ok) throw new AiError(httpMessage(res.status, buf.subarray(0, 2000).toString('utf8')));
      if (buf.length > 30_000_000) throw new AiError('The returned file is too large.');
      return buf;
    }
    const text = await res.text();
    if (!res.ok) throw new AiError(httpMessage(res.status, text));
    return text;
  } catch (e) {
    if (e instanceof AiError) throw e;
    if (cancelled) throw new AiError('Cancelled.');
    if (timedOut) throw new AiError('The request timed out. Check your connection or raise the timeout in Settings.');
    throw new AiError(describeNetworkError(e));
  } finally {
    clearTimeout(timer);
    if (signal) signal.removeEventListener('abort', onAbort);
  }
}

/** messages: [{role, content}] */
async function chat(cfg, messages, { signal } = {}) {
  const problem = validate(cfg);
  if (problem) throw new AiError(problem);
  const model = cfg.model.trim();
  if (cfg.kind === 'cloud') {
    const body = await request(openAiUrl(cfg.baseUrl), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + cfg.apiKey.trim() },
      body: JSON.stringify({ model, messages: toOpenAiMessages(messages) }),
      timeoutSec: cfg.timeoutSec, signal,
    });
    return parseOpenAi(body);
  }
  const body = await request(ollamaUrl(cfg.host, cfg.port, '/api/chat'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model, messages: toOllamaMessages(messages), stream: false }),
    timeoutSec: cfg.timeoutSec, signal,
  });
  return parseOllama(body);
}

/** A real request against the configured server. Resolves to a success message or throws AiError. */
async function testConnection(cfg) {
  const problem = validate(cfg);
  if (problem) throw new AiError(problem);
  if (cfg.kind === 'cloud') {
    await chat(cfg, [{ role: 'user', content: 'Reply with the single word: OK' }]);
    return 'Connected. The model answered a real test request.';
  }
  const names = await listOllamaModels(cfg);
  const m = cfg.model.trim();
  if (!names.some((n) => n === m || n === m + ':latest')) {
    throw new AiError(`Server reachable, but model '${m}' is not installed. Installed: ${names.slice(0, 8).join(', ') || 'none'}`);
  }
  return `Connected. Server reachable and model '${m}' is installed.`;
}

async function listOllamaModels(cfg) {
  const body = await request(ollamaUrl(cfg.host, cfg.port, '/api/tags'), { timeoutSec: Number(cfg.timeoutSec) || 30 });
  return ollamaModelNames(body);
}

function cloudModelNames(body) {
  try {
    const j = JSON.parse(body);
    const arr = Array.isArray(j.data) ? j.data : Array.isArray(j.models) ? j.models : [];
    return arr.map((m) => String(m && (m.id || m.name) || '').replace(/^models\//, '')).filter(Boolean);
  } catch { throw new AiError('The provider returned a malformed model list.'); }
}

/** Asks an OpenAI-compatible provider which models your key can use (also works for Gemini). */
async function listCloudModels(cfg) {
  const problem = validate({ ...cfg, kind: 'cloud', model: cfg.model || 'x' });
  if (problem) throw new AiError(problem);
  const body = await request(openAiBase(cfg.baseUrl) + '/models', {
    headers: { Authorization: 'Bearer ' + cfg.apiKey.trim() }, timeoutSec: Number(cfg.timeoutSec) || 30,
  });
  return cloudModelNames(body);
}

function describeError(e) {
  return e instanceof AiError ? e.message : 'Unexpected error: ' + (e && e.message ? e.message : String(e));
}

module.exports = {
  AiError, validate, openAiUrl, ollamaUrl, parseOpenAi, parseOllama, ollamaModelNames,
  httpMessage, describeNetworkError, chat, testConnection, listOllamaModels, describeError,
  request, toOpenAiMessages, toOllamaMessages, openAiBase, cloudModelNames, listCloudModels,
};
