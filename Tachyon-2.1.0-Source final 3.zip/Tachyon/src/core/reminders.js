'use strict';
// Reminders: "remind me to call mom at 6 pm", "remind me in 20 minutes to stretch", "remind me tomorrow at 9 to pay rent".
// Stored only on this computer (reminders.json); a desktop notification appears when one is due.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const { parseReminder, parseClock } = require('../renderer/commands');

class Reminders {
  constructor(dir) { this.file = path.join(dir, 'reminders.json'); }
  list() { try { const a = JSON.parse(fs.readFileSync(this.file, 'utf8')); return Array.isArray(a) ? a : []; } catch { return []; } }
  _write(a) { const tmp = this.file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(a), 'utf8'); fs.renameSync(tmp, this.file); }
  add(text, at) {
    if (!String(text || '').trim()) throw new Error('What should I remind you about?');
    if (!Number.isFinite(at)) throw new Error('When should I remind you?');
    const r = { id: crypto.randomUUID(), text: String(text).trim().slice(0, 300), at, done: false, createdAt: Date.now() };
    this._write([...this.list(), r]);
    return r;
  }
  remove(id) { const a = this.list(); const b = a.filter((r) => r.id !== id); this._write(b); return a.length - b.length; }
  /** Marks and returns the reminders that are due. */
  takeDue(now = Date.now()) {
    const a = this.list();
    const due = a.filter((r) => !r.done && r.at <= now);
    if (due.length) { due.forEach((r) => { r.done = true; r.firedAt = now; }); this._write(a.filter((r) => !r.done || now - r.at < 7 * 864e5)); }
    return due;
  }
  pending() { return this.list().filter((r) => !r.done).sort((a, b) => a.at - b.at); }
}

module.exports = { parseReminder, parseClock, Reminders };
