'use strict';
// Chooses which configured model answers a request: text/chat/code -> Text model; anything with an image
// (screenshots, OCR, image analysis) -> Vision model. The user never has to switch models by hand.
const { validate } = require('./providers');

/** Provider config for one slot. getKey(slot) returns the stored API key for that slot. */
function slotConfig(settings, slot, getKey) {
  const m = settings.models[slot];
  let apiKey = getKey(slot) || '';
  // A vision slot that points at the same cloud endpoint as the text slot can reuse the text key.
  if (!apiKey && slot === 'vision' && m.provider === 'cloud' && m.baseUrl && m.baseUrl === settings.models.text.baseUrl) apiKey = getKey('text') || '';
  return {
    kind: m.provider === 'cloud' ? 'cloud' : 'local', baseUrl: m.baseUrl, apiKey, model: m.model,
    timeoutSec: settings.timeoutSec, host: m.host, port: m.port, preset: m.preset,
  };
}

/** Decides which slot handles a request and returns its config plus a human-readable label. */
function route(settings, getKey, { hasImages = false } = {}) {
  const v = settings.models.vision;
  const separate = hasImages && v.mode === 'separate' && v.model.trim() !== '';
  const slot = separate ? 'vision' : 'text';
  const cfg = slotConfig(settings, slot, getKey);
  const where = cfg.kind === 'local' ? 'Ollama' : cfg.preset === 'gemini' ? 'Gemini' : 'cloud';
  return {
    slot, cfg, wantedVision: hasImages, usedTextForImages: hasImages && !separate,
    label: `${slot === 'vision' ? 'Vision' : 'Text'} model ${cfg.model} (${where})`,
  };
}

/** Null when the slot is ready to use, otherwise a short explanation. */
function slotProblem(settings, slot, getKey) {
  const cfg = slotConfig(settings, slot, getKey);
  if (!cfg.model || !cfg.model.trim()) return slot === 'vision' ? 'No vision model is set.' : 'No text model is set.';
  return validate(cfg);
}

module.exports = { slotConfig, route, slotProblem };
