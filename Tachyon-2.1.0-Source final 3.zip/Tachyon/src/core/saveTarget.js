'use strict';
// Turns a place the user named in the chat ("save it to D:\Reports", "save this to my desktop as notes.md")
// into a concrete, never-overwriting file path. Also resolves file/folder names the user typed.
const fs = require('fs');
const path = require('path');

const SAVE_EXT = new Set(['pdf', 'docx', 'txt', 'md', 'html', 'htm', 'csv', 'json', 'py', 'js', 'ts', 'java', 'kt', 'c', 'cpp', 'cs', 'go', 'rs', 'sh', 'sql', 'xml', 'yml', 'yaml', 'css']);
const KNOWN = ['desktop', 'documents', 'downloads', 'pictures', 'music', 'videos', 'home'];
const LANG_EXT = { python: 'py', py: 'py', javascript: 'js', js: 'js', typescript: 'ts', ts: 'ts', java: 'java', kotlin: 'kt', c: 'c', cpp: 'cpp', 'c++': 'cpp', csharp: 'cs', cs: 'cs', go: 'go', rust: 'rs', bash: 'sh', sh: 'sh', shell: 'sh', sql: 'sql', json: 'json', csv: 'csv', html: 'html', css: 'css', xml: 'xml', yaml: 'yaml', yml: 'yml' };

const extOf = (p) => path.extname(p).slice(1).toLowerCase();

/** "~/x", "D:\x", "/x", "my desktop" or a relative name -> absolute path. ctx: { home, known: {desktop, documents, …} } */
function expandUserPath(loc, ctx) {
  if (!loc) return ctx.known.documents;
  if (loc.kind === 'known') return loc.value === 'home' ? ctx.home : (ctx.known[loc.value] || ctx.known.documents);
  let v = String(loc.value || '').trim().replace(/^["“'`]|["”'`]$/g, '').replace(/[.,;:!?]+$/, '');
  if (v === '~') return ctx.home;
  if (/^~[\\/]/.test(v)) return path.join(ctx.home, v.slice(2));
  if (/^[A-Za-z]:[\\/]/.test(v) || path.isAbsolute(v)) return path.normalize(v);
  return path.join(ctx.known.documents, v);
}

/** The extension to use when the user did not say: the language of a code-only answer, else PDF. */
function guessFormat(text) {
  const t = String(text || '').trim();
  const m = /^```\s*([\w+#-]*)\s*\n[\s\S]*?\n```\s*$/.exec(t);
  if (m && LANG_EXT[m[1].toLowerCase()]) return LANG_EXT[m[1].toLowerCase()];
  return 'pdf';
}

function safeName(title) {
  const s = String(title || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/[#*`_]+/g, '').replace(/\s+/g, ' ').trim().slice(0, 50).trim();
  return s.replace(/[. ]+$/, '') || 'Tachyon answer';
}

function uniqueDest(dir, name, exists = fs.existsSync) {
  const base = path.basename(name, path.extname(name));
  const e = path.extname(name);
  let dest = path.join(dir, name);
  for (let i = 1; exists(dest); i++) dest = path.join(dir, `${base} (${i})${e}`);
  return dest;
}

/**
 * Plans where an auto-save goes. req: { location, filename, format, title, text }.
 * Returns { dir, file, format }. Existing files are never overwritten: "name (1).pdf", "name (2).pdf"…
 */
function planSave(req, ctx, exists = fs.existsSync) {
  let dir = expandUserPath(req.location, ctx);
  let name = req.filename ? path.basename(String(req.filename)) : null;
  if (!name && SAVE_EXT.has(extOf(dir))) { name = path.basename(dir); dir = path.dirname(dir); }
  let format = name && SAVE_EXT.has(extOf(name)) ? extOf(name) : null;
  if (!format) format = req.format && SAVE_EXT.has(req.format) ? req.format : guessFormat(req.text);
  if (!name) name = safeName(req.title) + '.' + format;
  else if (extOf(name) !== format) name = name + '.' + format;
  return { dir, file: uniqueDest(dir, name, exists), format };
}

/**
 * Windows often moves Desktop/Documents/Pictures into OneDrive (C:\Users\me\OneDrive\Documents). A path the user types
 * as C:\Users\me\Documents\x.pdf then does not exist. Returns the same path under the real known folder, or null.
 */
function remapKnownFolder(p, ctx, P = path) {
  const win = P === path.win32 || P.sep === '\\';
  const norm = (x) => (win ? P.normalize(x).toLowerCase() : P.normalize(x));
  const target = norm(p);
  const homes = [ctx.home, P.join(ctx.home, 'OneDrive')];
  for (const [name, real] of Object.entries(ctx.known || {})) {
    if (!real) continue;
    const leaf = P.basename(real);
    const variants = new Set([...homes.map((h) => P.join(h, leaf)), ...homes.map((h) => P.join(h, name.charAt(0).toUpperCase() + name.slice(1))), real]);
    for (const v of variants) {
      const nv = norm(v);
      if (nv === norm(real)) continue;
      if (target === nv || target.startsWith(nv + P.sep)) return P.join(real, P.normalize(p).slice(P.normalize(v).length));
    }
  }
  return null;
}

module.exports = { SAVE_EXT, KNOWN, expandUserPath, guessFormat, safeName, uniqueDest, planSave, remapKnownFolder };
