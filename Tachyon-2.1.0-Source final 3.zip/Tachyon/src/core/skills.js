'use strict';
// Skills: small abilities the user adds by asking ("create a skill that turns notes into a to-do list").
// Tachyon drafts the skill, the user sees it and its test results, and only an explicit Install adds it.
// Skills never change Tachyon itself: a prompt skill is an instruction for the AI model, a code skill is a
// JavaScript function run in a locked sandbox (no files, no network, time limit). Every version is kept for rollback.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const RESERVED = new Set(['image', 'task', 'skill', 'skills', 'help', 'remind', 'open', 'find', 'memory', 'settings', 'voice', 'undo', 'clear', 'new']);
const COMMAND_RE = /^[a-z][a-z0-9-]{1,23}$/;
const MAX_CODE = 20000;
const MAX_PROMPT = 4000;
const FORBIDDEN_CODE = /\b(?:require|process|importScripts|XMLHttpRequest|fetch|WebSocket|EventSource|indexedDB|localStorage|sessionStorage|eval|postMessage|Worker)\b|\bimport\s*\(|\bFunction\s*\(|document\.cookie|sendBeacon|window\.open/;

function drafterPrompt() {
  return [
    'You create small "skills" for Tachyon, a desktop assistant. A skill takes the user\'s text and returns text.',
    'Choose kind "prompt" when an AI model is needed (rewriting, summarising, translating, ideas…): write "prompt" as clear instructions containing {{input}} where the user\'s text goes.',
    'Choose kind "code" only for exact, mechanical work (counting, formatting, converting units, sorting lines…): write "code" as plain JavaScript that defines function run(input) { … return "text"; }. No require, fetch, network, files, eval or DOM.',
    'Add 1 to 3 tests: {"input": "…", "expect": "text the output must contain"}. Code skills must pass them; for prompt skills "expect" may be empty.',
    'Reply with ONLY JSON: {"name": "Readable name", "command": "short-lowercase-command", "description": "one sentence", "kind": "prompt"|"code", "prompt": "…", "code": "…", "tests": [ … ]}',
  ].join('\n');
}

/** Checks a drafted skill and returns a clean copy, or throws a readable error. */
function validateSkill(d) {
  if (!d || typeof d !== 'object') throw new Error('The skill draft is empty.');
  const command = String(d.command || '').trim().toLowerCase().replace(/^\//, '').replace(/[\s_]+/g, '-');
  if (!COMMAND_RE.test(command)) throw new Error('The skill command must be 2–24 lowercase letters, digits or dashes, starting with a letter.');
  if (RESERVED.has(command)) throw new Error(`/${command} is a built-in command. Pick another name for the skill.`);
  const kind = d.kind === 'code' ? 'code' : 'prompt';
  const out = {
    name: String(d.name || command).trim().slice(0, 60), command, description: String(d.description || '').trim().slice(0, 300), kind,
    tests: (Array.isArray(d.tests) ? d.tests : []).slice(0, 5).map((t) => ({ input: String((t && t.input) ?? '').slice(0, 2000), expect: String((t && t.expect) ?? '').slice(0, 500) })),
  };
  if (kind === 'prompt') {
    out.prompt = String(d.prompt || '').trim();
    if (!out.prompt) throw new Error('The prompt skill has no instructions.');
    if (out.prompt.length > MAX_PROMPT) throw new Error('The skill instructions are too long.');
    if (!out.prompt.includes('{{input}}')) out.prompt += '\n\n{{input}}';
  } else {
    out.code = String(d.code || '').replace(/^```\w*\n?|```\s*$/g, '').trim();
    if (!/\bfunction\s+run\s*\(|\brun\s*=\s*(?:async\s*)?(?:function|\()/.test(out.code)) throw new Error('A code skill must define function run(input).');
    if (out.code.length > MAX_CODE) throw new Error('The skill code is too long.');
    const bad = FORBIDDEN_CODE.exec(out.code);
    if (bad) throw new Error(`The skill code uses “${bad[0].replace(/\s*\($/, '')}”, which skills are not allowed to use.`);
    if (!out.tests.length) throw new Error('A code skill needs at least one test.');
  }
  return out;
}

const fillPrompt = (prompt, input) => String(prompt).split('{{input}}').join(String(input));

const { parseSkillCall, parseSkillRequest } = require('../renderer/commands');

/** Test results: [{input, expect, output, ok, error}] */
async function runTests(skill, runner) {
  const out = [];
  for (const t of skill.tests) {
    try {
      const output = String(await runner(skill, t.input));
      out.push({ ...t, output: output.slice(0, 2000), ok: !t.expect || output.toLowerCase().includes(t.expect.toLowerCase()) });
    } catch (e) { out.push({ ...t, output: '', ok: false, error: e.message }); }
  }
  return out;
}

class Skills {
  constructor(dir) { this.file = path.join(dir, 'skills.json'); }
  list() { try { const a = JSON.parse(fs.readFileSync(this.file, 'utf8')); return Array.isArray(a) ? a : []; } catch { return []; } }
  _write(a) { const tmp = this.file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(a, null, 1), 'utf8'); fs.renameSync(tmp, this.file); }
  byCommand(cmd) { return this.list().find((s) => s.command === String(cmd).toLowerCase()) || null; }
  /** Installs a validated skill; an existing skill with the same command becomes the previous version. */
  install(clean, testResults = []) {
    const a = this.list();
    const i = a.findIndex((s) => s.command === clean.command);
    const now = Date.now();
    if (i >= 0) {
      const old = a[i];
      const { history = [], ...prev } = old;
      a[i] = { ...clean, id: old.id, enabled: true, version: (old.version || 1) + 1, createdAt: old.createdAt, updatedAt: now, testResults, history: [prev, ...history].slice(0, 10) };
    } else a.push({ ...clean, id: crypto.randomUUID(), enabled: true, version: 1, createdAt: now, updatedAt: now, testResults, history: [] });
    this._write(a);
    return a[i >= 0 ? i : a.length - 1];
  }
  rollback(id) {
    const a = this.list();
    const s = a.find((x) => x.id === id);
    if (!s) throw new Error('Skill not found.');
    if (!s.history || !s.history.length) throw new Error('This skill has no earlier version.');
    const [prev, ...rest] = s.history;
    Object.keys(s).forEach((k) => { if (!['id', 'createdAt'].includes(k)) delete s[k]; });
    Object.assign(s, prev, { id: s.id, updatedAt: Date.now(), history: rest, enabled: true });
    this._write(a);
    return s;
  }
  setEnabled(id, on) { const a = this.list(); const s = a.find((x) => x.id === id); if (!s) throw new Error('Skill not found.'); s.enabled = Boolean(on); this._write(a); return s; }
  remove(id) { const a = this.list(); const b = a.filter((x) => x.id !== id); this._write(b); return a.length - b.length; }
}

module.exports = { RESERVED, COMMAND_RE, FORBIDDEN_CODE, drafterPrompt, validateSkill, fillPrompt, parseSkillCall, parseSkillRequest, runTests, Skills };
