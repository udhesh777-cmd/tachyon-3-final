'use strict';
// Settings and conversation storage (JSON files in the app's data folder).
// API keys (one per model slot) are encrypted with the operating system's secure storage (Electron safeStorage).
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const SLOTS = ['text', 'vision'];
const baseSlot = () => ({ provider: 'local', preset: 'custom', baseUrl: '', model: '', host: '127.0.0.1', port: '11434' });

const DEFAULTS = {
  models: { text: baseSlot(), vision: { ...baseSlot(), mode: 'same' } }, // vision.mode: 'same' (use the text model) | 'separate'
  timeoutSec: 60, systemPrompt: '', folders: [],
  overlayEnabled: true,
  aiEditMode: 'apply',   // 'apply' (write directly, backup always made) | 'review' (show proposal first)
  imageBackend: 'none',  // 'none' | 'a1111' | 'invokeai' | 'openai' | 'gemini'
  imageUrl: 'http://127.0.0.1:7860', imageModel: '', imageSteps: 20, imageWidth: 512, imageHeight: 512, imageNegative: '',
  theme: 'dark',         // 'dark' | 'light' | 'system'
  fontSize: 14,
  permissions: {},      // per-category 'allow' | 'ask' | 'deny' (see core/permissions.js)
  memoryEnabled: true,   // add 'remember …' facts to the system prompt
  customApps: [], projects: [], activeProject: null, sidebarCollapsed: false, // Applications panel + Project Workspace (see core/agent.js)
  voiceModel: '', voiceWake: false, voiceAutoRead: false, voiceName: '', voiceRate: 1, voiceWakeWord: '', // offline voice (Settings → Voice)
};

/** Accepts settings written by older versions (single provider + optional visionModel). */
function normalize(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  const out = { ...DEFAULTS, ...r };
  let text;
  let vision;
  if (r.models && r.models.text) {
    text = { ...baseSlot(), ...r.models.text };
    vision = { ...baseSlot(), mode: 'same', ...(r.models.vision || {}) };
  } else {
    const local = r.provider === 'local';
    text = {
      ...baseSlot(), provider: local ? 'local' : r.provider === 'cloud' ? 'cloud' : 'local', preset: r.cloudPreset === 'gemini' ? 'gemini' : 'custom',
      baseUrl: r.baseUrl || '', model: local ? (r.localModel || '') : (r.model || ''), host: r.host || '127.0.0.1', port: r.port || '11434',
    };
    vision = r.visionModel ? { ...text, model: r.visionModel, mode: 'separate' } : { ...baseSlot(), mode: 'same' };
  }
  out.models = { text, vision };
  for (const k of ['provider', 'baseUrl', 'model', 'host', 'port', 'localModel', 'cloudPreset', 'visionModel']) delete out[k];
  return out;
}

class Store {
  constructor(dir, safeStorage) {
    this.dir = dir;
    this.safe = safeStorage;
    this.sessionKeys = { text: '', vision: '' }; // used only when secure storage is unavailable
    fs.mkdirSync(dir, { recursive: true });
    this.settingsFile = path.join(dir, 'settings.json');
    this.convFile = path.join(dir, 'conversations.json');
    this.journalFile = path.join(dir, 'last-sort.json');
  }

  keyFile(slot) { return path.join(this.dir, slot === 'vision' ? 'apikey-vision.bin' : 'apikey.bin'); }

  _read(file, fallback) {
    try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
  }
  _write(file, data) {
    const tmp = file + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data), 'utf8');
    fs.renameSync(tmp, file);
  }

  getSettings() { return normalize(this._read(this.settingsFile, {})); }
  saveSettings(patch) {
    const cur = this.getSettings();
    const next = { ...cur, ...patch };
    if (patch.models) next.models = { text: { ...cur.models.text, ...patch.models.text }, vision: { ...cur.models.vision, ...patch.models.vision } };
    this._write(this.settingsFile, next);
    return next;
  }

  secureAvailable() { return Boolean(this.safe && this.safe.isEncryptionAvailable()); }
  setApiKey(slot, key) {
    if (!SLOTS.includes(slot)) throw new Error('Unknown model slot.');
    if (!key) return this.deleteApiKey(slot);
    if (this.secureAvailable()) {
      fs.writeFileSync(this.keyFile(slot), this.safe.encryptString(key));
      this.sessionKeys[slot] = '';
      return { persisted: true };
    }
    this.sessionKeys[slot] = key;
    return { persisted: false };
  }
  getApiKey(slot) {
    if (this.sessionKeys[slot]) return this.sessionKeys[slot];
    try { return this.safe.decryptString(fs.readFileSync(this.keyFile(slot))); } catch { return ''; }
  }
  hasApiKey(slot) { return Boolean(this.sessionKeys[slot]) || fs.existsSync(this.keyFile(slot)); }
  deleteApiKey(slot) {
    this.sessionKeys[slot] = '';
    try { fs.unlinkSync(this.keyFile(slot)); } catch { /* none stored */ }
    return { persisted: false };
  }

  // ---- conversations: { id, title, createdAt, updatedAt, messages: [{role, content, attachments, images, edits, route, error, note, ts}] }
  listConversations() {
    return this._read(this.convFile, []).map(({ id, title, updatedAt }) => ({ id, title, updatedAt }))
      .sort((a, b) => b.updatedAt - a.updatedAt);
  }
  getConversation(id) { return this._read(this.convFile, []).find((c) => c.id === id) || null; }
  saveConversation(conv) {
    const all = this._read(this.convFile, []);
    const c = { ...conv, id: conv.id || crypto.randomUUID(), updatedAt: Date.now(), createdAt: conv.createdAt || Date.now() };
    const i = all.findIndex((x) => x.id === c.id);
    if (i >= 0) all[i] = c; else all.push(c);
    this._write(this.convFile, all);
    return c;
  }
  renameConversation(id, title) {
    const all = this._read(this.convFile, []);
    const c = all.find((x) => x.id === id);
    if (c) { c.title = String(title).slice(0, 80); this._write(this.convFile, all); }
  }
  deleteConversation(id) { this._write(this.convFile, this._read(this.convFile, []).filter((c) => c.id !== id)); }
  clearConversations() { this._write(this.convFile, []); }
}

module.exports = { Store, DEFAULTS, normalize, SLOTS };
