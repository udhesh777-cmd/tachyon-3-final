'use strict';
// Multi-step tasks: the Text model turns a request into a short plan of known tools, the user sees the plan, and
// only then Tachyon runs it step by step (each step checked against Settings → Permissions) with an Undo for the whole task.

/** Tool name -> { args: {name: 'path'|'text'|'format'|...}, required: [...], label, category } */
const TOOLS = {
  list_folder: { args: { path: 'path' }, required: ['path'], label: 'List folder', category: 'files.read' },
  search_files: { args: { query: 'text', mode: 'text' }, required: ['query'], label: 'Search files', category: 'files.read' },
  read_file: { args: { path: 'path' }, required: ['path'], label: 'Read file', category: 'files.read' },
  ai_write: { args: { instruction: 'text', input: 'text' }, required: ['instruction'], label: 'Write with AI', category: null },
  save_text: { args: { text: 'text', location: 'path', filename: 'text', format: 'text' }, required: ['text'], label: 'Save to file', category: 'files.create' },
  edit_file: { args: { path: 'path', instruction: 'text' }, required: ['path', 'instruction'], label: 'Edit file with AI', category: 'files.edit' },
  convert_file: { args: { path: 'path', format: 'text' }, required: ['path', 'format'], label: 'Convert file', category: 'files.create' },
  make_folder: { args: { path: 'path' }, required: ['path'], label: 'Create folder', category: 'files.create' },
  copy_file: { args: { from: 'path', to: 'path' }, required: ['from', 'to'], label: 'Copy file', category: 'files.create' },
  move_file: { args: { from: 'path', to: 'path' }, required: ['from', 'to'], label: 'Move file', category: 'files.move' },
  organize_folder: { args: { path: 'path', mode: 'text' }, required: ['path'], label: 'Organize folder', category: 'files.move' },
  open_app: { args: { name: 'text' }, required: ['name'], label: 'Open app', category: 'apps.open' },
  open_file: { args: { path: 'path' }, required: ['path'], label: 'Open file', category: 'files.open' },
  remind: { args: { text: 'text', when: 'text' }, required: ['text', 'when'], label: 'Set reminder', category: 'reminders' },
};
const MAX_STEPS = 12;

function plannerPrompt({ folders = [], known = {}, platform = 'win32' } = {}) {
  const tools = Object.entries(TOOLS).map(([n, t]) => `- ${n}(${Object.keys(t.args).map((a) => (t.required.includes(a) ? a : a + '?')).join(', ')})`).join('\n');
  return [
    'You are the task planner of Tachyon, a desktop assistant. Turn the user\'s request into a short plan using ONLY these tools:',
    tools,
    'Notes:',
    '- ai_write writes text (a summary, letter, list, code…) from an instruction; "input" may contain earlier results.',
    '- Use "$N" inside a text argument to insert the result of step N (for example "text": "$2").',
    '- save_text saves text as a file: "location" is a folder (desktop, documents, downloads or a full path), "filename" like "notes.docx", "format" one of pdf, docx, txt, md, html, csv, json.',
    '- search_files "mode" is "name" (file names) or "inside" (text inside files).',
    '- organize_folder "mode" is "type" or "date". remind "when" is like "in 10 minutes", "tomorrow at 9am".',
    '- Never delete files. Never run shells or scripts. If the request needs something these tools cannot do, leave it out and say so in "note".',
    `- The user is on ${platform === 'win32' ? 'Windows' : platform}. Granted folders: ${folders.length ? folders.join('; ') : '(none yet)'}. Known folders: ${Object.entries(known).map(([k, v]) => `${k}=${v}`).join('; ')}.`,
    `Reply with ONLY JSON, no prose: {"title": "short title", "steps": [{"tool": "name", "args": {…}, "why": "one short sentence"}], "note": "optional"}. At most ${MAX_STEPS} steps.`,
  ].join('\n');
}

/** Pulls the first JSON object out of a model reply (code fences and chatter are ignored). */
function extractJson(reply) {
  const t = String(reply || '');
  const fence = /```(?:json)?\s*([\s\S]*?)```/i.exec(t);
  const src = fence ? fence[1] : t;
  const start = src.indexOf('{');
  if (start < 0) throw new Error('The model did not return a plan.');
  let depth = 0;
  let inStr = false;
  for (let i = start; i < src.length; i++) {
    const c = src[i];
    if (inStr) { if (c === '\\') i++; else if (c === '"') inStr = false; continue; }
    if (c === '"') inStr = true;
    else if (c === '{') depth++;
    else if (c === '}' && --depth === 0) return JSON.parse(src.slice(start, i + 1));
  }
  throw new Error('The model returned an incomplete plan.');
}

/** Validates a plan. Returns { title, steps: [{tool, args, why, label, category}], note } or throws a readable error. */
function parsePlan(reply) {
  let obj;
  try { obj = typeof reply === 'object' && reply ? reply : extractJson(reply); } catch (e) { throw new Error(e instanceof SyntaxError ? 'The model returned a plan that is not valid JSON. Try again or rephrase.' : e.message); }
  const raw = Array.isArray(obj.steps) ? obj.steps : [];
  if (!raw.length) throw new Error(obj.note ? String(obj.note) : 'I could not turn that into steps I can run.');
  if (raw.length > MAX_STEPS) throw new Error(`The plan has ${raw.length} steps; the limit is ${MAX_STEPS}. Split the task into smaller parts.`);
  const steps = raw.map((s, i) => {
    const name = String((s && (s.tool || s.action)) || '').trim();
    const def = TOOLS[name];
    if (!def) throw new Error(`Step ${i + 1} uses “${name || '?'}”, which Tachyon cannot do.`);
    const args = {};
    for (const k of Object.keys(def.args)) {
      const v = s.args ? s.args[k] : undefined;
      if (v == null || v === '') continue;
      args[k] = String(typeof v === 'object' ? JSON.stringify(v) : v).slice(0, 20000);
    }
    for (const k of def.required) if (!(k in args)) throw new Error(`Step ${i + 1} (${name}) is missing “${k}”.`);
    for (const [k, v] of Object.entries(args)) {
      for (const m of v.matchAll(/\$(\d+)/g)) if (Number(m[1]) < 1 || Number(m[1]) > i) throw new Error(`Step ${i + 1} refers to the result of step ${m[1]}, which does not come before it.`);
      if (def.args[k] === 'path' && /\0/.test(v)) throw new Error(`Step ${i + 1} has an invalid path.`);
    }
    return { tool: name, args, why: String((s && s.why) || '').slice(0, 300), label: def.label, category: def.category };
  });
  return { title: String(obj.title || 'Task').slice(0, 120), steps, note: obj.note ? String(obj.note).slice(0, 500) : '' };
}

/** Replaces $N with the text result of step N. */
function fillRefs(value, results) {
  return String(value).replace(/\$(\d+)/g, (m, n) => {
    const r = results[Number(n) - 1];
    return r == null ? m : String(typeof r === 'object' ? (r.text ?? r.path ?? JSON.stringify(r)) : r);
  });
}

const { isTaskRequest } = require('../renderer/commands');

module.exports = { TOOLS, MAX_STEPS, plannerPrompt, extractJson, parsePlan, fillRefs, isTaskRequest };
