'use strict';
// Offline speech recognition models (Vosk, Apache-2.0). Models are downloaded once from alphacephei.com or imported
// from a .zip/.tar.gz the user already has, converted to the .tar.gz layout the in-app recognizer reads, and kept in
// userData/models. Recognition itself runs inside Tachyon (WebAssembly); no audio ever leaves the computer.
const fs = require('fs');
const path = require('path');
const fflate = require('fflate');

const CATALOG = [
  { id: 'en-us', label: 'English (US), small', lang: 'en-US', file: 'vosk-model-small-en-us-0.15', sizeMb: 40 },
  { id: 'en-in', label: 'English (India), small', lang: 'en-IN', file: 'vosk-model-small-en-in-0.4', sizeMb: 36 },
  { id: 'hi', label: 'Hindi, small', lang: 'hi-IN', file: 'vosk-model-small-hi-0.22', sizeMb: 42 },
];
const MODEL_URL = (file) => `https://alphacephei.com/vosk/models/${file}.zip`;
const ID_RE = /^[a-z0-9][a-z0-9-]{0,40}$/;

/** Finds the folder inside an archive listing that holds the model (the one with am/ or conf/model.conf). */
function modelRoot(names) {
  const markers = names.filter((n) => /(^|\/)(am\/final\.mdl|conf\/model\.conf|graph\/HCLr?\.fst|final\.mdl)$/.test(n));
  if (!markers.length) throw new Error('This does not look like a Vosk speech model (no am/final.mdl or conf/model.conf inside).');
  const roots = markers.map((n) => n.replace(/(am\/final\.mdl|conf\/model\.conf|graph\/HCLr?\.fst|final\.mdl)$/, ''));
  return roots.sort((a, b) => a.length - b.length)[0];
}

/**
 * Writes a minimal POSIX ustar archive: entries [{name, data: Uint8Array}]. Every parent folder gets its own entry
 * (mode 755): the recognizer cannot open files in folders that were only implied.
 */
function tarPack(entries, mtime = Math.floor(Date.now() / 1000)) {
  const blocks = [];
  const enc = new TextEncoder();
  const octal = (n, len) => n.toString(8).padStart(len - 1, '0') + '\0';
  const dirs = new Set();
  for (const e of entries) {
    const parts = e.name.split('/').slice(0, -1);
    for (let i = 1; i <= parts.length; i++) dirs.add(parts.slice(0, i).join('/') + '/');
  }
  const all = [...[...dirs].sort().map((name) => ({ name, dir: true, data: new Uint8Array(0) })), ...entries];
  for (const e of all) {
    let name = e.name;
    let prefix = '';
    if (enc.encode(name).length > 100) {
      const cut = name.lastIndexOf('/', 154);
      if (cut < 0 || enc.encode(name.slice(cut + 1)).length > 100) throw new Error('A file name inside the model is too long: ' + name);
      prefix = name.slice(0, cut);
      name = name.slice(cut + 1);
    }
    const h = new Uint8Array(512);
    const put = (str, off, len) => h.set(enc.encode(str).slice(0, len), off);
    put(name, 0, 100);
    put(e.dir ? '0000755\0' : '0000644\0', 100, 8); put('0000000\0', 108, 8); put('0000000\0', 116, 8);
    put(octal(e.data.length, 12), 124, 12);
    put(octal(mtime, 12), 136, 12);
    put('        ', 148, 8);
    put(e.dir ? '5' : '0', 156, 1);
    put('ustar\0', 257, 6); put('00', 263, 2);
    put(prefix, 345, 155);
    let sum = 0;
    for (const b of h) sum += b;
    put(sum.toString(8).padStart(6, '0') + '\0 ', 148, 8);
    blocks.push(h);
    if (e.data.length) blocks.push(e.data);
    const pad = (512 - (e.data.length % 512)) % 512;
    if (pad) blocks.push(new Uint8Array(pad));
  }
  blocks.push(new Uint8Array(1024));
  const total = blocks.reduce((n, b) => n + b.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const b of blocks) { out.set(b, off); off += b.length; }
  return out;
}

/** Reads a ustar/gnu tar into [{name, data}] (regular files only). */
function tarUnpack(buf) {
  const out = [];
  const dec = new TextDecoder();
  let off = 0;
  let longName = null;
  while (off + 512 <= buf.length) {
    const h = buf.subarray(off, off + 512);
    if (h.every((b) => b === 0)) break;
    const str = (o, l) => dec.decode(h.subarray(o, o + l)).replace(/\0[\s\S]*$/, '');
    const size = parseInt(str(124, 12).trim() || '0', 8);
    const type = String.fromCharCode(h[156] || 48);
    let name = str(0, 100);
    const prefix = str(345, 155);
    if (prefix && str(257, 5) === 'ustar') name = prefix + '/' + name;
    const data = buf.subarray(off + 512, off + 512 + size);
    if (type === 'L') longName = dec.decode(data).replace(/\0[\s\S]*$/, '');
    else {
      if (longName) { name = longName; longName = null; }
      if (type === '0' || type === '\0') out.push({ name, data });
    }
    off += 512 + Math.ceil(size / 512) * 512;
  }
  return out;
}

/**
 * Any Vosk model archive (.zip from alphacephei, .tar.gz, or a zip without a top folder) -> .tar.gz with a single
 * top-level "model/" folder, the layout the recognizer expects.
 */
function toModelTarGz(bytes, fileName = '') {
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let files;
  if (u8[0] === 0x50 && u8[1] === 0x4b) {
    const z = fflate.unzipSync(u8);
    files = Object.entries(z).filter(([n]) => !n.endsWith('/')).map(([name, data]) => ({ name, data }));
  } else if (u8[0] === 0x1f && u8[1] === 0x8b) files = tarUnpack(fflate.gunzipSync(u8));
  else throw new Error(`${fileName || 'This file'} is not a .zip or .tar.gz model archive.`);
  const names = files.map((f) => f.name.replace(/\\/g, '/').replace(/^\.\//, ''));
  const root = modelRoot(names);
  const entries = [];
  files.forEach((f, i) => {
    const n = names[i];
    if (!n.startsWith(root) || n.includes('../')) return;
    const rel = n.slice(root.length);
    if (rel) entries.push({ name: 'model/' + rel, data: f.data });
  });
  return fflate.gzipSync(tarPack(entries), { level: 1 });
}

class ModelStore {
  constructor(dir) { this.dir = dir; fs.mkdirSync(dir, { recursive: true }); }
  file(id) { if (!ID_RE.test(id)) throw new Error('Invalid model id.'); return path.join(this.dir, id + '.tar.gz'); }
  meta() { try { return JSON.parse(fs.readFileSync(path.join(this.dir, 'models.json'), 'utf8')); } catch { return {}; } }
  _saveMeta(m) { fs.writeFileSync(path.join(this.dir, 'models.json'), JSON.stringify(m), 'utf8'); }
  list() {
    const meta = this.meta();
    const out = CATALOG.map((c) => ({ ...c, url: MODEL_URL(c.file), installed: fs.existsSync(this.file(c.id)), version: meta[c.id] ? meta[c.id].version : null }));
    for (const [id, m] of Object.entries(meta)) {
      if (!CATALOG.some((c) => c.id === id) && fs.existsSync(this.file(id))) out.push({ id, label: m.label || id, lang: m.lang || '', installed: true, imported: true, version: m.version });
    }
    return out;
  }
  save(id, tgz, info = {}) {
    const f = this.file(id);
    fs.writeFileSync(f + '.tmp', tgz);
    fs.renameSync(f + '.tmp', f);
    const meta = this.meta();
    meta[id] = { ...info, version: Date.now(), bytes: tgz.length };
    this._saveMeta(meta);
    return meta[id];
  }
  remove(id) {
    try { fs.unlinkSync(this.file(id)); } catch { /* already gone */ }
    const meta = this.meta();
    delete meta[id];
    this._saveMeta(meta);
    return true;
  }
}

module.exports = { CATALOG, MODEL_URL, modelRoot, tarPack, tarUnpack, toModelTarGz, ModelStore };
