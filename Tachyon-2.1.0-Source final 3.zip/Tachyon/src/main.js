'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, safeStorage, nativeImage, Notification, protocol, net, session, globalShortcut } = require('electron');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const fs = require('fs');
const { Store } = require('./core/store');
const providers = require('./core/providers');
const F = require('./core/fsTools');
const { createPdf } = require('./core/pdf');
const { exportToPath } = require('./core/exporters');
const { analyzeFile } = require('./core/analyze');
const FE = require('./core/fileEdits');
const imageGen = require('./core/imageGen');
const { createOverlayController } = require('./overlay');
const R = require('./core/router');
const rules = require('./core/rules');
const SaveT = require('./core/saveTarget');
const { migrateUserData } = require('./core/migrate');
const { AuditLog } = require('./core/audit');
const Perm = require('./core/permissions');
const { Memory } = require('./core/memory');
const { parseReminder, Reminders } = require('./core/reminders');
const Computer = require('./core/computer');
const Tasks = require('./core/tasks');
const Skills = require('./core/skills');
const Voice = require('./core/voiceModels');
const Agent = require('./core/agent');
const AgentUtil = require('./core/connectors/util');
const { parseAgentCommand } = require('./renderer/agentIntent');

let store;
let audit;
let memory;
let reminders;
let skills;
let agent;
let models;
let win;
let overlay;
let quitting = false;
const aborts = new Map();       // requestId -> AbortController
const createdPaths = new Set(); // files the user chose to create via a Save dialog
const extraAllowed = new Set(); // files/folders the user picked or named in the chat and allowed for this session
let scanToken = null;

// CI smoke test (TACHYON_SMOKE_TEST=1): start with a throw-away profile, load the real window, check the IPC bridge and the new
// agent layer, print TACHYON_SMOKE_OK and exit. Nothing is launched on the computer and nothing is written outside the temp profile.
const SMOKE = process.env.TACHYON_SMOKE_TEST === '1';
if (SMOKE) app.setPath('userData', path.join(os.tmpdir(), 'tachyon-smoke-' + process.pid));

if (!SMOKE && !app.requestSingleInstanceLock()) app.quit();
// Offline speech models are served to the in-app recognizer from userData/models (read-only, nothing else is reachable).
protocol.registerSchemesAsPrivileged([{ scheme: 'tachyon-model', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true } }]);

const SETTING_KEYS = [
  'timeoutSec', 'systemPrompt', 'overlayEnabled', 'aiEditMode', 'imageBackend', 'imageUrl', 'imageModel', 'imageSteps', 'imageWidth', 'imageHeight', 'imageNegative',
  'theme', 'fontSize', 'permissions', 'memoryEnabled',
  'voiceModel', 'voiceWake', 'voiceAutoRead', 'voiceName', 'voiceRate', 'voiceWakeWord',
  'sidebarCollapsed',
];
const SLOT_NAMES = ['text', 'vision'];
const VISION_HINT = 'Images need a vision-capable model. Text-only models (for example qwen2.5) cannot read images. In Settings → “Vision / OCR / screen model” choose a separate vision model (for Ollama, for example qwen2.5vl:3b or minicpm-v after “ollama pull”) or a Gemini Flash model.';
const IMG_EXT = new Set(['png', 'jpg', 'jpeg']);
const extOf = (p) => path.extname(p).slice(1).toLowerCase();

// ---------------------------------------------------------------- app-owned folders
const dirOf = (name) => { const d = path.join(app.getPath('userData'), name); fs.mkdirSync(d, { recursive: true }); return d; };
const roots = () => [...store.getSettings().folders, ...extraAllowed];
const allowedImageRoots = () => [...roots(), dirOf('captures'), dirOf('generated')];

function cleanOldCaptures() {
  try {
    const dir = dirOf('captures');
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f);
      if (Date.now() - fs.statSync(p).mtimeMs > 14 * 86400000) fs.unlinkSync(p);
    }
  } catch { /* best effort */ }
}

// ---------------------------------------------------------------- windows
function createWindow() {
  win = new BrowserWindow({
    width: 1180, height: 780, minWidth: 900, minHeight: 600, backgroundColor: '#070912', title: 'Tachyon',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true,
    },
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
  // With the floating button on, closing the window keeps Tachyon running in the background (quit from the tray or panel).
  win.on('close', (e) => { if (!quitting && overlay && overlay.isRunning()) { e.preventDefault(); win.hide(); } });
}

function showMain() {
  if (!win || win.isDestroyed()) createWindow();
  else { if (win.isMinimized()) win.restore(); win.show(); win.focus(); }
}

function quitApp() { quitting = true; app.quit(); }

// ---------------------------------------------------------------- helpers
const getKey = (slot) => store.getApiKey(slot);
/** Picks the configured model for a request: images -> Vision model, everything else -> Text model. */
const routeFor = (hasImages) => R.route(store.getSettings(), getKey, { hasImages });
const textCfg = () => R.slotConfig(store.getSettings(), 'text', getKey);

/** Config for "Test connection" / "List models": values typed in Settings override the saved ones. */
function overrideCfg(slot, o = {}) {
  const base = R.slotConfig(store.getSettings(), slot, getKey);
  return {
    ...base,
    kind: o.provider ? (o.provider === 'cloud' ? 'cloud' : 'local') : base.kind,
    baseUrl: o.baseUrl ?? base.baseUrl, model: o.model ?? base.model, host: o.host ?? base.host, port: o.port ?? base.port,
    preset: o.preset ?? base.preset,
    timeoutSec: o.timeoutSec ? Number(o.timeoutSec) : base.timeoutSec,
    apiKey: o.apiKey && String(o.apiKey).trim() ? String(o.apiKey).trim() : base.apiKey,
  };
}

/** A tiny solid-red JPEG used to check that a model can really read images. */
function redTestImageB64() {
  const w = 32;
  const buf = Buffer.alloc(w * w * 4);
  for (let i = 0; i < w * w; i++) { buf[i * 4] = 0; buf[i * 4 + 1] = 0; buf[i * 4 + 2] = 255; buf[i * 4 + 3] = 255; } // BGRA
  return nativeImage.createFromBitmap(buf, { width: w, height: w }).toJPEG(90).toString('base64');
}

// ---------------------------------------------------------------- permissions + audit log
const str = (v) => (v == null ? '' : typeof v === 'string' ? v : v.path || v.folder || JSON.stringify(v).slice(0, 300));
/** channel -> what it does: category checked against Settings → Permissions (logOnly: just recorded in the activity log). */
const GUARDS = {
  'fs:write': (a) => ({ category: 'files.edit', target: str(a) }),
  'fs:restoreBackup': (p) => ({ category: 'files.edit', target: p }),
  'fs:aiEdit': (a) => ({ category: 'files.edit', target: str(a) }),
  'fs:pdfRewrite': (a) => ({ category: 'files.create', target: str(a) }),
  'fs:applySort': (a) => ({ category: 'files.move', target: str(a) }),
  'fs:undoSort': () => ({ category: 'files.move', target: 'undo last organize' }),
  'fs:readEditable': (p) => ({ category: 'files.read', target: p }),
  'fs:analyze': (p) => ({ category: 'files.read', target: p }),
  'fs:findInside': (a) => ({ category: 'files.read', target: 'search inside files: ' + str(a && a.q) }),
  'files:resolve': (a) => ({ category: 'files.read', target: ((a && a.candidates) || []).map((c) => c.value).join(', ') }),
  'files:pick': () => ({ category: 'files.read', target: 'file picker' }),
  'files:allowDropped': (a) => ({ category: 'files.read', target: (Array.isArray(a) ? a : []).join(', ') }),
  'files:open': (p) => ({ category: 'files.open', target: p }),
  'files:convert': (a) => ({ category: 'files.create', target: str(a) }),
  'export:autoSave': (a) => ({ category: 'files.create', target: a && a.location ? str(a.location.value) : 'Documents' }),
  'image:op': (a) => ({ category: a && a.op === 'resize' ? 'files.edit' : 'files.create', target: str(a) }),
  'fs:reveal': (p) => ({ category: 'files.open', target: p, logOnly: true }),
  'export:save': (a) => ({ category: 'files.create', target: 'Save dialog: ' + str(a && a.title), logOnly: true }),
  'image:saveAs': (p) => ({ category: 'files.create', target: p, logOnly: true }),
  'folders:add': () => ({ category: 'settings', target: 'add folder', logOnly: true }),
  'folders:remove': (p) => ({ category: 'settings', target: 'remove folder ' + p, logOnly: true }),
  'settings:save': () => ({ category: 'settings', target: 'settings saved', logOnly: true }),
  'conv:delete': () => ({ category: 'history', target: 'delete a chat', logOnly: true }),
  'conv:clear': () => ({ category: 'history', target: 'clear all chats', logOnly: true }),
  'memory:add': (t) => ({ category: 'memory', target: str(t), logOnly: true }),
  'memory:delete': () => ({ category: 'memory', target: 'delete a memory', logOnly: true }),
  'memory:forget': (q) => ({ category: 'memory', target: 'forget ' + str(q), logOnly: true }),
  'memory:clear': () => ({ category: 'memory', target: 'clear all memories', logOnly: true }),
  'reminders:add': (a) => ({ category: 'reminders', target: `${str(a && a.text)} at ${a && Number.isFinite(Number(a.at)) ? new Date(Number(a.at)).toLocaleString() : '?'}` }),
  'reminders:delete': () => ({ category: 'reminders', target: 'cancel a reminder', logOnly: true }),
  'apps:open': (n) => ({ category: 'apps.open', target: str(n) }),
  'windows:action': (a) => ({ category: 'windows', target: `${str(a && a.action)} ${str(a && a.target)}`.trim(), logOnly: a && a.action === 'list' }),
  'task:plan': (a) => ({ category: 'tasks', target: str(a && a.text).slice(0, 200), logOnly: true }),
  'task:run': () => ({ category: 'tasks', target: 'run a planned task', logOnly: true }),
  'task:undo': () => ({ category: 'tasks', target: 'undo a task', logOnly: true }),
  'skills:install': () => ({ category: 'skills', target: 'install a skill you approved', logOnly: true }),
  'skills:run': (a) => ({ category: 'skills', target: '/' + str(a && a.command) }),
  'skills:rollback': () => ({ category: 'skills', target: 'roll back a skill', logOnly: true }),
  'skills:toggle': () => ({ category: 'skills', target: 'switch a skill on/off', logOnly: true }),
  'skills:delete': () => ({ category: 'skills', target: 'delete a skill', logOnly: true }),
  'voice:download': (id) => ({ category: 'voice', target: 'download speech model ' + str(id), logOnly: true }),
  'voice:importModel': () => ({ category: 'voice', target: 'import a speech model', logOnly: true }),
  'voice:deleteModel': (id) => ({ category: 'voice', target: 'delete speech model ' + str(id), logOnly: true }),
};

function dialogParent() { return win && !win.isDestroyed() && win.isVisible() ? win : null; }

/** Throws when the category is set to Never, or when it is set to Ask and the user cancels. */
async function guard(category, target) {
  const c = Perm.CATEGORIES[category];
  if (!c) return;
  const perm = Perm.effective(store.getSettings())[category];
  if (perm === 'allow') return;
  if (perm === 'deny') {
    audit.log({ action: 'blocked', category, target, ok: false, decision: 'never' });
    throw new Error(`Blocked by your permission settings: “${c.label}” is set to Never (Settings → Permissions).`);
  }
  const opts = {
    type: 'question', buttons: c.noAllow ? ['Cancel', 'Allow once'] : ['Cancel', 'Allow once', 'Always allow'], defaultId: 1, cancelId: 0,
    message: `Allow Tachyon to: ${c.label}?`, detail: String(target || '').slice(0, 800) + '\n\nYou can change this in Settings → Permissions.',
  };
  const parent = dialogParent();
  const r = parent ? await dialog.showMessageBox(parent, opts) : await dialog.showMessageBox(opts);
  if (r.response === 2 && !c.noAllow) {
    store.saveSettings({ permissions: { ...(store.getSettings().permissions || {}), [category]: 'allow' } });
    audit.log({ action: 'permission', category, target: 'set to Always allow', decision: 'always' });
  }
  if (r.response !== 1 && r.response !== 2) {
    audit.log({ action: 'cancelled', category, target, ok: false, decision: 'cancel' });
    throw new Error('Cancelled. Nothing was changed.');
  }
}

function handle(channel, fn) {
  ipcMain.handle(channel, async (event, ...args) => {
    let g = null;
    try {
      if (!event.senderFrame || !String(event.senderFrame.url).startsWith('file://')) throw new Error('Blocked request.');
      g = GUARDS[channel] ? GUARDS[channel](...args) : null;
      if (g && !g.logOnly) await guard(g.category, g.target);
      const data = await fn(...args);
      if (g) audit.log({ action: channel, category: g.category, target: g.target, detail: data === null ? 'cancelled by you' : undefined });
      return { ok: true, data };
    } catch (err) {
      const msg = err && err.message ? err.message : String(err);
      if (g && !/^(Cancelled|Blocked by your permission)/.test(msg)) audit.log({ action: channel, category: g.category, target: g.target, ok: false, detail: msg });
      return { ok: false, error: msg };
    }
  });
}

/** Any readable PNG/JPEG -> resized JPEG as base64 (for vision models). */
function visionB64(src) {
  const img = typeof src === 'string' ? nativeImage.createFromPath(src) : nativeImage.createFromBuffer(src);
  if (img.isEmpty()) throw new Error('This image cannot be read. Use a PNG or JPEG image.');
  const { width } = img.getSize();
  return (width > 1600 ? img.resize({ width: 1600, quality: 'good' }) : img).toJPEG(80).toString('base64');
}

async function chatWithHint(cfg, messages, opts, hasImages) {
  try { return await providers.chat(cfg, messages, opts); } catch (e) {
    if (hasImages && e instanceof providers.AiError && !/Cancelled/.test(e.message)) throw new Error(e.message + ' ' + VISION_HINT);
    throw e;
  }
}

async function buildApiMessages(messages, { allowEdits = false } = {}) {
  const s = store.getSettings();
  let budget = 150000;
  let imagesUsed = false;
  let sentFiles = 0;
  let editable = [];
  const processed = [];
  // Images are sent only with the newest question. Follow-up text questions go to the Text model, which sees the
  // Vision model's earlier answer in the history instead of the picture.
  // Reading attached files follows Settings → Permissions ("Read files"); when blocked, the model is told the file was not read.
  const attNames = messages.filter((m) => m.role === 'user' && !m.note && Array.isArray(m.attachments))
    .flatMap((m) => m.attachments).filter((x) => x && !IMG_EXT.has(extOf(String(x.path)))).map((x) => path.basename(String(x.path)));
  let readBlocked = null;
  if (attNames.length) { try { await guard('files.read', [...new Set(attNames)].join(', ')); } catch (e) { readBlocked = e.message; } }
  let lastUser = -1;
  for (let i = messages.length - 1; i >= 0; i--) if (messages[i].role === 'user' && !messages[i].error && !messages[i].note) { lastUser = i; break; }
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i];
    if (m.error || m.note) continue;
    let content = String(m.content || '');
    let images;
    if (m.role === 'user') {
      const atts = Array.isArray(m.attachments) ? m.attachments : [];
      const imgPaths = [...(Array.isArray(m.images) ? m.images : []).map((x) => x.path), ...atts.filter((a) => IMG_EXT.has(extOf(a.path))).map((a) => a.path)];
      if (imgPaths.length) {
        if (!imagesUsed && i === lastUser) {
          imagesUsed = true;
          images = [];
          for (const p of imgPaths.slice(0, 3)) {
            try { F.assertInside(allowedImageRoots(), p); images.push(visionB64(p)); } catch (e) { content += `\n[Image ${path.basename(p)} could not be used: ${e.message}]`; }
          }
        } else content = '[An image was attached here earlier and is not re-sent.]\n' + content;
      }
      const blocks = [];
      for (const a of atts.filter((x) => !IMG_EXT.has(extOf(x.path)))) {
        const name = path.basename(String(a.path));
        if (readBlocked) { blocks.push(`[Attached file ${name} was not read: ${readBlocked}]`); continue; }
        try {
          const r = await F.readForAI(roots(), a.path, { maxChars: Math.min(60000, Math.max(2000, budget)) });
          budget -= r.text.length;
          blocks.push(`[Attached file: ${name}${r.truncated ? ' (truncated)' : ''}]\n${r.text || '(no readable text: ' + r.note + ')'}\n[End of file]`);
        } catch (e) { blocks.push(`[Attached file ${name} could not be read: ${e.message}]`); }
      }
      if (blocks.length) { content = blocks.join('\n\n') + '\n\n' + content; sentFiles += blocks.length; }
      if (allowEdits && i === messages.length - 1) {
        editable = atts.filter((a) => F.TEXT_EXT.has(extOf(a.path))).map((a) => a.path);
      }
    }
    const item = { role: m.role === 'assistant' ? 'assistant' : 'user', content };
    if (images && images.length) item.images = images;
    processed.unshift(item);
  }
  const sys = rules.buildSystemPrompt(s.systemPrompt, [memoryBlock(), ...(editable.length ? [FE.editSystemPrompt(editable)] : [])]);
  return { api: [{ role: 'system', content: sys }, ...processed.slice(-40)], editable, hasImages: imagesUsed, sentFiles };
}

function stripFence(t) {
  let r = t.trim();
  if (r.startsWith('```') && r.endsWith('```') && r.length > 6) r = r.slice(r.indexOf('\n') + 1).replace(/```$/, '').trimEnd();
  return r;
}

/** The key used for image backends that need one: a Google key if the backend is Gemini, otherwise the text slot's key. */
function imageKey(backend) {
  const s = store.getSettings();
  if (backend === 'gemini') {
    for (const slot of SLOT_NAMES) {
      const m = s.models[slot];
      if (m.provider === 'cloud' && /generativelanguage\.googleapis\.com/.test(m.baseUrl)) { const k = R.slotConfig(s, slot, getKey).apiKey; if (k) return k; }
    }
    return '';
  }
  return R.slotConfig(s, 'text', getKey).apiKey;
}
const imageCfg = (over = {}) => {
  const s = store.getSettings();
  return {
    backend: s.imageBackend, url: s.imageUrl, steps: s.imageSteps, width: s.imageWidth, height: s.imageHeight, negative: s.imageNegative,
    cloudUrl: s.models.text.baseUrl, apiKey: imageKey(s.imageBackend), model: s.imageModel, ...over,
  };
};

const ANALYSIS_PROMPTS = {
  objects: 'List every distinct object you can detect in this image as a bullet list. For each give a label, a confidence (high/medium/low) and a rough position (for example top-left). Do not invent objects.',
  ocr: 'Transcribe all visible text in this image exactly as written, preserving line breaks. If there is no text, say so.',
  describe: 'Describe this image in detail.',
};

// ---------------------------------------------------------------- chat file access
const OPENABLE = new Set(['txt', 'md', 'csv', 'tsv', 'json', 'xml', 'log', 'rtf', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'odp', 'epub',
  'png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp', 'svg', 'tiff', 'heic', 'mp3', 'wav', 'flac', 'm4a', 'ogg', 'mp4', 'mkv', 'mov', 'webm', 'avi', 'html', 'htm', 'css', 'yml', 'yaml', 'ini', 'toml', 'sql', 'c', 'cpp', 'h', 'java', 'kt', 'go', 'rs', 'cs', 'ts']);
const knownDirs = () => {
  const out = {};
  for (const k of ['desktop', 'documents', 'downloads', 'pictures', 'music', 'videos']) { try { out[k] = app.getPath(k); } catch { /* not on this OS */ } }
  return out;
};
const saveCtx = () => ({ home: os.homedir(), known: knownDirs() });
const isAllowed = (p) => roots().some((r) => F.isInside(r, p));
function allowSession(p, isDir) {
  extraAllowed.add(p);
  if (!isDir) extraAllowed.add(p + '.nova-bak');
}

/** A bare file name from the chat ("budget.xlsx"): look in the granted folders, then directly in Desktop/Documents/Downloads. */
async function findByName(c) {
  const names = [String(c.value), ...(Array.isArray(c.alts) ? c.alts.map(String) : [])].map((n) => n.toLowerCase());
  const token = { cancelled: false };
  const timer = setTimeout(() => { token.cancelled = true; }, 5000);
  let hits = [];
  try {
    if (roots().length) hits = (await F.searchByName(roots(), { q: String(c.value), limit: 500, token })).filter((f) => names.includes(f.name.toLowerCase()));
  } catch { hits = []; } finally { clearTimeout(timer); }
  if (!hits.length) {
    for (const d of Object.values(knownDirs())) {
      for (const n of names) {
        try {
          const hit = fs.readdirSync(d).find((x) => x.toLowerCase() === n);
          if (hit) { const st = fs.statSync(path.join(d, hit)); if (st.isFile()) hits.push({ path: path.join(d, hit), name: hit, mtime: st.mtimeMs }); }
        } catch { /* missing folder */ }
      }
    }
  }
  hits.sort((a, b) => b.name.length - a.name.length || b.mtime - a.mtime);
  return { hit: hits[0] || null, count: hits.filter((h) => hits[0] && h.name.toLowerCase() === hits[0].name.toLowerCase()).length };
}

/** Asks once for files/folders named in the chat or in a task: Cancel, allow for this session, or always allow the folder. */
async function askAccess(need) {
  if (!need.length) return;
  const one = need.length === 1;
  const r = await dialog.showMessageBox(win, {
    type: 'question', buttons: ['Cancel', 'Allow for this session', 'Always allow this folder'], defaultId: 1, cancelId: 0,
    message: one ? `Let Tachyon use this ${need[0].isDir ? 'folder' : 'file'}?` : `Let Tachyon use these ${need.length} items?`,
    detail: need.map((x) => x.path).join('\n') + '\n\nYou named it in the chat. Tachyon only reads or changes what you ask for, keeps a .nova-bak backup before changing a file, and never deletes files.',
  });
  for (const x of need) {
    if (r.response !== 1 && r.response !== 2) { x.denied = true; continue; }
    const folder = x.isDir ? x.path : path.dirname(x.path);
    const broad = path.parse(folder).root === folder || folder === os.homedir();
    if (r.response === 2 && !broad) {
      const f = F.realpathNearest(folder);
      const cur = store.getSettings();
      if (!cur.folders.includes(f)) store.saveSettings({ folders: [...cur.folders, f] });
    } else allowSession(x.path, x.isDir);
    x.allowed = true;
  }
}

const memoryBlock = () => (store.getSettings().memoryEnabled === false ? '' : memory.promptBlock());

// ---------------------------------------------------------------- reminders, apps & windows, multi-step tasks, skills
function notifyReminder(r) {
  audit.log({ action: 'reminder.due', category: 'reminders', target: r.text });
  if (Notification.isSupported()) {
    const n = new Notification({ title: 'Tachyon reminder', body: r.text, icon: path.join(__dirname, 'assets', 'icon.png') });
    n.on('click', showMain);
    n.show();
  }
  if (win && !win.isDestroyed()) win.webContents.send('reminder-due', r);
}
function checkReminders() { try { reminders.takeDue().forEach(notifyReminder); } catch { /* best effort */ } }

const sendTaskProgress = (p) => { if (win && !win.isDestroyed()) win.webContents.send('task-progress', p); };
const tasksDir = () => dirOf('tasks');
const trashDir = (id) => { const d = path.join(tasksDir(), 'undo-' + id); fs.mkdirSync(d, { recursive: true }); return d; };
const pendingPlans = new Map(); // planId -> plan (only plans Tachyon made can be run)
const pendingSkills = new Map(); // draftId -> validated skill draft

/** A path a task step names: "desktop", "Documents/x.txt", "~/x", "C:\x" or a bare name (looked up like in the chat). */
async function taskPath(raw, { mustExist = true } = {}) {
  let v = String(raw || '').trim().replace(/^["“'`]|["”'`]$/g, '');
  const known = knownDirs();
  const k = /^(?:my\s+)?(desktop|documents|downloads|pictures|music|videos)(?:\s+folder)?(?:[\\/](.*))?$/i.exec(v);
  let p = k ? path.join(known[k[1].toLowerCase()] || os.homedir(), k[2] || '') : null;
  if (!p && mustExist && !/[\\/]/.test(v) && /\.\w{1,5}$/.test(v)) {
    const r = await findByName({ value: v });
    if (r.hit) p = r.hit.path;
  }
  if (!p) p = SaveT.expandUserPath({ kind: 'path', value: v }, saveCtx());
  p = path.resolve(p);
  if (mustExist && !fs.existsSync(p)) {
    const alt = SaveT.remapKnownFolder(p, saveCtx());
    if (alt && fs.existsSync(alt)) p = alt; else throw new Error(`I could not find ${v}.`);
  }
  return p;
}
/** Read/change access for an existing path: granted folders, else the same "Allow?" question as in the chat. */
async function ensureAccess(p) {
  if (isAllowed(p)) return;
  const item = { path: p, isDir: fs.statSync(p).isDirectory() };
  await askAccess([item]);
  if (!item.allowed) throw new Error(`You did not allow access to ${p}.`);
}
/** New files may go to granted folders or to the user's own Desktop/Documents/Downloads/… folders (like “save it to my desktop”). */
function assertWritable(p) {
  if (isAllowed(p)) return;
  if (Object.values(knownDirs()).some((d) => F.isInside(d, p))) return;
  throw new Error(`Tachyon only creates files in your granted folders or in Desktop, Documents, Downloads, Pictures, Music and Videos (not ${p}).`);
}

async function runTool(step, ctx) {
  const a = step.args;
  const j = ctx.journal;
  switch (step.tool) {
    case 'list_folder': {
      const p = await taskPath(a.path); await ensureAccess(p);
      const items = await F.listDir(roots(), p);
      return { text: items.map((x) => (x.isDir ? '[folder] ' : '') + x.name).join('\n') || '(empty folder)', summary: `${items.length} item(s) in ${p}` };
    }
    case 'search_files': {
      if (!roots().length) throw new Error('Add a folder in Files & PDFs first so I know where to search.');
      const token = { cancelled: false };
      const timer = setTimeout(() => { token.cancelled = true; }, 20000);
      try {
        const hits = a.mode === 'inside' ? (await F.searchContent(roots(), { q: a.query, token, limit: 30 })).items : await F.searchByName(roots(), { q: a.query, token, limit: 30 });
        return { text: hits.map((h) => h.path).join('\n') || 'No files found.', summary: `${hits.length} file(s) found`, paths: hits.map((h) => h.path) };
      } finally { clearTimeout(timer); }
    }
    case 'read_file': {
      const p = await taskPath(a.path); await ensureAccess(p);
      const r = await F.readForAI(roots(), p, { maxChars: 60000 });
      ctx.readFiles = true;
      return { text: r.text || `(no readable text: ${r.note})`, summary: `read ${path.basename(p)}${r.truncated ? ' (truncated)' : ''}` };
    }
    case 'ai_write': {
      const cfg = textCfg();
      if (cfg.kind === 'cloud' && ctx.readFiles && !ctx.cloudOk) { await guard('cloud.files', 'task: file contents to ' + cfg.model); ctx.cloudOk = true; }
      audit.log({ action: 'ai.request', category: cfg.kind === 'cloud' ? 'cloud' : 'local', target: cfg.model || 'text model', detail: 'task step: ' + a.instruction.slice(0, 120) });
      const out = await providers.chat(cfg, [
        { role: 'system', content: rules.buildSystemPrompt(store.getSettings().systemPrompt, [memoryBlock(), 'You are carrying out one step of a task. Reply with only the requested text, no preamble.']) },
        { role: 'user', content: a.instruction + (a.input ? '\n\n' + a.input : '') },
      ]);
      return { text: out, summary: `${out.length} characters written` };
    }
    case 'save_text': {
      const loc = a.location ? { kind: 'path', value: a.location } : null;
      let plan;
      if (loc) {
        const dir = await taskPath(a.location, { mustExist: false });
        plan = SaveT.planSave({ location: { kind: 'path', value: dir }, filename: a.filename || null, format: a.format || null, title: ctx.title, text: a.text }, saveCtx());
      } else plan = SaveT.planSave({ location: null, filename: a.filename || null, format: a.format || null, title: ctx.title, text: a.text }, saveCtx());
      assertWritable(plan.file);
      fs.mkdirSync(plan.dir, { recursive: true });
      const res = await exportToPath(plan.file, { title: ctx.title, text: a.text });
      createdPaths.add(plan.file);
      j.push({ type: 'created', path: plan.file });
      return { text: plan.file, path: plan.file, summary: `saved ${plan.file}`, ...res };
    }
    case 'edit_file': {
      const p = await taskPath(a.path); await ensureAccess(p);
      const original = await F.readEditable(roots(), p);
      const cfg = textCfg();
      if (cfg.kind === 'cloud' && !ctx.cloudOk) { await guard('cloud.files', 'task: ' + path.basename(p) + ' to ' + cfg.model); ctx.cloudOk = true; }
      const out = stripFence(await providers.chat(cfg, [
        { role: 'system', content: `You are a careful file editor. Apply the instruction to the file '${path.basename(p)}'. Reply with ONLY the complete updated file content: no explanations and no code fences.` },
        { role: 'user', content: `Instruction: ${a.instruction}\n\nFILE CONTENT:\n${original}` }]));
      const bad = FE.validateContent(p, out);
      if (bad) throw new Error(bad);
      const keep = path.join(trashDir(ctx.id), `${j.length}-${path.basename(p)}`);
      fs.writeFileSync(keep, original, 'utf8');
      await F.writeText(roots(), p, out.endsWith('\n') ? out : out + '\n');
      j.push({ type: 'restore', path: p, copy: keep });
      audit.log({ action: 'ai.edit', category: 'files.edit', target: p, detail: 'task step' });
      return { text: p, path: p, summary: `edited ${path.basename(p)} (backup kept)` };
    }
    case 'convert_file': {
      const p = await taskPath(a.path); await ensureAccess(p);
      const fmt = String(a.format).toLowerCase().replace(/^\./, '').replace(/^word$/, 'docx').replace(/^markdown$/, 'md').replace(/^text$/, 'txt');
      if (!['pdf', 'docx', 'md', 'txt', 'html'].includes(fmt)) throw new Error('Documents can be converted to PDF, Word, Markdown, text or HTML.');
      const src = await F.readForAI(roots(), p, { maxChars: 2_000_000 });
      if (!src.text) throw new Error(src.note || 'This file has no readable text.');
      const base = path.basename(p, path.extname(p));
      const dest = F.uniqueDest(path.dirname(p), base + '.' + fmt);
      await exportToPath(dest, { title: base, text: src.text });
      createdPaths.add(dest);
      j.push({ type: 'created', path: dest });
      return { text: dest, path: dest, summary: `created ${path.basename(dest)}` };
    }
    case 'make_folder': {
      const p = await taskPath(a.path, { mustExist: false });
      assertWritable(p);
      if (fs.existsSync(p)) return { text: p, path: p, summary: 'folder already exists' };
      fs.mkdirSync(p, { recursive: true });
      allowSession(p, true);
      j.push({ type: 'dir', path: p });
      return { text: p, path: p, summary: `created folder ${p}` };
    }
    case 'copy_file':
    case 'move_file': {
      const from = await taskPath(a.from); await ensureAccess(from);
      if (fs.statSync(from).isDirectory()) throw new Error('Only files can be copied or moved in a task.');
      let to = await taskPath(a.to, { mustExist: false });
      if (fs.existsSync(to) && fs.statSync(to).isDirectory()) to = F.uniqueDest(to, path.basename(from));
      else if (!path.extname(to)) { fs.mkdirSync(to, { recursive: true }); to = F.uniqueDest(to, path.basename(from)); } else to = F.uniqueDest(path.dirname(to), path.basename(to));
      assertWritable(to);
      fs.mkdirSync(path.dirname(to), { recursive: true });
      if (step.tool === 'copy_file') {
        fs.copyFileSync(from, to, fs.constants.COPYFILE_EXCL);
        j.push({ type: 'created', path: to });
      } else {
        fs.renameSync(from, to);
        j.push({ type: 'moved', from, to });
      }
      allowSession(to, false);
      return { text: to, path: to, summary: `${step.tool === 'copy_file' ? 'copied' : 'moved'} to ${to}` };
    }
    case 'organize_folder': {
      const p = await taskPath(a.path); await ensureAccess(p);
      const plan = await F.planSort(roots(), p, { mode: a.mode === 'date' ? 'date' : 'type' });
      const jf = path.join(tasksDir(), `sort-${ctx.id}-${j.length}.json`);
      const r = await F.applySort(roots(), plan, jf);
      if (r.moved) j.push({ type: 'sort', journal: jf });
      return { text: `${r.moved} file(s) moved`, summary: `organized ${r.moved} file(s)${r.failed ? `, ${r.failed} skipped` : ''}` };
    }
    case 'open_app': {
      const r = Computer.resolveApp(a.name);
      await Computer.launch(r, shell);
      return { text: r.name, summary: `opened ${r.name}` };
    }
    case 'open_file': {
      const p = await taskPath(a.path); await ensureAccess(p);
      if (!fs.statSync(p).isDirectory() && !OPENABLE.has(extOf(p))) throw new Error(`For safety Tachyon does not open .${extOf(p)} files.`);
      const err = await shell.openPath(p);
      if (err) throw new Error(err);
      return { text: p, summary: `opened ${path.basename(p)}` };
    }
    case 'remind': {
      const r = parseReminder(`remind me ${a.when} to ${a.text}`);
      if (!r || !r.at) throw new Error(`I could not understand the time “${a.when}”.`);
      const rem = reminders.add(r.text, r.at);
      j.push({ type: 'reminder', id: rem.id });
      return { text: `${rem.text} at ${new Date(rem.at).toLocaleString()}`, summary: `reminder set for ${new Date(rem.at).toLocaleString()}` };
    }
    default: throw new Error('Unknown step.');
  }
}

function saveTaskRecord(rec) {
  const file = path.join(tasksDir(), 'history.json');
  let a = [];
  try { a = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { a = []; }
  a = [rec, ...a.filter((x) => x.id !== rec.id)].slice(0, 30);
  fs.writeFileSync(file, JSON.stringify(a), 'utf8');
}
function getTaskRecord(id) {
  try { return JSON.parse(fs.readFileSync(path.join(tasksDir(), 'history.json'), 'utf8')).find((x) => x.id === id) || null; } catch { return null; }
}

/** Undoes a finished task in reverse order. New files go to Tachyon's undo folder (never deleted). */
async function undoTask(rec) {
  const done = [];
  const failed = [];
  for (const e of [...rec.journal].reverse()) {
    try {
      if (e.type === 'created') {
        if (fs.existsSync(e.path)) { const dest = F.uniqueDest(trashDir(rec.id), path.basename(e.path)); fs.renameSync(e.path, dest); }
        done.push(`removed ${path.basename(e.path)} (kept in Tachyon's undo folder)`);
      } else if (e.type === 'dir') {
        if (fs.existsSync(e.path) && !fs.readdirSync(e.path).length) fs.rmdirSync(e.path);
        done.push(`removed empty folder ${path.basename(e.path)}`);
      } else if (e.type === 'restore') {
        fs.writeFileSync(e.path, fs.readFileSync(e.copy));
        done.push(`restored ${path.basename(e.path)}`);
      } else if (e.type === 'moved') {
        if (fs.existsSync(e.from)) throw new Error(`${e.from} exists again`);
        fs.mkdirSync(path.dirname(e.from), { recursive: true });
        fs.renameSync(e.to, e.from);
        done.push(`moved ${path.basename(e.from)} back`);
      } else if (e.type === 'sort') {
        const r = await F.undoLastSort([...roots(), path.dirname(e.journal)], e.journal);
        done.push(`put ${r.restored} organized file(s) back`);
      } else if (e.type === 'reminder') {
        reminders.remove(e.id);
        done.push('cancelled the reminder');
      }
    } catch (err) { failed.push(err.message); }
  }
  return { done, failed };
}

/** Runs a code skill in a hidden, sandboxed window: no Node, no preload, no network, 5-second limit. */
function runCodeSkill(code, input) {
  const sb = new BrowserWindow({
    show: false, width: 200, height: 200,
    webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, partition: 'tachyon-skill-sandbox', javascript: true, webgl: false, images: false },
  });
  sb.webContents.session.webRequest.onBeforeRequest((d, cb) => cb({ cancel: !/^data:/.test(d.url) }));
  sb.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  sb.webContents.on('will-navigate', (e) => e.preventDefault());
  const html = '<!doctype html><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\' \'unsafe-eval\'">';
  const done = () => { if (!sb.isDestroyed()) { sb.webContents.forcefullyCrashRenderer(); sb.destroy(); } };
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { done(); reject(new Error('The skill took longer than 5 seconds and was stopped.')); }, 5000);
    sb.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html)).then(() => sb.webContents.executeJavaScript(
      `(async () => { ${code}\n; const r = await run(${JSON.stringify(String(input))}); return typeof r === 'string' ? r : JSON.stringify(r, null, 2); })()`, true))
      .then((r) => { clearTimeout(timer); done(); resolve(String(r ?? '').slice(0, 100000)); })
      .catch((e) => { clearTimeout(timer); done(); reject(new Error('The skill failed: ' + String((e && e.message) || e).replace(/^.*Error:\s*/, ''))); });
  });
}
async function runSkill(skill, input) {
  if (skill.kind === 'code') return runCodeSkill(skill.code, input);
  const cfg = textCfg();
  audit.log({ action: 'ai.request', category: cfg.kind === 'cloud' ? 'cloud' : 'local', target: cfg.model || 'text model', detail: 'skill /' + skill.command });
  return providers.chat(cfg, [
    { role: 'system', content: rules.buildSystemPrompt(store.getSettings().systemPrompt, [memoryBlock()]) },
    { role: 'user', content: Skills.fillPrompt(skill.prompt, input) }]);
}

// ---------------------------------------------------------------- IPC
function register() {
  // ---- safety: permissions, activity log, personal memory
  handle('perms:get', () => ({ categories: Perm.CATEGORIES, effective: Perm.effective(store.getSettings()) }));
  handle('audit:list', ({ limit = 300, category = null } = {}) => audit.list({ limit: Math.min(2000, Number(limit) || 300), category }));
  handle('audit:clear', () => { audit.clear(); audit.log({ action: 'audit.clear', category: 'settings', target: 'activity log cleared' }); return true; });
  handle('memory:list', () => memory.list());
  handle('memory:add', (text) => memory.add(text));
  handle('memory:delete', (id) => memory.remove(String(id)));
  handle('memory:forget', (q) => memory.forget(q));
  handle('memory:clear', () => { memory.clear(); return true; });

  handle('settings:get', () => ({
    settings: store.getSettings(), hasKey: { text: store.hasApiKey('text'), vision: store.hasApiKey('vision') }, secure: store.secureAvailable(),
    version: app.getVersion(), sep: path.sep, home: os.homedir(), overlayRunning: overlay.isRunning(),
  }));
  const cleanSlot = (m = {}, isVision = false) => ({
    provider: m.provider === 'cloud' ? 'cloud' : 'local', preset: m.preset === 'gemini' ? 'gemini' : 'custom',
    baseUrl: String(m.baseUrl || '').trim(), model: String(m.model || '').trim(), host: String(m.host || '').trim(), port: String(m.port || '').trim(),
    ...(isVision ? { mode: m.mode === 'separate' ? 'separate' : 'same' } : {}),
  });
  handle('settings:save', ({ settings = {}, apiKeys = {} } = {}) => {
    const patch = {};
    for (const k of SETTING_KEYS) if (k in settings) patch[k] = settings[k];
    for (const k of ['timeoutSec', 'imageSteps', 'imageWidth', 'imageHeight']) if (k in patch) patch[k] = Number(patch[k]);
    for (const k of ['imageUrl', 'imageModel']) if (k in patch) patch[k] = String(patch[k]).trim();
    if ('overlayEnabled' in patch) patch.overlayEnabled = Boolean(patch.overlayEnabled);
    if ('aiEditMode' in patch && !['apply', 'review'].includes(patch.aiEditMode)) patch.aiEditMode = 'apply';
    if ('theme' in patch && !['dark', 'light', 'system'].includes(patch.theme)) patch.theme = 'dark';
    if ('fontSize' in patch) patch.fontSize = Math.min(20, Math.max(12, Number(patch.fontSize) || 14));
    if ('permissions' in patch) patch.permissions = { ...(store.getSettings().permissions || {}), ...Perm.sanitize(patch.permissions) };
    if ('memoryEnabled' in patch) patch.memoryEnabled = Boolean(patch.memoryEnabled);
    if ('sidebarCollapsed' in patch) patch.sidebarCollapsed = Boolean(patch.sidebarCollapsed);
    for (const k of ['voiceWake', 'voiceAutoRead']) if (k in patch) patch[k] = Boolean(patch[k]);
    if ('voiceModel' in patch) patch.voiceModel = /^[a-z0-9][a-z0-9-]{0,40}$/.test(String(patch.voiceModel)) ? String(patch.voiceModel) : '';
    if ('voiceName' in patch) patch.voiceName = String(patch.voiceName || '').slice(0, 200);
    if ('voiceWakeWord' in patch) patch.voiceWakeWord = String(patch.voiceWakeWord || '').replace(/[^\p{L}\p{N} '-]/gu, '').trim().slice(0, 40);
    if ('voiceRate' in patch) patch.voiceRate = Math.min(2, Math.max(0.5, Number(patch.voiceRate) || 1));
    if ('imageBackend' in patch && !['none', 'a1111', 'invokeai', 'openai', 'gemini'].includes(patch.imageBackend)) patch.imageBackend = 'none';
    if (settings.models) {
      const cur = store.getSettings().models;
      patch.models = {
        text: settings.models.text ? cleanSlot(settings.models.text) : cur.text,
        vision: settings.models.vision ? cleanSlot(settings.models.vision, true) : cur.vision,
      };
    }
    store.saveSettings(patch);
    let persisted = true;
    for (const slot of SLOT_NAMES) {
      const k = apiKeys[slot];
      if (typeof k === 'string' && k.trim()) persisted = store.setApiKey(slot, k.trim()).persisted && persisted;
    }
    if ('overlayEnabled' in patch) { if (patch.overlayEnabled) overlay.start(); else overlay.stop(); }
    return { persisted };
  });
  handle('settings:deleteKey', (slot) => { if (!SLOT_NAMES.includes(slot)) throw new Error('Unknown model slot.'); store.deleteApiKey(slot); return true; });

  // "Test connection": the vision test sends a tiny red image and asks for its colour, a real check that images are understood.
  handle('provider:test', async ({ slot = 'text', vision = false, ...o } = {}) => {
    if (!SLOT_NAMES.includes(slot)) throw new Error('Unknown model slot.');
    const cfg = overrideCfg(slot, o);
    if (!vision) return providers.testConnection(cfg);
    const problem = providers.validate(cfg);
    if (problem) throw new Error(problem);
    let reply;
    try {
      reply = await providers.chat(cfg, [{ role: 'user', content: 'What colour fills this image? Answer with one word.', images: [redTestImageB64()] }]);
    } catch (e) { throw new Error(e.message + ' ' + VISION_HINT); }
    return `Connected. The model looked at a test image and answered: “${reply.slice(0, 80)}”. ` +
      (/red/i.test(reply) ? 'It can read images.' : 'If that is not “red”, this model probably cannot read images; choose a vision model.');
  });
  handle('provider:models', async ({ host, port } = {}) => providers.listOllamaModels({ host, port, timeoutSec: 10 }));
  handle('provider:cloudModels', async ({ slot = 'text', baseUrl, apiKey } = {}) => providers.listCloudModels(overrideCfg(slot, { baseUrl, apiKey })));

  handle('chat:send', async ({ requestId, messages, allowEdits }) => {
    const ctrl = new AbortController();
    aborts.set(requestId, ctrl);
    try {
      const { api, editable, hasImages, sentFiles } = await buildApiMessages(messages, { allowEdits: Boolean(allowEdits) });
      const r = routeFor(hasImages);   // images -> Vision model, text -> Text model (automatic)
      if (r.cfg.kind === 'cloud' && (hasImages || sentFiles)) await guard('cloud.files', `${r.label}: ${sentFiles} file(s)${hasImages ? ' and an image' : ''}`);
      audit.log({ action: 'ai.request', category: r.cfg.kind === 'cloud' ? 'cloud' : 'local', target: r.label, detail: `${sentFiles} file(s)${hasImages ? ', image' : ''}` });
      let reply = await chatWithHint(r.cfg, api, { signal: ctrl.signal }, hasImages);
      let edits = [];
      if (editable.length) {
        const blocks = FE.parseEditBlocks(reply);
        if (blocks.length) {
          try {
            await guard('files.edit', blocks.map((b) => b.path).join(', '));
            edits = await FE.applyEdits(roots(), editable, blocks);
            for (const e of edits) audit.log({ action: 'ai.edit', category: 'files.edit', target: e.path, ok: e.ok, detail: e.error });
          } catch (e) { edits = blocks.map((b) => ({ path: b.path, ok: false, error: e.message })); }
          reply = FE.stripEditBlocks(reply) || 'Done.';
        }
      }
      return { reply, edits, route: { slot: r.slot, label: r.label, usedTextForImages: r.usedTextForImages } };
    } finally { aborts.delete(requestId); }
  });
  handle('chat:cancel', (id) => { aborts.get(id)?.abort(); return true; });

  handle('conv:list', () => store.listConversations());
  handle('conv:get', (id) => store.getConversation(id));
  handle('conv:save', (c) => store.saveConversation(c));
  handle('conv:rename', ({ id, title }) => { store.renameConversation(id, title); return true; });
  handle('conv:delete', (id) => { store.deleteConversation(id); return true; });
  handle('conv:clear', () => { store.clearConversations(); return true; });

  handle('folders:add', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a folder Tachyon may use', properties: ['openDirectory'] });
    if (r.canceled || !r.filePaths[0]) return null;
    const p = F.realpathNearest(r.filePaths[0]);
    const broad = path.parse(p).root === p || p === os.homedir();
    if (broad) {
      const c = await dialog.showMessageBox(win, {
        type: 'warning', buttons: ['Cancel', 'Grant access'], defaultId: 0, cancelId: 0,
        message: `Give Tachyon access to everything inside\n${p}?`,
        detail: 'Tachyon only reads or changes files when you press a button or ask it to, never uploads files by itself, and never deletes files. Edits always keep a .nova-bak backup. You can remove this folder at any time.',
      });
      if (c.response !== 1) return null;
    }
    const s = store.getSettings();
    if (!s.folders.includes(p)) store.saveSettings({ folders: [...s.folders, p] });
    return store.getSettings().folders;
  });
  handle('folders:remove', (p) => store.saveSettings({ folders: store.getSettings().folders.filter((f) => f !== p) }).folders);

  handle('fs:list', (dir) => F.listDir(roots(), dir));
  const scan = async (fn) => {
    if (scanToken) scanToken.cancelled = true;
    const token = { cancelled: false };
    scanToken = token;
    try { return await fn(token); } finally { if (scanToken === token) scanToken = null; }
  };
  handle('fs:findName', ({ q, kind }) => scan((token) => F.searchByName(roots(), { q: String(q || ''), kind, token })));
  handle('fs:findInside', ({ q }) => scan((token) => F.searchContent(roots(), { q: String(q || ''), token })));
  handle('fs:cancelScan', () => { if (scanToken) scanToken.cancelled = true; return true; });
  handle('fs:readEditable', (p) => F.readEditable(roots(), p));
  handle('fs:write', ({ path: p, text }) => F.writeText(roots(), p, text));
  handle('fs:restoreBackup', (p) => F.restoreBackup(roots(), p));
  handle('fs:analyze', (p) => analyzeFile(roots(), p));

  // AI edits a text/code/CSV/JSON file. In "apply" mode it is written directly (a .nova-bak backup is always made first).
  handle('fs:aiEdit', async ({ path: p, instruction, mode }) => {
    const original = await F.readEditable(roots(), p);
    const sys = `You are a careful file editor. Apply the user's instruction to the file '${path.basename(p)}'. ` +
      'Reply with ONLY the complete updated file content: no explanations and no code fences.';
    const out = await providers.chat(textCfg(), [
      { role: 'system', content: sys },
      { role: 'user', content: `Instruction: ${instruction}\n\nFILE CONTENT:\n${original}` },
    ]);
    const proposal = stripFence(out);
    if ((mode || store.getSettings().aiEditMode) === 'apply') {
      const bad = FE.validateContent(p, proposal);
      if (bad) return { applied: false, original, proposal, warning: bad };
      const { backup } = await F.writeText(roots(), p, proposal.endsWith('\n') ? proposal : proposal + '\n');
      return { applied: true, backup, original, proposal };
    }
    return { applied: false, original, proposal };
  });

  // PDF / Office document -> AI rewrite -> NEW PDF next to the original (the original is never touched).
  handle('fs:pdfRewrite', async ({ path: p, instruction }) => {
    const src = await F.readForAI(roots(), p, { maxChars: 60000 });
    if (!src.text) throw new Error('This document has no extractable text (it may be a scanned image).');
    const sys = 'You transform documents. Apply the user\'s instruction to the document and reply with ONLY the resulting document text (plain text, no commentary).';
    const out = await providers.chat(textCfg(), [
      { role: 'system', content: sys }, { role: 'user', content: `Instruction: ${instruction}\n\nDOCUMENT:\n${src.text}` }]);
    const dest = F.uniqueSibling(p, 'edited', '.pdf');
    F.assertInside(roots(), dest);
    const res = await createPdf({ title: path.basename(p, path.extname(p)) + ' (edited)', text: out, outPath: dest });
    return { ...res, truncated: src.truncated };
  });

  handle('fs:planSort', async ({ folder, mode, onlyImages }) => {
    const plan = await F.planSort(roots(), folder, { mode, onlyImages: Boolean(onlyImages) });
    return plan.map((x) => ({ name: path.basename(x.from), to: path.basename(x.toDir) }));
  });
  handle('fs:applySort', async ({ folder, mode, onlyImages }) => {
    const plan = await F.planSort(roots(), folder, { mode, onlyImages: Boolean(onlyImages) });
    return F.applySort(roots(), plan, store.journalFile);
  });
  handle('fs:undoSort', () => F.undoLastSort(roots(), store.journalFile));
  handle('fs:reveal', (p) => {
    if (!createdPaths.has(p)) F.assertInside(allowedImageRoots(), p);
    shell.showItemInFolder(p);
    return true;
  });

  // Export an AI answer to a file (format chosen by the extension the user picks).
  handle('export:save', async ({ title, text, format }) => {
    const fmt = ['pdf', 'docx', 'txt', 'md', 'html', 'csv', 'json', 'py', 'js'].includes(format) ? format : 'pdf';
    const r = await dialog.showSaveDialog(win, {
      title: 'Export', defaultPath: path.join(app.getPath('documents'), `Tachyon-${Date.now()}.${fmt}`),
      filters: [
        { name: 'PDF', extensions: ['pdf'] }, { name: 'Word document', extensions: ['docx'] }, { name: 'Text', extensions: ['txt'] },
        { name: 'Markdown', extensions: ['md'] }, { name: 'HTML', extensions: ['html'] }, { name: 'CSV', extensions: ['csv'] },
        { name: 'JSON', extensions: ['json'] }, { name: 'Python', extensions: ['py'] }, { name: 'JavaScript', extensions: ['js'] },
        { name: 'Other source/text file', extensions: ['ts', 'java', 'kt', 'c', 'cpp', 'cs', 'go', 'rs', 'sh', 'sql', 'xml', 'yml', 'yaml', 'css'] },
      ],
    });
    if (r.canceled || !r.filePath) return null;
    const res = await exportToPath(r.filePath, { title: String(title || ''), text: String(text || '') });
    createdPaths.add(r.filePath);
    return res;
  });

  // ---- files named or picked in the chat, and "save it to …" without a Save dialog
  handle('files:resolve', async ({ candidates = [] } = {}) => {
    const out = [];
    for (const c of (Array.isArray(candidates) ? candidates : []).slice(0, 10)) {
      let p;
      let note = null;
      if (c.kind === 'name') {
        const r = await findByName(c);
        if (!r.hit) { out.push({ input: String(c.value), missing: true }); continue; }
        p = r.hit.path;
        if (r.count > 1) note = `${r.count} files are named ${r.hit.name}; I used the newest one (${p}).`;
      } else p = SaveT.expandUserPath(c.kind === 'known' ? { kind: 'known', value: String(c.value) } : { kind: 'path', value: String(c.value) }, saveCtx());
      p = path.resolve(p);
      let st;
      try { st = fs.statSync(p); } catch {
        // C:\Users\me\Documents\x when Documents really lives in OneDrive (or the other way round)
        const alt = SaveT.remapKnownFolder(p, saveCtx());
        try { st = alt && fs.statSync(alt); } catch { st = null; }
        if (!st) { out.push({ input: String(c.value), path: p, missing: true }); continue; }
        p = alt;
      }
      if (out.some((x) => x.path === p)) continue;
      out.push({ input: String(c.value), path: p, name: path.basename(p) || p, isDir: st.isDirectory(), size: st.size, mtime: st.mtimeMs, allowed: isAllowed(p), note });
    }
    await askAccess(out.filter((x) => !x.missing && !x.allowed));
    return out;
  });
  handle('files:pick', async ({ folders = false } = {}) => {
    const r = await dialog.showOpenDialog(win, {
      title: folders ? 'Choose a folder for Tachyon' : 'Choose files for Tachyon', properties: folders ? ['openDirectory'] : ['openFile', 'multiSelections'],
    });
    if (r.canceled || !r.filePaths || !r.filePaths.length) return [];
    return r.filePaths.slice(0, 20).map((p) => {
      const st = fs.statSync(p);
      allowSession(p, st.isDirectory());
      return { path: p, name: path.basename(p), isDir: st.isDirectory(), size: st.size, mtime: st.mtimeMs };
    });
  });
  // Dropped files: the drop itself is the user's choice, like the file picker.
  handle('files:allowDropped', (paths = []) => (Array.isArray(paths) ? paths : []).slice(0, 20).filter((p) => typeof p === 'string' && path.isAbsolute(p)).map((p) => {
    const st = fs.statSync(p);
    allowSession(p, st.isDirectory());
    return { path: p, name: path.basename(p), isDir: st.isDirectory(), size: st.size, mtime: st.mtimeMs };
  }));
  handle('files:open', async (p) => {
    F.assertInside(roots(), p);
    const st = fs.statSync(p);
    if (!st.isDirectory() && !OPENABLE.has(extOf(p))) throw new Error(`For safety Tachyon does not open .${extOf(p) || '(no extension)'} files. Ask me to “show it in the folder” instead.`);
    const err = await shell.openPath(p);
    if (err) throw new Error(err);
    return true;
  });
  // Document -> PDF / Word / Markdown / text / HTML copy next to the original (no AI involved, original untouched).
  handle('files:convert', async ({ path: p, format }) => {
    F.assertInside(roots(), p);
    const fmt = String(format || '').toLowerCase();
    if (!['pdf', 'docx', 'md', 'txt', 'html'].includes(fmt)) throw new Error('Documents can be converted to PDF, Word, Markdown, text or HTML.');
    if (extOf(p) === fmt) throw new Error(`${path.basename(p)} is already a .${fmt} file.`);
    const src = await F.readForAI(roots(), p, { maxChars: 2_000_000 });
    if (!src.text) throw new Error(src.note || 'This file has no readable text.');
    const base = path.basename(p, path.extname(p));
    const dest = F.uniqueDest(path.dirname(p), base + '.' + fmt);
    const res = await exportToPath(dest, { title: base, text: src.text });
    createdPaths.add(dest);
    return { ...res, truncated: src.truncated };
  });
  handle('export:autoSave', async ({ location = null, filename = null, format = null, title = '', text = '' } = {}) => {
    const plan = SaveT.planSave({ location, filename, format, title: String(title), text: String(text) }, saveCtx());
    fs.mkdirSync(plan.dir, { recursive: true });
    const res = await exportToPath(plan.file, { title: String(title), text: String(text) });
    createdPaths.add(plan.file);
    return res;
  });
  handle('image:savePasted', (dataUrl) => {
    const m = /^data:image\/(?:png|jpe?g|webp|gif|bmp);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
    if (!m) throw new Error('Paste a PNG or JPEG image.');
    const buf = Buffer.from(m[1], 'base64');
    if (buf.length > 25_000_000) throw new Error('The pasted image is too large.');
    const img = nativeImage.createFromBuffer(buf);
    if (img.isEmpty()) throw new Error('This image cannot be read. Use a PNG or JPEG image.');
    const file = path.join(dirOf('captures'), `pasted_${Date.now()}.png`);
    fs.writeFileSync(file, img.toPNG());
    return { path: file, name: path.basename(file) };
  });

  // ---- images
  handle('image:generate', async ({ prompt }) => {
    const img = await imageGen.generate(imageCfg(), String(prompt || ''));
    const file = path.join(dirOf('generated'), `img_${Date.now()}.${img.ext}`);
    fs.writeFileSync(file, img.bytes);
    return { path: file };
  });
  handle('image:test', async (cfg = {}) => imageGen.test(imageCfg({
    backend: cfg.backend, url: cfg.url, model: cfg.model, cloudUrl: cfg.cloudUrl || store.getSettings().models.text.baseUrl,
    apiKey: cfg.apiKey && cfg.apiKey.trim() ? cfg.apiKey.trim() : imageKey(cfg.backend),
  })));
  handle('image:read', (p) => {
    F.assertInside(allowedImageRoots(), p);
    const img = nativeImage.createFromPath(p);
    if (img.isEmpty()) {
      const mime = { webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml' }[extOf(p)];
      if (!mime || fs.statSync(p).size > 8_000_000) throw new Error('This image cannot be previewed.');
      return `data:${mime};base64,` + fs.readFileSync(p).toString('base64');
    }
    const out = img.getSize().width > 900 ? img.resize({ width: 900, quality: 'good' }) : img;
    return 'data:image/jpeg;base64,' + out.toJPEG(88).toString('base64');
  });
  handle('image:saveAs', async (p) => {
    F.assertInside(allowedImageRoots(), p);
    const e = extOf(p) || 'png';
    const r = await dialog.showSaveDialog(win, { title: 'Save image', defaultPath: path.join(app.getPath('pictures'), 'Tachyon-' + path.basename(p)), filters: [{ name: 'Image', extensions: [e] }] });
    if (r.canceled || !r.filePath) return null;
    fs.copyFileSync(p, r.filePath);
    createdPaths.add(r.filePath);
    return { path: r.filePath };
  });
  handle('image:analyze', async ({ path: p, mode }) => {
    F.assertInside(allowedImageRoots(), p);
    const prompt = ANALYSIS_PROMPTS[mode] || ANALYSIS_PROMPTS.describe;
    const r = routeFor(true);
    if (r.cfg.kind === 'cloud') await guard('cloud.files', r.label + ': ' + path.basename(p));
    audit.log({ action: 'ai.request', category: r.cfg.kind === 'cloud' ? 'cloud' : 'local', target: r.label, detail: 'image analysis: ' + mode });
    return chatWithHint(r.cfg, [{ role: 'user', content: prompt, images: [visionB64(p)] }], {}, true);
  });
  // Resize in place (with backup) or convert to a new PNG/JPEG file next to the original.
  handle('image:op', async ({ path: p, op, width, format }) => {
    F.assertInside(roots(), p);
    const img = nativeImage.createFromPath(p);
    if (img.isEmpty()) throw new Error('Only PNG and JPEG images can be edited here.');
    const enc = (im, e) => (e === 'png' ? im.toPNG() : im.toJPEG(92));
    if (op === 'resize') {
      const w = Math.round(Number(width));
      if (!(w >= 16 && w <= 8000)) throw new Error('Enter a width between 16 and 8000 pixels.');
      const e = extOf(p) === 'png' ? 'png' : 'jpg';
      fs.copyFileSync(p, p + '.nova-bak');
      fs.writeFileSync(p, enc(img.resize({ width: w, quality: 'best' }), e));
      return { path: p, backup: p + '.nova-bak', size: img.resize({ width: w }).getSize() };
    }
    if (op === 'convert') {
      const e = format === 'png' ? 'png' : 'jpg';
      const dest = F.uniqueDest(path.dirname(p), path.basename(p, path.extname(p)) + '.' + e);
      if (!extraAllowed.has(p)) F.assertInside(roots(), dest); // a single file allowed from the chat may get a converted copy beside it
      fs.writeFileSync(dest, enc(img, e));
      return { path: dest };
    }
    throw new Error('Unknown image operation.');
  });

  // ---- computer control: reminders, apps, windows
  handle('reminders:list', () => reminders.pending());
  handle('reminders:add', ({ text, at }) => reminders.add(String(text || ''), Number(at)));
  handle('reminders:delete', (id) => reminders.remove(String(id)));
  handle('apps:open', async (name) => {
    const r = Computer.resolveApp(String(name || ''));
    await Computer.launch(r, shell);
    return { name: r.name };
  });
  handle('windows:action', async ({ action, target = '' } = {}) => {
    const out = await Computer.windowAction(String(action), String(target));
    if (action === 'list') return out.split(/\r?\n/).filter(Boolean).map((l) => { const [app, ...t] = l.split('\t'); return { app, title: t.join('\t') }; });
    return out;
  });

  // ---- multi-step tasks: plan (shown to the user) -> run (each step checked) -> undo
  handle('task:plan', async ({ text } = {}) => {
    const request = String(text || '').replace(/^\/task\s*/i, '').trim();
    if (!request) throw new Error('Tell me what the task should do, for example “/task find my CV, make it a PDF and copy it to the desktop”.');
    const cfg = textCfg();
    audit.log({ action: 'ai.request', category: cfg.kind === 'cloud' ? 'cloud' : 'local', target: cfg.model || 'text model', detail: 'task planning' });
    const reply = await providers.chat(cfg, [
      { role: 'system', content: Tasks.plannerPrompt({ folders: roots(), known: knownDirs(), platform: process.platform }) + (memoryBlock() ? '\n\n' + memoryBlock() : '') },
      { role: 'user', content: request }]);
    const plan = Tasks.parsePlan(reply);
    plan.id = crypto.randomUUID();
    plan.request = request;
    pendingPlans.set(plan.id, plan);
    return plan;
  });
  handle('task:run', async ({ id } = {}) => {
    const plan = pendingPlans.get(String(id));
    if (!plan) throw new Error('This plan has expired. Ask again to make a new one.');
    pendingPlans.delete(plan.id);
    const ctx = { id: plan.id, title: plan.title, journal: [], readFiles: false, cloudOk: false };
    const results = [];
    const steps = [];
    let stopped = null;
    for (let i = 0; i < plan.steps.length; i++) {
      const st = plan.steps[i];
      const step = { ...st, args: Object.fromEntries(Object.entries(st.args).map(([k, v]) => [k, Tasks.fillRefs(v, results)])) };
      sendTaskProgress({ id: plan.id, index: i, status: 'running' });
      try {
        if (step.category) await guard(step.category, `${step.label}: ${Object.values(step.args).join(' | ').slice(0, 300)}`);
        const r = await runTool(step, ctx);
        results.push(r.text);
        steps.push({ index: i, tool: step.tool, label: step.label, ok: true, summary: r.summary, path: r.path || null, text: step.tool === 'ai_write' || step.tool === 'list_folder' || step.tool === 'search_files' ? String(r.text).slice(0, 4000) : undefined });
        audit.log({ action: 'task.step', category: step.category || 'ai', target: step.label, detail: r.summary });
        sendTaskProgress({ id: plan.id, index: i, status: 'done', summary: r.summary });
      } catch (e) {
        steps.push({ index: i, tool: step.tool, label: step.label, ok: false, error: e.message });
        audit.log({ action: 'task.step', category: step.category || 'ai', target: step.label, ok: false, detail: e.message });
        sendTaskProgress({ id: plan.id, index: i, status: 'failed', error: e.message });
        stopped = i;
        break;
      }
    }
    const rec = { id: plan.id, title: plan.title, time: Date.now(), journal: ctx.journal, steps, undone: false };
    saveTaskRecord(rec);
    return { id: plan.id, title: plan.title, steps, stopped, canUndo: ctx.journal.length > 0 };
  });
  handle('task:undo', async ({ id } = {}) => {
    const rec = getTaskRecord(String(id));
    if (!rec) throw new Error('I could not find that task.');
    if (rec.undone) throw new Error('This task was already undone.');
    const r = await undoTask(rec);
    saveTaskRecord({ ...rec, undone: true });
    audit.log({ action: 'task.undo', category: 'files.edit', target: rec.title, detail: r.done.join('; ') });
    return r;
  });

  // ---- skills: draft (shown with test results) -> install on the user's click; versions kept for rollback
  handle('skills:list', () => skills.list());
  handle('skills:draft', async ({ request } = {}) => {
    const cfg = textCfg();
    audit.log({ action: 'ai.request', category: cfg.kind === 'cloud' ? 'cloud' : 'local', target: cfg.model || 'text model', detail: 'skill draft' });
    const reply = await providers.chat(cfg, [{ role: 'system', content: Skills.drafterPrompt() }, { role: 'user', content: String(request || '') }]);
    let raw;
    try { raw = Tasks.extractJson(reply); } catch { throw new Error('The model did not return a skill I can use. Try describing it differently.'); }
    const clean = Skills.validateSkill(raw);
    const tests = await Skills.runTests(clean, runSkill);
    const draftId = crypto.randomUUID();
    pendingSkills.set(draftId, { clean, tests });
    const existing = skills.byCommand(clean.command);
    return { draftId, skill: clean, tests, replaces: existing ? { name: existing.name, version: existing.version || 1 } : null };
  });
  handle('skills:install', ({ draftId } = {}) => {
    const d = pendingSkills.get(String(draftId));
    if (!d) throw new Error('This draft has expired. Ask again to create the skill.');
    if (d.clean.kind === 'code' && d.tests.some((t) => !t.ok)) throw new Error('A code skill can only be installed when all its tests pass.');
    pendingSkills.delete(String(draftId));
    return skills.install(d.clean, d.tests);
  });
  handle('skills:run', async ({ command, input = '' } = {}) => {
    const s = skills.byCommand(String(command || ''));
    if (!s) throw new Error(`There is no skill called /${command}.`);
    if (!s.enabled) throw new Error(`The skill /${s.command} is switched off (Settings → Skills).`);
    return { text: await runSkill(s, String(input)), name: s.name, kind: s.kind };
  });
  handle('skills:rollback', (id) => skills.rollback(String(id)));
  handle('skills:toggle', ({ id, enabled }) => skills.setEnabled(String(id), enabled));
  handle('skills:delete', (id) => skills.remove(String(id)));

  // ---- offline voice: speech models (download once, or import a file you have)
  const sendVoice = (p) => { if (win && !win.isDestroyed()) win.webContents.send('voice-progress', p); };
  handle('voice:models', () => models.list());
  handle('voice:download', async (id) => {
    const c = Voice.CATALOG.find((x) => x.id === id);
    if (!c) throw new Error('Unknown speech model.');
    const url = Voice.MODEL_URL(c.file);
    const res = await net.fetch(url);
    if (!res.ok) throw new Error(`The download failed (HTTP ${res.status}). You can download ${c.file}.zip yourself and use “Import model file”.`);
    const total = Number(res.headers.get('content-length')) || c.sizeMb * 1e6;
    const reader = res.body.getReader();
    const parts = [];
    let got = 0;
    let last = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      parts.push(value);
      got += value.length;
      if (Date.now() - last > 300) { last = Date.now(); sendVoice({ id, phase: 'download', pct: Math.min(99, Math.round((got / total) * 100)) }); }
    }
    sendVoice({ id, phase: 'convert' });
    const tgz = Voice.toModelTarGz(Buffer.concat(parts), c.file + '.zip');
    const info = models.save(c.id, tgz, { label: c.label, lang: c.lang, source: url });
    sendVoice({ id, phase: 'done' });
    return info;
  });
  handle('voice:importModel', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a Vosk speech model (.zip or .tar.gz)', properties: ['openFile'], filters: [{ name: 'Speech model', extensions: ['zip', 'gz', 'tgz'] }] });
    if (r.canceled || !r.filePaths[0]) return null;
    const f = r.filePaths[0];
    if (fs.statSync(f).size > 600e6) throw new Error('This model is too large for Tachyon. Use a “small” Vosk model (about 40–100 MB).');
    const base = path.basename(f).replace(/\.(zip|tar\.gz|tgz|gz)$/i, '');
    const cat = Voice.CATALOG.find((c) => c.file === base);
    const id = cat ? cat.id : 'custom-' + base.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30);
    sendVoice({ id, phase: 'convert' });
    const tgz = Voice.toModelTarGz(fs.readFileSync(f), path.basename(f));
    const lang = /-hi-/.test(base) ? 'hi-IN' : /-en-in/.test(base) ? 'en-IN' : /-en-/.test(base) ? 'en-US' : '';
    models.save(id, tgz, { label: cat ? cat.label : base, lang, source: f });
    sendVoice({ id, phase: 'done' });
    return { id };
  });
  handle('voice:deleteModel', async (id) => {
    models.remove(String(id));
    await session.defaultSession.clearStorageData({ storages: ['indexdb'] }).catch(() => {}); // the recognizer's unpacked copy
    return true;
  });

  // ---- overlay (bubble + quick-assist panel)
  handle('overlay:toggle', () => { overlay.togglePanel(); return true; });
  handle('overlay:hide', () => { overlay.hidePanel(); return true; });
  handle('overlay:quit', () => { quitApp(); return true; });
  handle('capture:list', () => overlay.listSources());
  handle('capture:take', async ({ sourceId } = {}) => {
    const shot = await overlay.capture(sourceId || null);
    const big = shot.getSize().width > 1600 ? shot.resize({ width: 1600, quality: 'good' }) : shot;
    const file = path.join(dirOf('captures'), `screen_${Date.now()}.jpg`);
    fs.writeFileSync(file, big.toJPEG(85));
    const small = big.resize({ width: 640, quality: 'good' });
    return { path: file, dataUrl: 'data:image/jpeg;base64,' + small.toJPEG(70).toString('base64') };
  });
  handle('overlay:ask', async ({ text, imagePath }) => {
    const s = store.getSettings();
    const m = { role: 'user', content: String(text || '') };
    if (imagePath) { F.assertInside([dirOf('captures')], imagePath); m.images = [visionB64(imagePath)]; }
    const r = routeFor(Boolean(imagePath));   // screenshot -> Vision model, plain question -> Text model
    if (imagePath && r.cfg.kind === 'cloud') await guard('cloud.files', r.label + ': a screenshot');
    audit.log({ action: 'ai.request', category: r.cfg.kind === 'cloud' ? 'cloud' : 'local', target: r.label, detail: imagePath ? 'quick assist, screenshot' : 'quick assist' });
    const msgs = [{ role: 'system', content: rules.buildSystemPrompt(s.systemPrompt, [memoryBlock()]) }, m];
    return { reply: await chatWithHint(r.cfg, msgs, {}, Boolean(imagePath)), route: { slot: r.slot, label: r.label } };
  });
  handle('overlay:openMain', ({ text, imagePath, reply } = {}) => {
    if (text) {
      const now = Date.now();
      const conv = store.saveConversation({
        title: String(text).slice(0, 40),
        messages: [
          { role: 'user', content: String(text), images: imagePath ? [{ path: imagePath }] : [], ts: now },
          ...(reply ? [{ role: 'assistant', content: String(reply), ts: now }] : []),
        ],
      });
      showMain();
      const send = () => win.webContents.send('open-conv', conv.id);
      if (win.webContents.isLoading()) win.webContents.once('did-finish-load', send); else send();
    } else showMain();
    overlay.hidePanel();
    return true;
  });
}

// ---------------------------------------------------------------- agent: connectors, launcher, projects, approved commands
const pendingProposals = new Map(); // id -> { connector, op, args, label } waiting for the user's approval

function registerAgent() {
  handle('agent:apps', () => agent.apps());
  handle('agent:tools', () => agent.tools());
  handle('agent:models', () => agent.modelStatus());
  handle('agent:diagnostics', () => agent.diagnostics());
  handle('agent:catalog', () => agent.registry.catalog().map((o) => ({ connector: o.connector, op: o.op, describe: o.describe, uiOnly: o.uiOnly, category: o.category })));
  handle('agent:activity', ({ limit = 100 } = {}) => agent.activity.list(Math.min(500, Number(limit) || 100)));
  handle('agent:activityClear', () => { agent.activity.clear(); return true; });
  handle('agent:history', () => agent.history.list(50));
  handle('agent:historyClear', () => { agent.history.clear(); return true; });
  handle('agent:cancel', (id) => agent.cancel(String(id)));

  // A button in the window (source "ui": the only source that may open a terminal).
  handle('agent:run', async ({ connector, op, args, label } = {}) => {
    let a = args && typeof args === 'object' ? { ...args } : {};
    if (a.project) { const r = agent.resolveProjectArgs(String(connector), String(op), { ...a, project: undefined }, String(a.project)); if (r.message) throw new Error(r.message); a = r.args; delete a.project; }
    return agent.run({ connector: String(connector), op: String(op), args: a, source: 'ui', label: label ? String(label).slice(0, 100) : undefined });
  });

  // A sentence typed in the chat (source "chat": shells and other button-only operations are refused by the registry).
  handle('agent:chat', ({ text } = {}) => agent.chat(String(text || '')));

  // “/do …”: a LOCAL model proposes one registered operation; nothing runs until the user approves the card.
  handle('agent:propose', async ({ text } = {}) => {
    const request = String(text || '').replace(/^\/do\s*/i, '').trim().slice(0, 500);
    if (!request) throw new Error('Tell me what to do, for example “/do open my project in VS Code”.');
    const cfg = textCfg();
    const problem = R.slotProblem(store.getSettings(), 'text', getKey);
    if (problem) throw new Error(problem);
    if (cfg.kind === 'cloud') throw new Error('“/do” uses your local model to understand the request, and never sends it to a cloud service. Choose a local (Ollama) text model in Settings, or use the buttons and the simple commands (“Open VS Code”, “git status”).');
    const catalog = agent.registry.catalog({ forModel: true }).map((o) => `- ${o.connector}.${o.op}: ${o.describe} args=${JSON.stringify(o.schema.properties || {})}${(o.schema.required || []).length ? ' required=' + JSON.stringify(o.schema.required) : ''}`).join('\n');
    audit.log({ action: 'ai.request', category: 'local', target: cfg.model || 'text model', detail: 'action proposal' });
    const reply = await providers.chat(cfg, [
      { role: 'system', content: 'You choose ONE operation for a desktop assistant. Reply with a single JSON object and nothing else: {"connector":"...","op":"...","args":{...},"project":"name or empty","explain":"one short sentence"}. Choose only from this list; if nothing fits reply {"none":true,"explain":"why"}. Never invent operations, paths or commands. For folder arguments (path/cwd) leave them out and put the project name in "project".\n' + catalog },
      { role: 'user', content: request }]);
    const m = /\{[\s\S]*\}/.exec(String(reply));
    let j; try { j = JSON.parse(m ? m[0] : ''); } catch { throw new Error('The model did not return a usable action. Try the simple commands or the buttons.'); }
    if (j.none || !j.connector) return { proposal: null, message: String(j.explain || 'I could not match that to an action I can perform.').slice(0, 300) };
    let args = j.args && typeof j.args === 'object' ? { ...j.args } : {};
    delete args.cwd; delete args.path;
    const r = agent.resolveProjectArgs(String(j.connector), String(j.op), args, j.project ? String(j.project) : undefined);
    if (r.message) return { proposal: null, message: r.message };
    args = r.args;
    const v = await agent.registry.validateAction(String(j.connector), String(j.op), args, { source: 'model' });
    if (!v.ok) return { proposal: null, message: 'That is not something I can do safely: ' + v.errors.join(' ') };
    const id = crypto.randomUUID();
    const proposal = { id, connector: String(j.connector), op: String(j.op), args, label: `${j.connector}.${j.op}`, explain: String(j.explain || '').slice(0, 300), project: r.project ? r.project.name : null, state: 'awaiting_approval' };
    pendingProposals.set(id, proposal);
    while (pendingProposals.size > 20) pendingProposals.delete(pendingProposals.keys().next().value);
    return { proposal };
  });
  handle('agent:approve', async ({ id } = {}) => {
    const p = pendingProposals.get(String(id));
    if (!p) throw new Error('This proposal has expired. Ask again.');
    pendingProposals.delete(p.id);
    return agent.run({ connector: p.connector, op: p.op, args: p.args, source: 'model', label: p.label });
  });
  handle('agent:reject', ({ id } = {}) => pendingProposals.delete(String(id)));

  // Output of a command, explained by the user's text model. Cloud models only after an explicit confirmation.
  handle('agent:analyze', async ({ id } = {}) => {
    const rec = agent.getRecord(id);
    const r = rec && rec.result;
    if (!r || r.stdout === undefined) throw new Error('There is no command output to explain.');
    const problem = R.slotProblem(store.getSettings(), 'text', getKey);
    if (problem) throw new Error(problem);
    const cfg = textCfg();
    const out = (String(r.stdout || '') + (r.stderr ? '\n[stderr]\n' + r.stderr : '')).slice(-12000);
    if (cfg.kind === 'cloud') await guard('cloud.files', `Send the output of “${r.command}” (${out.length} characters) to your cloud model`);
    audit.log({ action: 'ai.request', category: cfg.kind === 'cloud' ? 'cloud' : 'local', target: cfg.model || 'text model', detail: 'explain command output' });
    const reply = await providers.chat(cfg, [
      { role: 'system', content: 'You help a developer read the output of a command. Be concise. Say what happened, the most likely cause of any error, and the next step to try. Do not claim to have run anything yourself.' },
      { role: 'user', content: `Command: ${r.command}\nExit code: ${r.exitCode}${r.timedOut ? ' (timed out)' : ''}\n\n${out}` }]);
    return { text: String(reply).trim() };
  });

  // Projects: folders the user chose to work on. They must be inside folders granted to Tachyon.
  handle('projects:list', () => ({ projects: agent.projects(), active: store.getSettings().activeProject || null }));
  handle('projects:add', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a project folder', properties: ['openDirectory'], defaultPath: store.getSettings().folders[0] });
    if (r.canceled || !r.filePaths[0]) return null;
    const p = F.realpathNearest(r.filePaths[0]);
    if (path.parse(p).root === p || p === os.homedir()) throw new Error('Choose the project’s own folder, not a drive or your whole home folder.');
    try { AgentUtil.authorizedPath(agent.ctx, p); } catch {
      const c = await dialog.showMessageBox(win, { type: 'question', buttons: ['Cancel', 'Grant access'], defaultId: 0, cancelId: 0, message: `Give Tachyon access to this project folder?\n${p}`, detail: 'Tachyon can then read it, open it in your apps and run the approved commands in it. Edits keep a backup, and nothing is uploaded.' });
      if (c.response !== 1) return null;
      const s = store.getSettings();
      if (!s.folders.includes(p)) store.saveSettings({ folders: [...s.folders, p] });
    }
    const proj = agent.addProject(p);
    if (!store.getSettings().activeProject) store.saveSettings({ activeProject: proj.id });
    return proj;
  });
  handle('projects:remove', (id) => { agent.removeProject(String(id)); if (store.getSettings().activeProject === id) store.saveSettings({ activeProject: null }); return true; });
  handle('projects:setActive', (id) => { if (!agent.projects().some((x) => x.id === id)) throw new Error('Unknown project.'); store.saveSettings({ activeProject: id }); return true; });
  handle('apps:addCustom', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose the app’s program file', properties: ['openFile'], filters: process.platform === 'win32' ? [{ name: 'Programs', extensions: ['exe'] }] : [] });
    if (r.canceled || !r.filePaths[0]) return null;
    return agent.addCustomApp(r.filePaths[0]);
  });
  handle('apps:removeCustom', (id) => agent.removeCustomApp(String(id)));
}

// Extra hardening for every window Tachyon creates: no <webview>, no popups, no navigation away from the app's own files.
app.on('web-contents-created', (_e, contents) => {
  contents.on('will-attach-webview', (ev) => ev.preventDefault());
});

function runSmokeTest() {
  // The result is printed and, when TACHYON_SMOKE_OUT names a file, written there too (a Windows GUI app may not show console output).
  const finish = (msg, code) => { console.log(msg); try { if (process.env.TACHYON_SMOKE_OUT) fs.writeFileSync(process.env.TACHYON_SMOKE_OUT, msg); } catch { /* console only */ } app.exit(code); };
  const fail = (why) => finish('TACHYON_SMOKE_FAIL ' + why, 1);
  setTimeout(() => fail('timeout'), 60000);
  win.webContents.once('did-fail-load', (_e, code, desc) => fail('load ' + code + ' ' + desc));
  win.webContents.once('did-finish-load', async () => {
    try {
      const r = await win.webContents.executeJavaScript(`(async () => {
        const inv = (c, a) => window.nova.invoke(c, a);
        const s = await inv('settings:get');
        const apps = await inv('agent:apps');
        const tools = await inv('agent:tools');
        const shell = await inv('agent:chat', { text: 'open powershell' });
        const chat = await inv('agent:chat', { text: 'tell me a joke' });
        const blocked = await window.nova.invoke('not:achannel').then(() => false, () => true);
        await new Promise((r) => setTimeout(r, 400));
        return JSON.stringify({
          settings: s.ok, apps: apps.ok && apps.data.length, tools: tools.ok && tools.data.length,
          shellRefused: Boolean(shell.ok && shell.data.refused), plainChatIgnored: Boolean(chat.ok && chat.data.handled === false), blocked,
          nav: document.querySelectorAll('#sidebar .nav').length, navIcons: document.querySelectorAll('#sidebar .nav svg').length,
          quick: document.querySelectorAll('#quickbar .qa svg').length, version: s.data && s.data.version,
        });
      })()`);
      const j = JSON.parse(r);
      const good = j.settings && j.apps >= 7 && j.tools === 7 && j.shellRefused && j.plainChatIgnored && j.blocked && j.nav === 9 && j.navIcons === 9 && j.quick === 7;
      if (!good) return fail('unexpected ' + r);
      finish('TACHYON_SMOKE_OK ' + r, 0);
    } catch (e) { fail(String(e && e.message)); }
  });
}

app.whenReady().then(() => {
  let migrated = null;
  try { migrated = migrateUserData(app.getPath('userData'), app.getPath('appData')); } catch { /* start fresh */ }
  store = new Store(app.getPath('userData'), safeStorage);
  audit = new AuditLog(app.getPath('userData'));
  memory = new Memory(app.getPath('userData'));
  reminders = new Reminders(app.getPath('userData'));
  models = new Voice.ModelStore(dirOf('models'));
  protocol.handle('tachyon-model', (req) => {
    const id = new URL(req.url).hostname;
    let f;
    try { f = models.file(id); } catch { return new Response('bad model', { status: 400 }); }
    if (!fs.existsSync(f)) return new Response('model not installed', { status: 404 });
    const st = fs.statSync(f);
    return new Response(fs.readFileSync(f), { headers: { 'content-type': 'application/gzip', 'content-length': String(st.size), 'access-control-allow-origin': '*' } });
  });
  // The microphone (offline voice) is only for Tachyon's own windows, audio only; other requests behave as before.
  session.defaultSession.setPermissionRequestHandler((wc, permission, cb, details) => {
    if (permission !== 'media') return cb(true);
    const own = String((details && details.requestingUrl) || wc.getURL()).startsWith('file://');
    cb(own && (!details || !details.mediaTypes || details.mediaTypes.every((t) => t === 'audio')));
  });
  skills = new Skills.Skills(app.getPath('userData'));
  // Keys copied from NOVA AI that this app cannot decrypt (the macOS keychain entry is per app) are dropped so Settings asks again.
  if (migrated) for (const slot of SLOT_NAMES) if (store.hasApiKey(slot) && !store.getApiKey(slot)) store.deleteApiKey(slot);
  overlay = createOverlayController({ onOpenMain: showMain, onQuit: quitApp });
  agent = Agent.create({
    userData: app.getPath('userData'), audit,
    getSettings: () => store.getSettings(), saveSettings: (p) => store.saveSettings(p),
    roots, guard, fetch: (u, o) => fetch(u, o),
    openExternal: (u) => shell.openExternal(u), openPath: (p) => shell.openPath(p),
    emit: (rec) => { if (win && !win.isDestroyed()) win.webContents.send('agent-activity', rec); },
    listWindows: process.platform === 'win32'
      ? async () => (await Computer.windowAction('list')).split(/\r?\n/).filter(Boolean).map((l) => { const [a, ...t] = l.split('\t'); return { app: a, title: t.join('\t') }; })
      : undefined,
  });
  register();
  registerAgent();
  cleanOldCaptures();
  createWindow();
  if (SMOKE) { runSmokeTest(); return; }
  if (store.getSettings().overlayEnabled) overlay.start();
  // Reminders: checked every 15 s; ones missed while Tachyon was closed are shown at start-up.
  setTimeout(checkReminders, 3000);
  setInterval(checkReminders, 15000);
  // Ctrl+Shift+Space from anywhere: bring Tachyon up and start listening.
  try {
    globalShortcut.register('CommandOrControl+Shift+Space', () => {
      showMain();
      const go = () => win.webContents.send('voice-start');
      if (win.webContents.isLoading()) win.webContents.once('did-finish-load', go); else go();
    });
  } catch { /* shortcut taken by another app */ }
  app.on('activate', showMain);
});
app.on('before-quit', () => { quitting = true; });
app.on('will-quit', () => { try { globalShortcut.unregisterAll(); } catch { /* not ready */ } });
app.on('second-instance', showMain);
app.on('window-all-closed', () => { if (process.platform !== 'darwin' && (!overlay || !overlay.isRunning())) app.quit(); });
