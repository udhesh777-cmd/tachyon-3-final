'use strict';
// Always-on floating "N" button (top-right) + quick-assist panel + screen capture.
const { BrowserWindow, screen, desktopCapturer, nativeImage, Tray, Menu, systemPreferences, app } = require('electron');
const path = require('path');

const BUBBLE = 52;
const PANEL_W = 400;
const PANEL_H = 580;
const MARGIN = 14;

function createOverlayController({ onOpenMain, onQuit }) {
  let bubble = null;
  let panel = null;
  let tray = null;
  let running = false;

  const webPrefs = () => ({
    preload: path.join(__dirname, 'overlayPreload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true,
  });

  function positions() {
    const wa = screen.getPrimaryDisplay().workArea;
    return {
      bubble: { x: wa.x + wa.width - BUBBLE - MARGIN, y: wa.y + MARGIN },
      panel: { x: wa.x + wa.width - PANEL_W - MARGIN, y: wa.y + MARGIN + BUBBLE + 8 },
    };
  }

  function reposition() {
    const p = positions();
    if (bubble && !bubble.isDestroyed()) bubble.setPosition(p.bubble.x, p.bubble.y);
    if (panel && !panel.isDestroyed()) panel.setPosition(p.panel.x, p.panel.y);
  }

  function makeWindows() {
    const p = positions();
    bubble = new BrowserWindow({
      width: BUBBLE, height: BUBBLE, x: p.bubble.x, y: p.bubble.y, frame: false, transparent: true, resizable: false,
      movable: false, minimizable: false, maximizable: false, fullscreenable: false, skipTaskbar: true, alwaysOnTop: true,
      focusable: false, hasShadow: false, show: false, title: 'Tachyon button', webPreferences: webPrefs(),
    });
    bubble.setAlwaysOnTop(true, 'screen-saver');
    bubble.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    bubble.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    bubble.webContents.on('will-navigate', (e) => e.preventDefault());
    bubble.loadFile(path.join(__dirname, 'overlay', 'bubble.html'));
    bubble.once('ready-to-show', () => bubble && !bubble.isDestroyed() && bubble.showInactive());

    panel = new BrowserWindow({
      width: PANEL_W, height: PANEL_H, x: p.panel.x, y: p.panel.y, frame: false, resizable: false, minimizable: false,
      maximizable: false, fullscreenable: false, skipTaskbar: true, alwaysOnTop: true, show: false, backgroundColor: '#060a18',
      title: 'Tachyon quick assist', webPreferences: webPrefs(),
    });
    panel.setAlwaysOnTop(true, 'screen-saver');
    panel.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    panel.webContents.on('will-navigate', (e) => e.preventDefault());
    panel.loadFile(path.join(__dirname, 'overlay', 'panel.html'));
  }

  function makeTray() {
    try {
      const img = nativeImage.createFromPath(path.join(__dirname, 'assets', 'icon.png')).resize({ width: 22, height: 22 });
      tray = new Tray(img);
      tray.setToolTip('Tachyon');
      tray.setContextMenu(Menu.buildFromTemplate([
        { label: 'Open Tachyon', click: () => onOpenMain() },
        { label: 'Quick assist panel', click: () => showPanel() },
        { type: 'separator' },
        { label: 'Quit Tachyon', click: () => onQuit() },
      ]));
      tray.on('click', () => onOpenMain());
    } catch { tray = null; /* some Linux desktops have no tray */ }
  }

  function start() {
    if (running) return;
    running = true;
    makeWindows();
    makeTray();
    screen.on('display-metrics-changed', reposition);
  }

  function stop() {
    if (!running) return;
    running = false;
    screen.removeListener('display-metrics-changed', reposition);
    for (const w of [bubble, panel]) if (w && !w.isDestroyed()) w.destroy();
    bubble = panel = null;
    if (tray) { tray.destroy(); tray = null; }
  }

  function showPanel() {
    if (!panel || panel.isDestroyed()) return;
    reposition();
    panel.show();
    panel.focus();
  }
  function hidePanel() { if (panel && !panel.isDestroyed()) panel.hide(); }
  function togglePanel() { if (panel && !panel.isDestroyed()) (panel.isVisible() ? hidePanel() : showPanel()); }

  // ---------------------------------------------------------------- capture
  async function listSources() {
    const sources = await desktopCapturer.getSources({ types: ['screen', 'window'], thumbnailSize: { width: 1, height: 1 }, fetchWindowIcons: false });
    return sources.filter((s) => s.name !== 'Tachyon quick assist' && s.name !== 'Tachyon button')
      .map((s) => ({ id: s.id, name: s.name || s.id, type: s.id.startsWith('screen') ? 'screen' : 'window' }));
  }

  /** Returns a nativeImage of the chosen screen or window. The overlay is hidden while capturing. */
  async function capture(sourceId) {
    if (process.platform === 'darwin' && systemPreferences.getMediaAccessStatus('screen') === 'denied') {
      throw new Error('Screen recording is blocked. Open System Settings → Privacy & Security → Screen Recording, enable Tachyon, then restart the app.');
    }
    const panelWasVisible = Boolean(panel && !panel.isDestroyed() && panel.isVisible());
    if (panelWasVisible) panel.hide();
    if (bubble && !bubble.isDestroyed()) bubble.hide();
    await new Promise((r) => setTimeout(r, 350));
    try {
      const d = screen.getPrimaryDisplay();
      const w = Math.min(2560, Math.round(d.size.width * d.scaleFactor));
      const h = Math.round((w * d.size.height) / d.size.width);
      const sources = await desktopCapturer.getSources({ types: ['screen', 'window'], thumbnailSize: { width: w, height: h } });
      const src = sourceId ? sources.find((s) => s.id === sourceId) : sources.find((s) => s.id.startsWith('screen'));
      if (!src || src.thumbnail.isEmpty()) {
        throw new Error('Could not capture the screen. On macOS allow Screen Recording for Tachyon; on Linux/Wayland approve the screen-share prompt; make sure the window is not minimized.');
      }
      return src.thumbnail;
    } finally {
      if (bubble && !bubble.isDestroyed()) bubble.showInactive();
      if (panelWasVisible) showPanel();
    }
  }

  return { start, stop, showPanel, hidePanel, togglePanel, listSources, capture, isRunning: () => running, reposition };
}

module.exports = { createOverlayController };
