'use strict';
document.getElementById('b').addEventListener('click', () => { window.novaOverlay.invoke('overlay:toggle').catch(() => {}); });
