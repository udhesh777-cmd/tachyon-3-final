'use strict';
const { contextBridge, ipcRenderer, webUtils } = require('electron');

const ALLOWED = new Set([
  'settings:get', 'settings:save', 'settings:deleteKey', 'provider:test', 'provider:models', 'provider:cloudModels',
  'chat:send', 'chat:cancel',
  'conv:list', 'conv:get', 'conv:save', 'conv:rename', 'conv:delete', 'conv:clear',
  'folders:add', 'folders:remove',
  'fs:list', 'fs:findName', 'fs:findInside', 'fs:cancelScan', 'fs:readEditable', 'fs:write', 'fs:aiEdit',
  'fs:restoreBackup', 'fs:analyze', 'fs:pdfRewrite', 'fs:planSort', 'fs:applySort', 'fs:undoSort', 'fs:reveal',
  'export:save',
  'image:generate', 'image:test', 'image:read', 'image:saveAs', 'image:analyze', 'image:op',
  'perms:get', 'audit:list', 'audit:clear', 'memory:list', 'memory:add', 'memory:delete', 'memory:forget', 'memory:clear',
  'files:resolve', 'files:pick', 'files:allowDropped', 'files:open', 'files:convert', 'export:autoSave', 'image:savePasted',
  'reminders:list', 'reminders:add', 'reminders:delete', 'apps:open', 'windows:action',
  'task:plan', 'task:run', 'task:undo',
  'skills:list', 'skills:draft', 'skills:install', 'skills:run', 'skills:rollback', 'skills:toggle', 'skills:delete',
  'voice:models', 'voice:download', 'voice:importModel', 'voice:deleteModel',
  'agent:apps', 'agent:tools', 'agent:models', 'agent:diagnostics', 'agent:catalog', 'agent:activity', 'agent:activityClear', 'agent:history', 'agent:historyClear',
  'agent:cancel', 'agent:run', 'agent:chat', 'agent:propose', 'agent:approve', 'agent:reject', 'agent:analyze',
  'projects:list', 'projects:add', 'projects:remove', 'projects:setActive', 'apps:addCustom', 'apps:removeCustom',
]);

contextBridge.exposeInMainWorld('nova', {
  invoke: (channel, ...args) =>
    ALLOWED.has(channel) ? ipcRenderer.invoke(channel, ...args) : Promise.reject(new Error('Blocked channel')),
  onOpenConversation: (cb) => ipcRenderer.on('open-conv', (_e, id) => cb(id)),
  onReminder: (cb) => ipcRenderer.on('reminder-due', (_e, r) => cb(r)),
  onTaskProgress: (cb) => ipcRenderer.on('task-progress', (_e, p) => cb(p)),
  onVoiceProgress: (cb) => ipcRenderer.on('voice-progress', (_e, p) => cb(p)),
  onAgentActivity: (cb) => ipcRenderer.on('agent-activity', (_e, r) => cb(r)),
  onVoiceStart: (cb) => ipcRenderer.on('voice-start', () => cb()),
  pathForFile: (file) => { try { return webUtils.getPathForFile(file) || ''; } catch { return ''; } },
});
