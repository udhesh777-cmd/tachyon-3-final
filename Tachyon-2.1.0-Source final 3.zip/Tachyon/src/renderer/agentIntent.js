(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TachyonAgentIntent = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Turns a short chat sentence ("Open VS Code", "git status in my project", "go to example.com") into a request for ONE registered
  // connector operation. This is plain rule matching — no model is involved, and nothing here can run anything: the main process
  // validates the request against the connector registry, checks permissions, executes, and verifies.

  const VSC = '(?:vs ?code|vscode|visual studio code|code editor)';
  const SHELLS = '(?:power ?shell|pwsh|windows terminal|terminal|command prompt|cmd(?:\\.exe)?|wt|bash|wsl|shell|console)';
  const PREFIX = /^(?:hey\s+tachyon[,!]?\s+|tachyon[,:]?\s+)?(?:(?:please|pls|kindly)\s+)?(?:(?:can|could|would|will)\s+you\s+(?:please\s+)?)?(?:i\s+(?:want|need)\s+(?:you\s+)?to\s+)?/i;
  const TLDS = 'com|org|net|io|dev|ai|app|edu|gov|co|uk|in|de|fr|info|me|tv|us|ca|au|jp|ac\\.in|co\\.uk';
  const URL_RE = new RegExp('(https?:\\/\\/[^\\s]+|(?:www\\.)[^\\s]+|[a-z0-9][a-z0-9-]*(?:\\.[a-z0-9-]+)*\\.(?:' + TLDS + ')(?:\\/[^\\s]*)?)', 'i');

  const clean = (s) => String(s || '').trim().replace(/[.?!]+$/, '').trim();
  // "in my project", "for tachyon", "of the backend repo" -> "my project" / "tachyon" / "backend"
  function projectRef(tail) {
    let t = clean(tail);
    if (!t) return '';
    t = t.replace(/^(?:in|on|for|of|from|with|at|inside|into)\s+/i, '').replace(/^(?:the|my)\s+/i, '');
    t = t.replace(/\s+(?:project|folder|repo|repository|workspace)$/i, '');
    return t.trim() || 'project';
  }
  // A project reference is a short name; anything that looks like a sentence or code is not a command for us.
  const act = (connector, op, extra = {}) => (extra.project && (/[:;,(){}=<>]/.test(extra.project) || extra.project.split(/\s+/).length > 4) ? null : { kind: 'action', connector, op, args: {}, ...extra });

  function parseAgentCommand(text) {
    let t = String(text || '').trim();
    if (!t || t.length > 160 || /\n/.test(t) || /^\//.test(t)) return null;
    t = clean(t.replace(PREFIX, ''));
    let m;

    // ---- shells: never started from chat
    if ((m = new RegExp('^(?:open|launch|start|run|use|show|give me)\\s+(?:a\\s+|an\\s+|the\\s+|my\\s+)?(?:new\\s+)?' + SHELLS + '(?:\\s+(?:window|prompt|here|session))?$', 'i').exec(t))
      || /^(?:run|execute|type|enter)\s+(?:the\s+)?(?:command|cmd|script)\b/i.test(t)
      || new RegExp('^(?:run|execute)\\s+.+\\s+(?:in|with|using|on)\\s+(?:a\\s+|the\\s+)?' + SHELLS + '$', 'i').test(t)) {
      return { kind: 'refuse', reason: 'shell',
        message: 'I do not start shells or run free-form commands from chat. To open PowerShell or Windows Terminal, click its button in **Applications** (it opens in a folder you granted). From chat I can run a fixed set of safe commands: git status / branch / log, python / node / npm versions, and your project’s tests (you confirm each test run).' };
    }

    // ---- VS Code
    if ((m = new RegExp('^(?:open|launch|start|run)\\s+' + VSC + '(?:\\s+(.+))?$', 'i').exec(t))) {
      const tail = clean(m[1] || '');
      if (!tail) return act('vscode', 'open', { label: 'Open Visual Studio Code' });
      if (/^(?:in|on|with|for|at)\b/i.test(tail)) return act('vscode', 'open', { label: 'Open Visual Studio Code on a project', project: projectRef(tail) });
      if (/^and\b/i.test(tail)) return null;
      return act('vscode', 'open', { label: 'Open Visual Studio Code on a project', project: projectRef(tail) });
    }
    if ((m = new RegExp('^(?:open|launch|start|show|edit)\\s+(.+?)\\s+(?:in|with|using|on)\\s+' + VSC + '$', 'i').exec(t))) {
      return act('vscode', 'open', { label: 'Open a project in Visual Studio Code', project: projectRef(m[1]) });
    }

    // ---- Chrome and web pages
    if ((m = /^(?:open|launch|start)\s+(?:google\s+)?chrome(?:\s+(?:and|then)\s+(?:go\s+to|visit|open|navigate\s+to|browse\s+to)\s+(.+))?$/i.exec(t))) {
      if (!m[1]) return act('browser', 'open', { label: 'Open Chrome' });
      const u = URL_RE.exec(m[1]);
      return u ? act('browser', 'open', { args: { url: u[1] }, label: 'Open ' + u[1] }) : null;
    }
    if ((m = /^(?:go\s+to|visit|navigate\s+to|browse\s+to|open|load)\s+(?:the\s+(?:website|site|page|url|link)\s+)?(\S+)(?:\s+(?:in|with|using|on)\s+(?:google\s+)?(?:chrome|(?:my\s+|the\s+)?browser))?$/i.exec(t))) {
      const u = URL_RE.exec(m[1]);
      if (u && u[1].length === m[1].length) return act('browser', 'open', { args: { url: u[1] }, label: 'Open ' + u[1] });
    }

    // ---- File Explorer
    if ((m = /^(?:open|show|launch|start)\s+(?:(?:the\s+)?(?:file\s+explorer|windows\s+explorer|explorer)|(?:my\s+|the\s+)?(.+?)\s+(?:folder\s+)?in\s+(?:the\s+)?(?:file\s+explorer|windows\s+explorer|explorer))(?:\s+(.+))?$/i.exec(t))) {
      const proj = m[1] ? projectRef(m[1]) : m[2] && /^(?:in|on|for|at|to)\b/i.test(m[2]) ? projectRef(m[2]) : '';
      return act('apps', 'openExplorer', { label: proj ? 'Open the project in File Explorer' : 'Open File Explorer', project: proj || undefined });
    }

    // ---- Git (read-only)
    const gitMap = [[/^(?:git\s+status|status\s+of\s+(?:the\s+)?git|what(?:'s| is)\s+(?:the\s+)?git\s+status|show\s+(?:the\s+)?git\s+status|check\s+git(?:\s+status)?)\b(.*)$/i, 'git.status', 'Git status'],
      [/^(?:git\s+branch|which\s+(?:git\s+)?branch(?:\s+am\s+i\s+on)?|what\s+branch\s+am\s+i\s+on|what(?:'s| is)\s+(?:the\s+)?(?:current\s+)?(?:git\s+)?branch|show\s+(?:the\s+)?(?:current\s+)?branch)\b(.*)$/i, 'git.branch', 'Git branch'],
      [/^(?:git\s+log|show\s+(?:the\s+)?(?:git\s+)?(?:log|history|commits)|recent\s+commits)\b(.*)$/i, 'git.log', 'Git log'],
      [/^(?:git\s+diff(?:\s+--?stat)?|show\s+(?:the\s+)?(?:git\s+)?diff(?:\s+summary)?|what\s+changed)\b(.*)$/i, 'git.diffStat', 'Git diff summary']];
    for (const [re, cmd, label] of gitMap) {
      if ((m = re.exec(t))) { const tail = clean(m[1] || ''); if (tail && !/^(?:in|on|for|of|at|from)\b/i.test(tail)) continue; return act('git', 'read', { args: { command: cmd }, label, project: projectRef(tail) || undefined, needsProject: true }); }
    }

    // ---- tests and versions
    if ((m = /^(?:run|start|execute)\s+(?:the\s+|my\s+|all\s+)?(?:(npm\s+test|pytest|unit\s*tests?|tests?|test\s+suite|python\s+tests?))(?:\s+(.+))?$/i.exec(t))) {
      const w = m[1].toLowerCase().replace(/\s+/g, '');
      const tail = clean(m[2] || '');
      if (tail && !/^(?:in|on|for|of|at)\b/i.test(tail)) return null;
      const command = w === 'npmtest' ? 'npm.test' : w === 'pytest' ? 'python.pytest' : w === 'unittests' || w === 'unittest' ? 'python.unittest' : 'auto';
      return act('devcmd', 'test', { args: { command }, label: 'Run tests', project: projectRef(tail) || undefined, needsProject: true });
    }
    if ((m = /^(?:what(?:'s| is)\s+(?:the\s+)?|show\s+(?:me\s+)?(?:the\s+)?|check\s+(?:the\s+)?|which\s+)?(python|node(?:\.?js)?|npm)\s+version(?:\s+do\s+i\s+have)?(?:\s+(.+))?$/i.exec(t)) || (m = /^(?:which|what)\s+(python|node(?:\.?js)?|npm)\s+(?:do\s+i\s+have|is\s+installed)$/i.exec(t))) {
      const w = m[1].toLowerCase();
      const command = w.startsWith('python') ? 'python.version' : w.startsWith('node') ? 'node.version' : 'npm.version';
      return act('devcmd', 'version', { args: { command }, label: `${w} version`, needsProject: true, project: projectRef(m[2] || '') || undefined });
    }

    // ---- project, models, system
    if ((m = /^(?:inspect|summari[sz]e|analy[sz]e|describe|look\s+at)\s+(?:the\s+|my\s+)?(.+?)(?:\s+project|\s+repo|\s+repository)?$/i.exec(t)) && /\b(project|repo|repository|workspace)\b/i.test(t)) {
      return act('project', 'inspect', { label: 'Inspect the project', project: projectRef(m[1]) || 'project', needsProject: true });
    }
    if (/^(?:is\s+ollama\s+(?:running|on|up|working)|check\s+ollama(?:\s+status)?|ollama\s+status|(?:which|what)\s+(?:local\s+)?models\s+(?:are\s+)?(?:installed|available)(?:\s+(?:in|on)\s+ollama)?|list\s+(?:my\s+)?(?:installed\s+|ollama\s+)?models)$/i.test(t)) {
      return act('ollama', 'status', { label: 'Check Ollama' });
    }
    if (/^(?:(?:show|get|check)\s+(?:me\s+)?(?:the\s+)?(?:my\s+)?(?:hardware|system)\s+(?:info|information|specs?)|how\s+much\s+(?:ram|memory)\s+do\s+i\s+have|what(?:'s| is)\s+my\s+(?:hardware|system|computer)\s+(?:info|specs?))$/i.test(t)) {
      return act('system', 'info', { label: 'Hardware information' });
    }
    return null;
  }

  return { parseAgentCommand, projectRef };
});
