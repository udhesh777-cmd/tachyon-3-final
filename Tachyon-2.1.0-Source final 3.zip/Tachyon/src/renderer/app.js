'use strict';
// Tachyon - renderer. All model output is rendered with textContent (never innerHTML).

// Icons are SVG from icons.js (no emoji anywhere in the interface).
const IC = (name, size = 14) => window.TachyonIcons.icon(name, size);
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return e;
}

async function call(channel, ...args) {
  const r = await window.nova.invoke(channel, ...args);
  if (!r.ok) throw new Error(r.error);
  return r.data;
}

let toastTimer;
function toast(msg, ms = 4500) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), ms);
}

// prompt() is not available in Electron, so use small dialogs instead.
function askDialog(title, buildInput, getValue) {
  return new Promise((resolve) => {
    const input = buildInput();
    const dlg = el('dialog', { class: 'small-dialog' }, el('b', { text: title }), input,
      el('div', { class: 'row' },
        el('button', { class: 'ghost', onclick: () => { dlg.close(); resolve(null); } }, 'Cancel'),
        el('button', { class: 'primary', onclick: () => { dlg.close(); resolve(getValue(input) || null); } }, 'OK')));
    dlg.addEventListener('close', () => { dlg.remove(); resolve(null); });
    document.body.append(dlg);
    dlg.showModal();
    input.focus();
  });
}
const askText = (title, initial = '') => askDialog(title, () => el('input', { type: 'text', value: initial }), (i) => i.value.trim());
const askChoice = (title, options) => askDialog(title, () => el('select', {}, options.map(([v, l]) => el('option', { value: v }, l))), (i) => i.value);

const fmtSize = (n) => (n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB');
const fmtDate = (ms) => new Date(ms).toLocaleDateString();
const extOf = (p) => (p.includes('.') ? p.split('.').pop().toLowerCase() : '');
const TEXT_EXT = new Set(['txt', 'md', 'csv', 'tsv', 'json', 'xml', 'html', 'htm', 'css', 'js', 'ts', 'jsx', 'tsx', 'py', 'java', 'kt', 'c', 'cpp', 'h', 'cs', 'go', 'rs', 'rb', 'php', 'sh', 'bat', 'ps1', 'sql', 'yml', 'yaml', 'toml', 'ini', 'cfg', 'log', 'tex', 'gradle', 'properties', 'rtf']);
const OFFICE = new Set(['docx', 'pptx', 'xlsx']);
const VISION_IMG = new Set(['png', 'jpg', 'jpeg']);
const isText = (p) => TEXT_EXT.has(extOf(p));
const READABLE = (p) => isText(p) || extOf(p) === 'pdf' || OFFICE.has(extOf(p)) || VISION_IMG.has(extOf(p));
const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/openai/';

const state = {
  s: null, hasKey: { text: false, vision: false }, secure: true, version: '', sep: '/',
  conv: { id: null, title: 'New chat', messages: [] },
  convs: [], attachments: [], busy: false, requestId: null,
  browseDir: null, organizeFolder: '',
  pasted: [],          // images pasted into the composer: [{ path, name }]
  convFilter: '',
  speaking: null,      // message currently read aloud
  voiceTurn: false,    // the current question was spoken, so the answer is read aloud
  listening: 'off',    // microphone: 'off' | 'listening' | 'wake'
};

// ---------------------------------------------------------------- navigation
function showView(name) {
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + name));
  $$('.nav').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
  if (name === 'files') renderFiles();
  if (name === 'settings') renderSettings();
  if (name === 'chat' && window.refreshModelBadge) window.refreshModelBadge();
  if (window.TachyonViews && window.TachyonViews[name]) window.TachyonViews[name]();
}
$$('.nav').forEach((b) => b.addEventListener('click', () => showView(b.dataset.view)));

function slotReady(m, hasKey) {
  if (!m || !m.model) return false;
  return m.provider === 'cloud' ? Boolean(m.baseUrl && hasKey) : Boolean(m.host && m.port);
}
function configured() { return Boolean(state.s) && slotReady(state.s.models.text, state.hasKey.text); }
function visionAvailable() {
  if (!state.s) return false;
  const v = state.s.models.vision;
  if (v.mode === 'separate' && v.model) return slotReady(v, state.hasKey.vision || (v.baseUrl === state.s.models.text.baseUrl && state.hasKey.text));
  return configured();
}

async function refreshSettings() {
  const d = await call('settings:get');
  Object.assign(state, { s: d.settings, hasKey: d.hasKey, secure: d.secure, version: d.version, sep: d.sep });
  applyAppearance();
  renderBanner();
  if (window.applySidebar) { window.applySidebar(); window.refreshModelBadge(); }
}

// ---------------------------------------------------------------- appearance
const darkQuery = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
function applyAppearance() {
  const s = state.s || {};
  const theme = s.theme === 'system' ? (darkQuery && !darkQuery.matches ? 'light' : 'dark') : (s.theme || 'dark');
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.setProperty('--fs', (Number(s.fontSize) || 14) + 'px');
  $('#themeToggle').replaceChildren(IC(theme === 'dark' ? 'sun' : 'moon', 18));
}
if (darkQuery && darkQuery.addEventListener) darkQuery.addEventListener('change', applyAppearance);
$('#themeToggle').addEventListener('click', async () => {
  const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
  try { await call('settings:save', { settings: { theme: next } }); state.s.theme = next; applyAppearance(); } catch (e) { toast(e.message); }
});

function renderBanner() {
  const b = $('#banner');
  b.classList.toggle('hidden', configured());
  b.replaceChildren(
    el('b', { text: 'No AI provider configured. ' }),
    'Tachyon does not generate replies by itself. In Settings choose a Text model (for example Ollama qwen2.5, or Google Gemini’s free tier); add a Vision model for screenshots and OCR. ',
    el('button', { class: 'primary', onclick: () => showView('settings') }, 'Open Settings'));
}

// ---------------------------------------------------------------- images
const imgCache = new Map();
const loadImg = (p) => { if (!imgCache.has(p)) imgCache.set(p, call('image:read', p)); return imgCache.get(p); };
function imageEl(p, cls = 'msg-img') {
  const img = el('img', { class: cls, alt: 'Image' });
  loadImg(p).then((src) => { img.src = src; }).catch(() => { imgCache.delete(p); img.replaceWith(el('span', { class: 'muted small', text: '(image no longer available)' })); });
  return img;
}

// ---------------------------------------------------------------- chat rendering
function renderText(container, text) {
  text.split('```').forEach((part, i) => {
    if (i % 2 === 1) {
      const nl = part.indexOf('\n');
      const first = nl >= 0 ? part.slice(0, nl).trim() : '';
      const code = nl >= 0 && first.length <= 20 && !first.includes(' ') ? part.slice(nl + 1) : part;
      container.append(el('pre', {}, el('code', { text: code.trimEnd() })));
    } else if (part.trim()) {
      container.append(el('p', { text: part.trim() }));
    }
  });
}

function editItems(edits) {
  return el('div', { class: 'edits' }, edits.map((e) => e.ok
    ? el('div', { class: 'edit-item' }, IC('check-circle'), ' Edited ' + e.path.split(/[\\/]/).pop() + ' (backup kept as .nova-bak)',
      el('button', { onclick: async () => { try { await call('fs:restoreBackup', e.path); toast('Restored the previous version of ' + e.path.split(/[\\/]/).pop()); } catch (err) { toast(err.message); } } }, 'Undo'),
      el('button', { onclick: () => call('fs:reveal', e.path).catch((err) => toast(err.message)) }, 'Show'))
    : el('div', { class: 'edit-item' }, IC('x-circle'), ' ' + e.path.split(/[\\/]/).pop() + ': ' + e.error)));
}

function renderMessages() {
  const box = $('#messages');
  box.replaceChildren();
  const msgs = state.conv.messages;
  if (!msgs.length) {
    const ex = [
      ['file-text', 'Summarize a PDF from my documents'], ['search', 'Find the invoice that mentions "total due" and tell me the amount'],
      ['wrench', 'Fix the syntax error in my script and save it'], ['image', '/image a glowing blue jellyfish in deep space'],
      ['folder-open', 'List the files in my Downloads folder'], ['pencil', 'Write a short thank-you email and save it to my desktop'],
      ['refresh', 'Convert report.docx to PDF'], ['folder', 'Organize my Downloads folder by type'],
      ['bell', 'Remind me in 20 minutes to stretch'], ['play', 'Open Notepad'],
      ['sparkles', '/task find my resume, convert it to PDF and copy it to my desktop'], ['package', 'Create a skill that turns my notes into a to-do list'],
    ];
    box.append(el('div', { class: 'welcome' },
      el('div', { class: 'logo big', text: 'T' }), el('h2', { text: 'Hello, I’m Tachyon' }),
      el('p', { class: 'muted', text: 'Ask anything, or name a file or folder in your message and I will open it: summarize, edit, convert, list or organize it. Say “save it to …” and I save the answer there, no dialog needed. Attach with the paperclip button, drag & drop, or paste an image. The floating T button (top-right of your screen) captures the screen. Press the microphone button or say “Hey Tachyon” to talk, and type /help to see everything I can do.' }),
      el('div', { class: 'suggest' }, ex.map(([ico, t]) => el('button', { onclick: () => { $('#input').value = t; autoGrow(); $('#input').focus(); } }, el('span', { class: 'ico' }, IC(ico, 18)), el('span', { text: t }))))));
  }
  let lastUserIdx = -1;
  msgs.forEach((m, i) => { if (m.role === 'user' && !m.note) lastUserIdx = i; });
  msgs.forEach((m, i) => {
    const d = el('div', { class: 'msg ' + m.role + (m.error ? ' error' : ''), title: m.ts ? new Date(m.ts).toLocaleString() : false });
    if (m.attachments && m.attachments.length) d.append(el('div', { class: 'chips' }, m.attachments.map((a) => el('span', { class: 'chip' }, IC('paperclip', 13), ' ' + a.name))));
    (m.images || []).forEach((im) => d.append(imageEl(im.path)));
    if (m.role === 'assistant' && !m.error) { window.NovaMarkdown.render(d, m.content, document); addCodeCopy(d); } else renderText(d, m.content);
    if (m.edits && m.edits.length) d.append(editItems(m.edits));
    if (m.task) d.append(taskCard(m));
    if (m.agent && window.TachyonAgent) d.append(window.TachyonAgent.card(m));
    if (m.proposal && window.TachyonAgent) d.append(window.TachyonAgent.proposal(m));
    if (m.skillDraft) d.append(skillCard(m));
    if (m.files && m.files.length) d.append(fileHits(m.files));
    const last = i === msgs.length - 1 && !state.busy;
    if (m.route && (m.route.slot === 'vision' || m.route.usedTextForImages)) {
      d.append(el('div', { class: 'route muted small', text: m.route.slot === 'vision' ? 'Answered by the ' + m.route.label : 'Images were sent to the ' + m.route.label + ' (no separate vision model is set)' }));
    }
    if (m.note) {
      d.classList.add('note');
      if (m.savedPath) d.append(el('div', { class: 'msg-actions' }, el('button', { onclick: () => call('fs:reveal', m.savedPath).catch((err) => toast(err.message)) }, IC('folder-open'), ' Show in folder')));
    } else if (m.role === 'user' && i === lastUserIdx && !state.busy && !(m.images || []).length) {
      d.append(el('div', { class: 'msg-actions user-actions' }, el('button', { title: 'Edit this message and send it again', onclick: () => editLastQuestion(i) }, IC('pencil'), ' Edit')));
    } else if (m.role === 'assistant' && !m.error) {
      // Files are only created when the user clicks Export… (or asks for one in the chat). Nothing is attached or generated automatically.
      const hasImg = (m.images || []).length > 0;
      d.append(el('div', { class: 'msg-actions' },
        el('button', { onclick: () => { navigator.clipboard.writeText(m.content).then(() => toast('Copied')); } }, IC('copy'), ' Copy'),
        hasImg ? el('button', { onclick: async () => { try { const r = await call('image:saveAs', m.images[0].path); if (r) toast('Image saved.'); } catch (e) { toast(e.message); } } }, IC('save'), ' Save image…') : null,
        !hasImg ? el('button', { class: 'export-btn', title: 'Export this answer as PDF, Word, Markdown, JSON…', onclick: () => exportMessage(m) }, IC('download'), ' Export…') : null,
        last && !hasImg ? el('button', { onclick: retry }, IC('rotate'), ' Retry') : null,
        !hasImg && window.speechSynthesis ? el('button', { title: 'Read this answer aloud', onclick: () => speak(m) }, state.speaking === m ? [IC('square'), ' Stop reading'] : [IC('volume'), ' Read aloud']) : null));
    } else if (m.error && last) {
      d.append(el('div', { class: 'msg-actions' }, el('button', { onclick: retry }, IC('rotate'), ' Retry')));
    }
    box.append(d);
  });
  if (state.busy) box.append(el('div', { class: 'msg assistant thinking' }, el('span', { class: 'dots' }, el('i'), el('i'), el('i')), ' Tachyon is working…'));
  box.scrollTop = box.scrollHeight;
  $('#sendBtn').replaceChildren(...(state.busy ? [IC('square', 15), ' Stop'] : [IC('send', 15), ' Send']));
  $('#sendBtn').classList.toggle('stop', state.busy);
  renderChatHead();
}

function renderChatHead() {
  $('#chatTitle').textContent = state.conv.title || 'New chat';
  const a = state.conv.autoSave;
  const badge = $('#autoSaveBadge');
  badge.classList.toggle('hidden', !a);
  if (a) badge.replaceChildren(IC('save'), ' Auto-saving to ' + placeLabel(a.location) + (a.format ? ' as .' + a.format : ''),
    el('button', { title: 'Stop auto-saving', onclick: () => { delete state.conv.autoSave; renderChatHead(); saveConv(); toast('Auto-save is off for this chat.'); } }, IC('x')));
}

/** Adds a small Copy button to every code block of a rendered answer. */
function addCodeCopy(container) {
  container.querySelectorAll('pre').forEach((pre) => {
    const code = pre.querySelector('code') || pre;
    pre.classList.add('has-copy');
    pre.append(el('button', { class: 'copy-code', title: 'Copy code', onclick: (e) => { e.stopPropagation(); navigator.clipboard.writeText(code.textContent).then(() => toast('Code copied')); } }, 'Copy'));
  });
}

function speak(m) {
  if (state.speaking === m) { window.TachyonVoice.stopSpeaking(); state.speaking = null; renderMessages(); return; }
  state.speaking = m;
  window.TachyonVoice.speakText(m.content, {
    voiceName: (state.s && state.s.voiceName) || '', rate: (state.s && state.s.voiceRate) || 1,
    onEnd: () => { if (state.speaking === m) { state.speaking = null; renderMessages(); } resumeWake(); },
  });
  renderMessages();
}

function editLastQuestion(i) {
  if (state.busy) return;
  const m = state.conv.messages[i];
  state.conv.messages.splice(i);
  $('#input').value = m.content;
  state.attachments = m.attachments || [];
  renderAttachments(); renderMessages(); autoGrow();
  $('#input').focus();
}

function renderAttachments() {
  $('#attachRow').replaceChildren(...state.attachments.map((a, i) =>
    el('span', { class: 'chip' }, IC('paperclip'), ' ' + a.name, el('button', { title: 'Remove', onclick: () => { state.attachments.splice(i, 1); renderAttachments(); } }, IC('x')))),
  ...state.pasted.map((p, i) => el('span', { class: 'chip img-chip' }, imageEl(p.path, 'chip-img'), 'Pasted image',
    el('button', { title: 'Remove', onclick: () => { state.pasted.splice(i, 1); renderAttachments(); } }, IC('x')))));
  const canEdit = state.attachments.some((a) => isText(a.path));
  $('#editRow').classList.toggle('hidden', !canEdit);
  if (!canEdit) $('#allowEdits').checked = false;
}

async function saveConv() {
  const c = state.conv;
  if (!c.messages.length) return;
  if (!c.title || c.title === 'New chat') c.title = (c.messages.find((m) => m.role === 'user')?.content || 'Chat').slice(0, 40);
  try {
    const saved = await call('conv:save', c);
    // Keep the same objects on screen (buttons hold them); only take the id and times from the saved copy.
    if (state.conv === c) Object.assign(c, { id: saved.id, createdAt: saved.createdAt, updatedAt: saved.updatedAt });
  } catch { /* history is best-effort */ }
  await loadConvList();
}

async function loadConvList() {
  try { state.convs = await call('conv:list'); } catch { state.convs = []; }
  const f = state.convFilter.trim().toLowerCase();
  const shown = f ? state.convs.filter((c) => String(c.title || '').toLowerCase().includes(f)) : state.convs;
  $('#convList').replaceChildren(...(shown.length ? [] : [el('div', { class: 'muted small conv-empty', text: f ? 'No chats match.' : 'No chats yet.' })]), ...shown.map((c) => el('div', { class: 'conv' + (c.id === state.conv.id ? ' active' : ''), onclick: () => openConv(c.id) },
    el('span', { class: 't', text: c.title }),
    el('button', { title: 'Rename', onclick: async (e) => { e.stopPropagation(); const t = await askText('Rename chat', c.title); if (t) { await call('conv:rename', { id: c.id, title: t }); loadConvList(); } } }, IC('pencil')),
    el('button', { title: 'Delete', onclick: async (e) => { e.stopPropagation(); if (confirm('Delete this chat?')) { await call('conv:delete', c.id); if (state.conv.id === c.id) newChat(); else loadConvList(); } } }, IC('trash')))));
}

async function openConv(id) {
  if (state.busy) return;
  const c = await call('conv:get', id);
  if (c) { state.conv = c; state.attachments = []; renderAttachments(); renderMessages(); loadConvList(); showView('chat'); }
}

function newChat() {
  if (state.busy) return;
  state.conv = { id: null, title: 'New chat', messages: [] };
  state.attachments = [];
  state.pasted = [];
  renderAttachments(); renderMessages(); loadConvList(); showView('chat');
}

async function generate(opts = {}) {
  state.busy = true;
  state.requestId = crypto.randomUUID();
  renderMessages();
  try {
    const { reply, edits, route } = await call('chat:send', { requestId: state.requestId, messages: state.conv.messages, allowEdits: Boolean(opts.allowEdits) });
    const msg = { role: 'assistant', content: reply, edits: edits && edits.length ? edits : undefined, route, ts: Date.now() };
    state.conv.messages.push(msg);
    if (state.voiceTurn || (state.s && state.s.voiceAutoRead)) setTimeout(() => speak(msg), 50);
    if (opts.exportAfter) { state.busy = false; renderMessages(); await exportMessage(msg, opts.exportAfter); }
    if (opts.saveAfter) await autoSaveMessage(msg, opts.saveAfter);
    else if (state.conv.autoSave) await autoSaveMessage(msg, state.conv.autoSave);
  } catch (e) {
    if (e.message !== 'Cancelled.') state.conv.messages.push({ role: 'assistant', content: e.message, error: true, ts: Date.now() });
  } finally {
    state.busy = false;
    state.voiceTurn = false;
    renderMessages();
    saveConv();
  }
}

async function generateImage(prompt) {
  state.busy = true;
  renderMessages();
  try {
    const { path } = await call('image:generate', { prompt });
    state.conv.messages.push({ role: 'assistant', content: 'Image for: ' + prompt, images: [{ path }], ts: Date.now() });
  } catch (e) {
    state.conv.messages.push({ role: 'assistant', content: e.message, error: true, ts: Date.now() });
  } finally {
    state.busy = false;
    renderMessages();
    saveConv();
  }
}

async function send() {
  if (state.busy) { call('chat:cancel', state.requestId); if (window.TachyonAgent) window.TachyonAgent.cancelLive(); return; }
  const text = $('#input').value.trim();
  if (!text && !state.attachments.length && !state.pasted.length) return;
  const isImageCmd = /^\/image(\s|$)/i.test(text);
  if (isImageCmd) {
    const prompt = text.replace(/^\/image\s*/i, '').trim();
    if (!prompt) { toast('Describe the picture, e.g. /image a red fox in snow'); return; }
    if (!state.s || state.s.imageBackend === 'none') { toast('Choose an image backend in Settings first.'); showView('settings'); return; }
    state.conv.messages.push({ role: 'user', content: text, ts: Date.now() });
    $('#input').value = '';
    generateImage(prompt);
    return;
  }
  // Reminders, apps, windows, file search, multi-step tasks and skills ("remind me…", "open Spotify", "/task …", "/mycommand …")
  if (text && !state.attachments.length && !state.pasted.length && await handleCommand(text)) return;
  // "remember that …", "forget …", "what do you remember about me"
  const mem = text && !state.attachments.length && !state.pasted.length ? window.NovaIntent.parseMemoryCommand(text) : null;
  if (mem) { await runMemoryCommand(text, mem); return; }
  // "save it to D:\Reports", "save this to my desktop as notes.md", "auto-save answers to …", "stop auto-saving"
  const sv = text && !state.pasted.length ? window.NovaIntent.parseSaveIntent(text) : null;
  if (sv && sv.mode === 'off') { delete state.conv.autoSave; localExchange(text, 'Auto-save is off for this chat.'); return; }
  const ask = sv ? (text.slice(0, sv.clause[0]) + ' ' + text.slice(sv.clause[1])).trim() : text;
  if (sv && !sv.format) { const f = window.NovaIntent.parseExportIntent(ask); if (f) sv.format = f.format; }
  if (sv && sv.mode === 'always') {
    state.conv.autoSave = { location: sv.location, filename: null, format: sv.format };
    if (sv.scope === 'previous') {
      localExchange(text, `Auto-save is on. Every new answer in this chat is saved to ${placeLabel(sv.location)}${sv.format ? ' as .' + sv.format : ''}. Say “stop auto-saving” to turn it off.`);
      return;
    }
  } else if (sv && sv.scope === 'previous') {
    const lastAnswer = lastAnswerMsg();
    if (!lastAnswer) { toast('There is no answer to save yet. Ask something first, or say what to write and where to save it.'); return; }
    state.conv.messages.push({ role: 'user', content: text, note: true, ts: Date.now() });
    $('#input').value = ''; autoGrow();
    await autoSaveMessage(lastAnswer, sv);
    renderMessages(); saveConv();
    return;
  }
  const exp = text && !sv ? window.NovaIntent.parseExportIntent(text) : null;
  if (exp && exp.scope === 'previous') {
    const lastAnswer = [...state.conv.messages].reverse().find((m) => m.role === 'assistant' && !m.error && !m.note && !(m.images || []).length);
    if (lastAnswer) {
      state.conv.messages.push({ role: 'user', content: text, note: true, ts: Date.now() });
      $('#input').value = '';
      const r = await exportMessage(lastAnswer, exp.format);
      state.conv.messages.push({ role: 'assistant', content: r ? 'Exported to ' + r.path : 'Export cancelled. Nothing was saved.', note: true, ts: Date.now() });
      renderMessages(); saveConv();
      return;
    }
  }
  // Files and folders named in the message ("summarize C:\Docs\a.pdf", "list my downloads folder", "fix notes.txt")
  let autoEdit = false;
  const fr = ask && !state.pasted.length ? window.TachyonFiles.parseFileRequest(ask) : null;
  if (fr) {
    const r = await handleFileRequest(text, fr);
    if (r.done) return;
    autoEdit = Boolean(r.edit);
  } else if (text && !state.attachments.length && window.TachyonFiles.isEditFollowUp(text)) {
    const prev = recentTextAttachments();
    if (prev.length) { state.attachments.push(...prev); autoEdit = true; }
  }
  if (!configured()) { toast('Set up a Text model in Settings first.'); showView('settings'); return; }
  const allowEdits = ($('#allowEdits').checked || autoEdit) && state.attachments.some((a) => isText(a.path));
  const userMsg = { role: 'user', content: text || (state.pasted.length ? 'What is in this image?' : 'Please summarize the attached file(s).'), attachments: state.attachments, ts: Date.now() };
  if (state.pasted.length) userMsg.images = state.pasted.map((p) => ({ path: p.path }));
  state.conv.messages.push(userMsg);
  state.attachments = [];
  state.pasted = [];
  $('#input').value = '';
  autoGrow();
  renderAttachments();
  generate({ allowEdits, exportAfter: exp && exp.scope === 'new' ? exp.format : null, saveAfter: sv && sv.mode === 'once' && sv.scope === 'new' ? sv : null });
}

// ---------------------------------------------------------------- chat: memory, files, saving, local answers
async function runMemoryCommand(text, mem) {
  try {
    if (mem.op === 'add') {
      const item = await call('memory:add', mem.text);
      localExchange(text, `Got it, I’ll remember: “${item.text}”.${state.s && state.s.memoryEnabled === false ? ' (Memory is switched off in Settings, so I won’t use it until you switch it on.)' : ''} You can see or delete what I remember in Settings → Memory, or say “forget …”.`);
    } else if (mem.op === 'forget') {
      const gone = await call('memory:forget', mem.query);
      localExchange(text, gone.length ? 'Forgotten:\n' + gone.map((g) => '- ' + g.text).join('\n') : `I don’t have anything saved about “${mem.query}”. Say “what do you remember about me” to see everything.`);
    } else if (mem.op === 'forgetAll') {
      if (!confirm('Delete everything Tachyon remembers about you?')) { localExchange(text, 'Okay, nothing was deleted.'); return; }
      await call('memory:clear');
      localExchange(text, 'Done. I no longer remember anything about you.');
    } else {
      const items = await call('memory:list');
      localExchange(text, items.length ? 'Here is what I remember (stored only on this computer):\n' + items.map((g) => '- ' + g.text).join('\n') + '\n\nSay “forget …” or use Settings → Memory to delete any of it.' : 'I don’t remember anything about you yet. Say “remember that …” to teach me.');
    }
  } catch (e) { toast(e.message); }
}

// ---------------------------------------------------------------- chat: files, saving, local answers
const baseName = (p) => String(p).split(/[\\/]/).filter(Boolean).pop() || String(p);
const answerTitle = (m) => (m.content.split('\n').find((l) => l.trim()) || 'Tachyon').replace(/^[#*\s]+/, '').slice(0, 60);
function lastAnswerMsg() {
  return [...state.conv.messages].reverse().find((m) => m.role === 'assistant' && !m.error && !m.note && !(m.images || []).length);
}
function placeLabel(loc) {
  if (!loc) return 'Documents';
  if (loc.kind === 'known') return loc.value.charAt(0).toUpperCase() + loc.value.slice(1);
  return loc.value;
}

/** Adds the user's message and a local (no AI) answer. Notes are not sent to the model later. */
function localExchange(text, answer, { note = true, savedPath } = {}) {
  state.conv.messages.push({ role: 'user', content: text, note: note || undefined, ts: Date.now() });
  const a = { role: 'assistant', content: answer, note: note || undefined, savedPath, ts: Date.now() };
  state.conv.messages.push(a);
  $('#input').value = ''; autoGrow();
  renderMessages(); saveConv();
  if (state.voiceTurn) { state.voiceTurn = false; speak(a); }
}

async function autoSaveMessage(m, sv) {
  try {
    const r = await call('export:autoSave', { location: sv.location || null, filename: sv.filename || null, format: sv.format || null, title: answerTitle(m), text: m.content });
    let note = 'Saved to ' + r.path;
    if (r.replacedChars) note += ` (${r.replacedChars} unsupported character(s) replaced with “?”; no Unicode font found)`;
    state.conv.messages.push({ role: 'assistant', content: note, note: true, savedPath: r.path, ts: Date.now() });
    toast(note, 6000);
    return r;
  } catch (e) {
    state.conv.messages.push({ role: 'assistant', content: 'Could not save: ' + e.message, note: true, ts: Date.now() });
    return null;
  }
}

/** The text files attached most recently in this chat, for "now fix the typo in it". */
function recentTextAttachments() {
  const msgs = state.conv.messages;
  for (let i = msgs.length - 1, seen = 0; i >= 0 && seen < 6; i--, seen++) {
    const atts = (msgs[i].role === 'user' && msgs[i].attachments) || [];
    const text = atts.filter((a) => isText(a.path));
    if (text.length) return text.map((a) => ({ path: a.path, name: a.name }));
  }
  return [];
}

function addAttachment(f) {
  if (!state.attachments.some((a) => a.path === f.path)) state.attachments.push({ path: f.path, name: f.name });
}

/** Attaches readable files from a folder (top level only, at most 10). */
async function attachFolder(dir) {
  const items = await call('fs:list', dir);
  const files = items.filter((x) => !x.isDir && READABLE(x.path)).slice(0, 10);
  files.forEach(addAttachment);
  return files.length;
}

function listingMarkdown(dir, items) {
  const esc = (t) => String(t).replace(/\|/g, '\\|');
  const rows = items.slice(0, 200).map((f) => `| ${esc(f.name)}${f.isDir ? '/' : ''} | ${f.isDir ? 'Folder' : (extOf(f.name) || 'file').toUpperCase()} | ${f.isDir ? '' : fmtSize(f.size)} | ${fmtDate(f.mtime)} |`);
  const dirs = items.filter((x) => x.isDir).length;
  return [`**${dir}** contains ${items.length - dirs} file(s) and ${dirs} folder(s).`, '',
    '| Name | Type | Size | Modified |', '|---|---|---|---|', ...rows,
    ...(items.length > 200 ? ['', `…and ${items.length - 200} more.`] : [])].join('\n');
}

/** Runs a file/folder request from the chat. Returns { done } when answered locally, else { edit } after attaching. */
async function handleFileRequest(text, fr) {
  let items;
  try { items = await call('files:resolve', { candidates: fr.targets }); } catch (e) { toast(e.message); return {}; }
  items.filter((x) => x.note).forEach((x) => toast(x.note, 8000));
  const ok = items.filter((x) => x.allowed && !x.missing);
  const denied = items.filter((x) => x.denied);
  if (!ok.length) {
    if (denied.length) { toast('Okay, I did not open ' + denied.map((x) => x.name).join(', ') + '.'); return { done: true }; }
    const typed = items.filter((x) => x.missing && fr.targets.some((t) => t.value === x.input && t.kind !== 'name'));
    if (typed.length) toast('I could not find ' + typed.map((x) => x.path || x.input).join(', ') + '. Check the path and try again.', 8000);
    return {};
  }
  const files = ok.filter((x) => !x.isDir);
  const dirs = ok.filter((x) => x.isDir);
  const lines = [];
  let savedPath;
  const fail = (x, e) => lines.push(`Failed: ${x.name}: ${e.message}`);
  switch (fr.op) {
    case 'list': {
      if (!dirs.length) break;
      const parts = [];
      for (const d of dirs) { try { parts.push(listingMarkdown(d.path, await call('fs:list', d.path))); } catch (e) { parts.push(`Failed: ${d.path}: ${e.message}`); } }
      localExchange(text, parts.join('\n\n'), { note: false });
      return { done: true };
    }
    case 'organize': {
      if (!dirs.length) break;
      for (const d of dirs) {
        try {
          const plan = await call('fs:planSort', { folder: d.path, mode: fr.mode || 'type', onlyImages: false });
          if (!plan.length) { lines.push(`${d.path}: no files to move (only files directly inside the folder are sorted).`); continue; }
          const groups = {};
          plan.forEach((x) => { groups[x.to] = (groups[x.to] || 0) + 1; });
          const summary = Object.entries(groups).map(([k, n]) => `${k}/ (${n})`).join(', ');
          if (!confirm(`Move ${plan.length} file(s) in ${d.path} into sub-folders?\n${summary}\n\nNothing is deleted or overwritten, and you can undo it.`)) { lines.push(`${d.path}: nothing was moved.`); continue; }
          const r = await call('fs:applySort', { folder: d.path, mode: fr.mode || 'type', onlyImages: false });
          lines.push(`Organized ${d.path}: moved ${r.moved} file(s) into ${summary}${r.failed ? `, ${r.failed} failed` : ''}. To undo, open Files & PDFs → Organize → “Undo last organize”.`);
        } catch (e) { fail(d, e); }
      }
      localExchange(text, lines.join('\n'));
      return { done: true };
    }
    case 'convert': {
      if (!files.length) break;
      for (const f of files) {
        try {
          const img = window.TachyonFiles.isImagePath(f.path) && ['png', 'jpg'].includes(fr.format);
          const r = img ? await call('image:op', { path: f.path, op: 'convert', format: fr.format }) : await call('files:convert', { path: f.path, format: fr.format });
          savedPath = r.path;
          lines.push(`Created ${r.path} (the original is unchanged).${r.truncated ? ' The text was long and was shortened.' : ''}`);
        } catch (e) { fail(f, e); }
      }
      localExchange(text, lines.join('\n'), { savedPath });
      return { done: true };
    }
    case 'resize': {
      const imgs = files.filter((f) => window.TachyonFiles.isImagePath(f.path));
      if (!imgs.length) break;
      const w = fr.width || Number(await askText('New width in pixels (the original is backed up as .nova-bak)', '1280'));
      if (!w) return { done: true };
      for (const f of imgs) {
        try { const r = await call('image:op', { path: f.path, op: 'resize', width: w }); savedPath = f.path; lines.push(`Resized ${f.name} to ${r.size.width}×${r.size.height}. Backup: ${baseName(r.backup)}.`); } catch (e) { fail(f, e); }
      }
      localExchange(text, lines.join('\n'), { savedPath });
      return { done: true };
    }
    case 'open': {
      for (const x of ok) { try { await call('files:open', x.path); lines.push('Opened ' + x.path); } catch (e) { fail(x, e); } }
      localExchange(text, lines.join('\n'));
      return { done: true };
    }
    case 'reveal': {
      for (const x of ok) { try { await call('fs:reveal', x.path); lines.push('Showing ' + x.path); } catch (e) { fail(x, e); } }
      localExchange(text, lines.join('\n'), { savedPath: ok[0].path });
      return { done: true };
    }
    default:
  }
  // read / ask / edit: attach the files (and readable files directly inside named folders) and ask the model
  const skipped = [];
  for (const f of files) { if (READABLE(f.path)) addAttachment(f); else skipped.push(f.name); }
  for (const d of dirs) {
    try { const n = await attachFolder(d.path); if (!n) skipped.push(d.name + ' (no readable files)'); } catch (e) { skipped.push(d.name + ': ' + e.message); }
  }
  if (skipped.length) toast('Not attached: ' + skipped.join(', ') + '. I can read PDF, Word, PowerPoint, Excel, text/code files and PNG/JPEG images.', 8000);
  renderAttachments();
  return { edit: fr.op === 'edit' };
}

// ---------------------------------------------------------------- composer: attach, drop, paste, grow
function autoGrow() {
  const t = $('#input');
  t.style.height = 'auto';
  t.style.height = Math.min(t.scrollHeight, 220) + 'px';
}
$('#input').addEventListener('input', autoGrow);

async function pickFiles() {
  try {
    const picked = await call('files:pick', {});
    if (!picked.length) return;
    picked.forEach(addAttachment);
    renderAttachments(); showView('chat'); $('#input').focus();
    toast(`Attached ${picked.length} file(s). Ask your question and press Send.`);
  } catch (e) { toast(e.message); }
}
$('#attachBtn').addEventListener('click', pickFiles);

async function attachPaths(paths) {
  if (!paths.length) return;
  try {
    const items = await call('files:allowDropped', paths);
    let n = 0;
    for (const x of items) {
      if (x.isDir) n += await attachFolder(x.path);
      else if (READABLE(x.path)) { addAttachment(x); n++; } else toast(`Cannot read .${extOf(x.name)} files yet.`);
    }
    renderAttachments();
    if (n) toast(`Attached ${n} file(s). Ask your question and press Send.`);
  } catch (e) { toast(e.message); }
}

const chatView = $('#view-chat');
let dragDepth = 0;
chatView.addEventListener('dragenter', (e) => { if ([...(e.dataTransfer?.types || [])].includes('Files')) { dragDepth++; $('#dropZone').classList.remove('hidden'); } });
chatView.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) $('#dropZone').classList.add('hidden'); });
chatView.addEventListener('dragover', (e) => e.preventDefault());
chatView.addEventListener('drop', (e) => {
  e.preventDefault();
  dragDepth = 0; $('#dropZone').classList.add('hidden');
  const paths = [...(e.dataTransfer?.files || [])].map((f) => window.nova.pathForFile ? window.nova.pathForFile(f) : '').filter(Boolean);
  attachPaths(paths);
});
document.addEventListener('dragover', (e) => e.preventDefault());
document.addEventListener('drop', (e) => e.preventDefault());

function readAsDataUrl(file) {
  return new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = () => reject(r.error); r.readAsDataURL(file); });
}
$('#input').addEventListener('paste', async (e) => {
  const files = [...(e.clipboardData?.files || [])];
  if (!files.length) return;
  e.preventDefault();
  const withPath = files.map((f) => ({ f, p: window.nova.pathForFile ? window.nova.pathForFile(f) : '' }));
  await attachPaths(withPath.filter((x) => x.p).map((x) => x.p));
  for (const { f } of withPath.filter((x) => !x.p && /^image\//.test(x.f.type))) {
    try { state.pasted.push(await call('image:savePasted', await readAsDataUrl(f))); } catch (err) { toast(err.message); }
  }
  renderAttachments();
});

$('#convSearch').addEventListener('input', (e) => { state.convFilter = e.target.value; loadConvList(); });

async function exportChat() {
  const msgs = state.conv.messages.filter((m) => !m.note && !m.error);
  if (!msgs.length) { toast('Nothing to export yet.'); return; }
  const fmt = await askChoice('Export the whole chat as…', [['pdf', 'PDF'], ['docx', 'Word document (.docx)'], ['md', 'Markdown'], ['txt', 'Plain text'], ['html', 'HTML']]);
  if (!fmt) return;
  const text = msgs.map((m) => `${m.role === 'user' ? '**You:**' : '**Tachyon:**'}\n${m.content}`).join('\n\n');
  try {
    const r = await call('export:save', { title: state.conv.title || 'Tachyon chat', text, format: fmt });
    if (r) { toast('Saved: ' + r.path, 7000); call('fs:reveal', r.path).catch(() => {}); }
  } catch (e) { toast('Could not export: ' + e.message); }
}
$('#exportChat').addEventListener('click', exportChat);

window.addEventListener('keydown', (e) => {
  const mod = e.ctrlKey || e.metaKey;
  if (e.key === 'Escape' && state.busy) { call('chat:cancel', state.requestId); if (window.TachyonAgent) window.TachyonAgent.cancelLive(); return; }
  if (!mod || e.altKey) return;
  const k = e.key.toLowerCase();
  if (k === 'n' && !e.shiftKey) { e.preventDefault(); newChat(); $('#input').focus(); } else if (k === 'k') { e.preventDefault(); $('#convSearch').focus(); } else if (k === 'o') { e.preventDefault(); pickFiles(); } else if (k === ',') { e.preventDefault(); showView('settings'); } else if (k === 'l') { e.preventDefault(); showView('chat'); $('#input').focus(); }
});

function retry() {
  if (state.busy) return;
  const msgs = state.conv.messages;
  if (msgs.length && msgs[msgs.length - 1].role === 'assistant') msgs.pop();
  const lastUser = [...msgs].reverse().find((m) => m.role === 'user');
  if (lastUser && /^\/image(\s|$)/i.test(lastUser.content)) generateImage(lastUser.content.replace(/^\/image\s*/i, '').trim());
  else generate();
}

async function exportMessage(m, format) {
  const title = (m.content.split('\n').find((l) => l.trim()) || 'Tachyon').replace(/^[#*\s]+/, '').slice(0, 60);
  let fmt = format;
  if (!fmt) {
    fmt = await askChoice('Export as…', [['pdf', 'PDF'], ['docx', 'Word document (.docx)'], ['md', 'Markdown'], ['txt', 'Plain text'], ['html', 'HTML'], ['csv', 'CSV'], ['json', 'JSON'], ['py', 'Python file (code block only)'], ['js', 'JavaScript file (code block only)']]);
    if (!fmt) return null;
  }
  try {
    const r = await call('export:save', { title, text: m.content, format: fmt });
    if (!r) return null;
    let note = 'Saved: ' + r.path;
    if (r.replacedChars) note += ` (${r.replacedChars} unsupported character(s) replaced with “?”; no Unicode font found)`;
    toast(note, 7000);
    call('fs:reveal', r.path).catch(() => {});
    return r;
  } catch (e) { toast('Could not export: ' + e.message); return null; }
}

$('#sendBtn').addEventListener('click', send);
$('#input').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
$('#newChat').addEventListener('click', newChat);

function attachFile(f) {
  if (!state.attachments.some((a) => a.path === f.path)) state.attachments.push({ path: f.path, name: f.name });
  renderAttachments();
  showView('chat');
  $('#input').focus();
  toast(`Attached ${f.name}. Ask your question and press Send.`);
}

// ---------------------------------------------------------------- analysis dialog
async function openAnalysis(f) {
  const dlg = $('#analysis');
  $('#analysisTitle').textContent = f.name;
  $('#analysisReport').textContent = 'Analyzing…';
  $('#analysisOut').textContent = '';
  $('#analysisActions').replaceChildren();
  $('#analysisImg').classList.add('hidden');
  dlg.showModal();
  const out = $('#analysisOut');
  const actions = $('#analysisActions');
  const e = extOf(f.path);
  try {
    if (VISION_IMG.has(e)) {
      $('#analysisReport').textContent = `Image: ${f.name}\nSize: ${fmtSize(f.size)}\nPath: ${f.path}\n\nObject detection and text extraction use your configured vision model (local if it is an Ollama vision model such as llava).`;
      loadImg(f.path).then((src) => { const im = $('#analysisImg'); im.src = src; im.classList.remove('hidden'); }).catch(() => {});
      for (const [mode, icoName, label] of [['objects', 'search', 'Detect objects'], ['ocr', 'file-text', 'Extract text (OCR)'], ['describe', 'file-text', 'Describe']]) {
        actions.append(el('button', { onclick: async () => {
          if (!visionAvailable()) { out.textContent = 'Set up a Vision model (or a vision-capable Text model) in Settings first.'; return; }
          out.textContent = 'Asking the vision model…';
          try { out.textContent = await call('image:analyze', { path: f.path, mode }); } catch (err) { out.textContent = err.message; }
        } }, IC(icoName), ' ' + label));
      }
      actions.append(el('button', { onclick: () => { $('#analysis').close(); attachFile(f); } }, IC('message-square'), ' Ask AI about it'));
      return;
    }
    const a = await call('fs:analyze', f.path);
    $('#analysisReport').textContent = a.report + (a.preview ? '\n\n--- Preview ---\n' + a.preview : '');
    if (READABLE(f.path)) actions.append(el('button', { onclick: () => { $('#analysis').close(); attachFile(f); } }, IC('message-square'), ' Ask AI about it'));
    if (a.diagnostics && a.diagnostics.length && isText(f.path)) {
      actions.append(el('button', { class: 'primary', onclick: async () => {
        if (!configured()) { out.textContent = 'Set up an AI provider in Settings first.'; return; }
        out.textContent = 'Asking the AI to fix the problems…';
        try {
          const instr = 'Fix these problems without changing anything else:\n' + a.diagnostics.map((d) => `${d.line ? 'line ' + d.line + ': ' : ''}${d.message}`).join('\n');
          const r = await call('fs:aiEdit', { path: f.path, instruction: instr });
          out.textContent = r.applied ? `Fixed and saved. The previous version is kept as ${f.name}.nova-bak (use Edit → Restore backup to undo).`
            : (r.warning ? 'The AI’s proposal was not applied: ' + r.warning : 'Review mode: open Edit to see the proposal.') + '\n\n' + r.proposal.slice(0, 3000);
        } catch (err) { out.textContent = err.message; }
      } }, IC('wrench'), ' Fix with AI'));
    }
  } catch (err) { $('#analysisReport').textContent = err.message; }
}
$('#analysisClose').addEventListener('click', () => $('#analysis').close());

// ---------------------------------------------------------------- files
function fileRow(f, { snippet } = {}) {
  const e = extOf(f.path);
  const analyzable = READABLE(f.path);
  return el('div', { class: 'item' },
    el('div', { class: 'name' }, el('b', { text: f.name }), el('span', { text: snippet || `${f.path}  ·  ${fmtSize(f.size)}  ·  ${fmtDate(f.mtime)}` })),
    el('div', { class: 'actions' },
      analyzable ? el('button', { onclick: () => attachFile(f) }, IC('message-square'), ' Ask AI') : null,
      analyzable ? el('button', { onclick: () => openAnalysis(f) }, IC('search'), ' Analyze') : null,
      isText(f.path) ? el('button', { onclick: () => openEditor(f) }, IC('pencil'), ' Edit') : null,
      e === 'pdf' || OFFICE.has(e) ? el('button', { title: 'Creates a NEW PDF; the original is never changed', onclick: () => rewriteToPdf(f) }, IC('sparkles'), ' Rewrite → PDF') : null,
      VISION_IMG.has(e) ? el('button', { onclick: () => resizeImage(f) }, 'Resize') : null,
      VISION_IMG.has(e) ? el('button', { onclick: () => convertImage(f) }, 'Convert') : null,
      el('button', { onclick: () => call('fs:reveal', f.path).catch((err) => toast(err.message)) }, 'Show')));
}

async function rewriteToPdf(f) {
  if (!configured()) { toast('Set up an AI provider in Settings first.'); return; }
  const instr = await askText('What should the AI do? (e.g. summarize in 10 bullets, translate to English)', '');
  if (!instr) return;
  toast('Working… this can take a minute.', 60000);
  try {
    const r = await call('fs:pdfRewrite', { path: f.path, instruction: instr });
    toast('Created ' + r.path.split(/[\\/]/).pop() + ' next to the original.' + (r.replacedChars ? ` (${r.replacedChars} unsupported character(s) replaced)` : ''), 7000);
    call('fs:reveal', r.path).catch(() => {});
  } catch (e) { toast(e.message); }
}
async function resizeImage(f) {
  const w = await askText('New width in pixels (the original is backed up as .nova-bak)', '1280');
  if (!w) return;
  try { const r = await call('image:op', { path: f.path, op: 'resize', width: Number(w) }); toast('Resized. Backup: ' + r.backup.split(/[\\/]/).pop()); } catch (e) { toast(e.message); }
}
async function convertImage(f) {
  const fmt = await askChoice('Convert to…', [['png', 'PNG'], ['jpg', 'JPEG']]);
  if (!fmt) return;
  try { const r = await call('image:op', { path: f.path, op: 'convert', format: fmt }); toast('Created ' + r.path.split(/[\\/]/).pop()); } catch (e) { toast(e.message); }
}

function renderFiles() {
  const fp = $('#foldersPanel');
  const folders = state.s.folders;
  fp.replaceChildren(
    el('b', { text: 'Folders Tachyon may use' }),
    el('p', { class: 'muted small', text: 'Tachyon only reads or changes files inside these folders, when you press a button or ask it to. It never uploads files by itself and never deletes files; edits always keep a .nova-bak backup. File text is sent to your AI provider only when you attach a file, use Ask AI, or let the AI edit it.' }),
    folders.length ? el('div', { class: 'list' }, folders.map((f) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: f })),
      el('button', { onclick: async () => { state.s.folders = await call('folders:remove', f); state.browseDir = null; renderFiles(); } }, 'Remove')))) : el('p', { class: 'muted', text: 'No folders yet.' }),
    el('div', { class: 'row' }, el('button', { class: 'primary', onclick: async () => { try { const r = await call('folders:add'); if (r) { state.s.folders = r; renderFiles(); } } catch (e) { toast(e.message); } } }, '+ Add folder')));
  renderBrowse(); renderFind(); renderInside(); renderOrganize();
}

$$('.tab').forEach((t) => t.addEventListener('click', () => {
  $$('.tab').forEach((x) => x.classList.toggle('active', x === t));
  $$('.tabview').forEach((v) => v.classList.toggle('active', v.id === 'tab-' + t.dataset.tab));
}));

async function renderBrowse() {
  const box = $('#tab-browse');
  const folders = state.s.folders;
  if (!folders.length) { box.replaceChildren(el('p', { class: 'muted', text: 'Add a folder first.' })); return; }
  if (!state.browseDir || !folders.some((f) => state.browseDir === f || state.browseDir.startsWith(f + state.sep))) state.browseDir = null;
  if (!state.browseDir) {
    box.replaceChildren(el('div', { class: 'list' }, folders.map((f) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', {}, IC('folder'), ' ' + f)), el('button', { onclick: () => { state.browseDir = f; renderBrowse(); } }, 'Open')))));
    return;
  }
  try {
    const items = await call('fs:list', state.browseDir);
    const isRoot = folders.includes(state.browseDir);
    const parent = state.browseDir.slice(0, state.browseDir.lastIndexOf(state.sep)) || state.sep;
    box.replaceChildren(
      el('div', { class: 'row' },
        el('button', { onclick: () => { state.browseDir = isRoot ? null : parent; renderBrowse(); } }, IC('arrow-left'), ' Up'),
        el('span', { class: 'muted', text: state.browseDir }),
        el('button', { onclick: () => { state.organizeFolder = state.browseDir; renderOrganize(); $$('.tab').find((t) => t.dataset.tab === 'organize').click(); } }, 'Organize this folder…')),
      el('div', { class: 'list' }, items.length ? items.map((f) => f.isDir
        ? el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', {}, IC('folder'), ' ' + f.name)), el('button', { onclick: () => { state.browseDir = f.path; renderBrowse(); } }, 'Open'))
        : fileRow(f)) : [el('div', { class: 'item muted', text: 'Empty folder' })]));
  } catch (e) { box.replaceChildren(el('p', { class: 'muted', text: e.message })); }
}

function searchTab(boxId, build) {
  const box = $(boxId);
  const results = el('div');
  const status = el('p', { class: 'muted small' });
  box.replaceChildren(...build(results, status));
}

function renderFind() {
  searchTab('#tab-find', (results, status) => {
    const q = el('input', { type: 'text', placeholder: 'File name contains… (leave empty to list a type)' });
    const kind = el('select', {}, el('option', { value: 'all' }, 'All files'), el('option', { value: 'pdf' }, 'PDFs'), el('option', { value: 'docs' }, 'Documents'), el('option', { value: 'images' }, 'Images'));
    const go = async () => {
      status.textContent = 'Searching…'; results.replaceChildren();
      try {
        const items = await call('fs:findName', { q: q.value, kind: kind.value });
        status.textContent = `${items.length} result(s)` + (items.length >= 300 ? ' (showing the first 300)' : '');
        results.replaceChildren(el('div', { class: 'list' }, items.map((f) => fileRow(f))));
      } catch (e) { status.textContent = e.message; }
    };
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    return [el('div', { class: 'row' }, q, kind, el('button', { class: 'primary', onclick: go }, 'Search')), status, results];
  });
}

function renderInside() {
  searchTab('#tab-inside', (results, status) => {
    const q = el('input', { type: 'text', placeholder: 'Text to find inside documents…' });
    const go = async () => {
      status.textContent = 'Searching inside files (PDF and Office files can take a while)…'; results.replaceChildren();
      try {
        const r = await call('fs:findInside', { q: q.value });
        status.textContent = `${r.items.length} file(s). Scanned ${r.scannedPdfs} PDF/Office file(s)` + (r.skippedPdfs ? `, skipped ${r.skippedPdfs} (limit)` : '') + '. Scanned/image-only PDFs have no searchable text.';
        results.replaceChildren(el('div', { class: 'list' }, r.items.map((f) => fileRow(f, { snippet: '…' + f.snippet + '…' }))));
      } catch (e) { status.textContent = e.message; }
    };
    q.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    return [el('p', { class: 'muted small', text: 'Searches text inside PDFs, Word (.docx), PowerPoint (.pptx), Excel (.xlsx), notes, code, CSV and JSON files.' }),
      el('div', { class: 'row' }, q, el('button', { class: 'primary', onclick: go }, 'Search'), el('button', { onclick: () => call('fs:cancelScan') }, 'Stop')), status, results];
  });
}

function renderOrganize() {
  searchTab('#tab-organize', (results, status) => {
    const folders = state.s.folders;
    if (!folders.length) return [el('p', { class: 'muted', text: 'Add a folder first.' })];
    const folder = el('input', { type: 'text', value: state.organizeFolder || folders[0] });
    const pick = el('select', { onchange: () => { folder.value = pick.value; } }, folders.map((f) => el('option', { value: f }, f)));
    const mode = el('select', {}, el('option', { value: 'type' }, 'By type (Images, PDFs, Documents…)'), el('option', { value: 'month' }, 'By month modified'), el('option', { value: 'ext' }, 'By file extension'));
    const onlyImg = el('input', { type: 'checkbox' });
    const args = () => ({ folder: folder.value.trim(), mode: mode.value, onlyImages: onlyImg.checked });
    const apply = el('button', { class: 'primary hidden' }, 'Move files');
    const preview = async () => {
      results.replaceChildren(); apply.classList.add('hidden');
      try {
        const plan = await call('fs:planSort', args());
        if (!plan.length) { status.textContent = 'No files to move directly inside this folder.'; return; }
        const groups = {};
        plan.forEach((p) => { (groups[p.to] = groups[p.to] || []).push(p.name); });
        status.textContent = `${plan.length} file(s) would be moved (sub-folders are created inside the chosen folder). Nothing is deleted or overwritten.`;
        results.replaceChildren(el('div', { class: 'list' }, Object.entries(groups).map(([to, names]) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: to + '/  (' + names.length + ')' }), el('span', { text: names.slice(0, 6).join(', ') + (names.length > 6 ? '…' : '') }))))));
        apply.classList.remove('hidden');
      } catch (e) { status.textContent = e.message; }
    };
    apply.addEventListener('click', async () => {
      if (!confirm('Move these files into sub-folders now? You can undo the last organize afterwards.')) return;
      try {
        const r = await call('fs:applySort', args());
        status.textContent = `Moved ${r.moved} file(s)` + (r.failed ? `, ${r.failed} failed` : '') + '. You can undo this.';
        results.replaceChildren(); apply.classList.add('hidden');
      } catch (e) { status.textContent = e.message; }
    });
    const undo = el('button', { onclick: async () => {
      if (!confirm('Move the files from the last organize back to where they were?')) return;
      try { const r = await call('fs:undoSort'); status.textContent = `Restored ${r.restored} file(s)` + (r.skipped ? `, skipped ${r.skipped}` : '') + '.'; } catch (e) { status.textContent = e.message; }
    } }, IC('undo'), ' Undo last organize');
    return [el('p', { class: 'muted small', text: 'Sorts the files directly inside a folder (not sub-folders) into sub-folders. Preview first; nothing moves until you confirm.' }),
      el('div', { class: 'row' }, folder, pick), el('div', { class: 'row' }, mode, el('label', {}, onlyImg, ' only images')),
      el('div', { class: 'row' }, el('button', { onclick: preview }, 'Preview'), apply, undo), status, results];
  });
}

// ---------------------------------------------------------------- editor
let editing = null;
async function openEditor(f) {
  try {
    const text = await call('fs:readEditable', f.path);
    editing = { path: f.path, original: text };
    $('#editorTitle').textContent = f.name;
    $('#editorText').value = text;
    $('#editorInstr').value = '';
    $('#editorMsg').textContent = '';
    $('#editor').showModal();
  } catch (e) { toast(e.message); }
}
$('#editorClose').addEventListener('click', () => $('#editor').close());
$('#editorRevert').addEventListener('click', () => { $('#editorText').value = editing.original; $('#editorMsg').textContent = 'Reverted to the text on disk.'; });
$('#editorUndo').addEventListener('click', async () => {
  try {
    await call('fs:restoreBackup', editing.path);
    const t = await call('fs:readEditable', editing.path);
    editing.original = t; $('#editorText').value = t;
    $('#editorMsg').textContent = 'Restored the version from the .nova-bak backup (click again to switch back).';
  } catch (e) { $('#editorMsg').textContent = e.message; }
});
$('#editorAsk').addEventListener('click', async () => {
  const instr = $('#editorInstr').value.trim();
  if (!instr) return;
  if (!configured()) { toast('Set up an AI provider in Settings first.'); return; }
  $('#editorMsg').textContent = 'Asking the AI…';
  $('#editorAsk').disabled = true;
  try {
    // Save any manual changes first so the AI edits what you see.
    if ($('#editorText').value !== editing.original) {
      await call('fs:write', { path: editing.path, text: $('#editorText').value });
      editing.original = $('#editorText').value;
    }
    const r = await call('fs:aiEdit', { path: editing.path, instruction: instr });
    $('#editorText').value = r.proposal;
    if (r.applied) { editing.original = r.proposal; $('#editorMsg').textContent = 'AI edit applied and saved. The previous version is kept as .nova-bak (use “Restore backup” to undo).'; }
    else if (r.warning) $('#editorMsg').textContent = 'Not saved: ' + r.warning + ' Review the text below.';
    else $('#editorMsg').textContent = r.original && r.proposal.length < r.original.length / 2 ? 'AI proposal loaded, but it is much shorter than the original. Review carefully, then Save.' : 'AI proposal loaded. Review it, then Save.';
  } catch (e) { $('#editorMsg').textContent = e.message; } finally { $('#editorAsk').disabled = false; }
});
$('#editorSave').addEventListener('click', async () => {
  const text = $('#editorText').value;
  if (text === editing.original) { $('#editorMsg').textContent = 'No changes to save.'; return; }
  if (!confirm('Overwrite this file? The previous version is kept as a .nova-bak copy.')) return;
  try {
    const w = await call('fs:write', { path: editing.path, text });
    editing.original = text;
    $('#editorMsg').textContent = (w && w.verified ? 'Saved and checked: the file was read back and matches (' + fmtSize(w.bytes) + '). ' : 'Saved. ') + 'Backup kept next to the file (.nova-bak).';
  } catch (e) { $('#editorMsg').textContent = e.message; }
});

// ---------------------------------------------------------------- settings
function field(label, input, hint) {
  return el('div', { class: 'field' }, el('label', { text: label }), input, hint ? el('div', { class: 'muted small', text: hint }) : null);
}

/** One model card (Text or Vision): provider, connection details, key, model list and a real test. */
function slotCard(slot, title, intro, m, { isVision = false } = {}) {
  const sel = el('select', {}, el('option', { value: 'local' }, 'Ollama (local, http://localhost:11434)'), el('option', { value: 'gemini' }, 'Google Gemini (cloud, free tier available)'), el('option', { value: 'custom' }, 'Other cloud API (OpenAI-compatible)'));
  sel.value = m.provider === 'local' ? 'local' : m.preset === 'gemini' ? 'gemini' : 'custom';
  const baseUrl = el('input', { type: 'text', value: m.baseUrl, placeholder: 'https://…/v1' });
  const key = el('input', { type: 'password', placeholder: state.hasKey[slot] ? 'Key saved (leave empty to keep it)' : (isVision ? 'API key (leave empty to reuse the Text model’s key for the same service)' : 'Paste your API key') });
  const listId = 'models-' + slot;
  const model = el('input', { type: 'text', value: m.model, placeholder: isVision ? 'e.g. qwen2.5vl:3b, minicpm-v, or a Gemini Flash model' : 'e.g. qwen2.5, or a Gemini Flash-Lite model', list: listId });
  const datalist = el('datalist', { id: listId });
  const host = el('input', { type: 'text', value: m.host });
  const port = el('input', { type: 'text', value: m.port });
  const result = el('p', { class: 'small' });
  const geminiNote = el('p', { class: 'muted small', text: 'Gemini has a free tier (no card). Create a key in Google AI Studio, then “List models” and pick a current Flash or Flash-Lite model' + (isVision ? ' (Gemini Flash models read images)' : '') + '. Google says free-tier content may be used to improve its products: avoid confidential data.' });
  const cloudBox = el('div', {}, geminiNote, field('API base URL (https only)', baseUrl),
    field('API key', key, state.secure ? 'Stored encrypted with your operating system’s secure storage.' : 'Secure storage is unavailable: the key is kept in memory for this session only.'));
  const localBox = el('div', {}, field('Host', host), field('Port', port));
  const collect = () => ({
    provider: sel.value === 'local' ? 'local' : 'cloud', preset: sel.value === 'gemini' ? 'gemini' : 'custom',
    baseUrl: sel.value === 'gemini' ? GEMINI_URL : baseUrl.value, model: model.value, host: host.value, port: port.value,
  });
  const listModels = async () => {
    const c = collect();
    try {
      const names = c.provider === 'local' ? await call('provider:models', { host: c.host.trim(), port: c.port.trim() }) : await call('provider:cloudModels', { slot, baseUrl: c.baseUrl, apiKey: key.value });
      datalist.replaceChildren(...names.map((n) => el('option', { value: n })));
      result.textContent = names.length ? 'Available models: ' + names.slice(0, 40).join(', ') : 'Connected, but no models were listed.';
    } catch (e) { result.textContent = 'Failed: ' + e.message; }
  };
  const test = async () => {
    result.textContent = isVision ? 'Sending a test image…' : 'Testing…';
    try { result.textContent = 'OK: ' + await call('provider:test', { slot, vision: isVision, ...collect(), apiKey: key.value }); } catch (e) { result.textContent = 'Failed: ' + e.message; }
  };
  const fields = el('div', {}, field('Provider', sel), cloudBox, localBox, field('Model', model, isVision ? 'Text-only models such as qwen2.5 cannot read images.' : null), datalist,
    el('div', { class: 'row' }, el('button', { onclick: listModels }, 'List models'), el('button', { onclick: test }, isVision ? 'Test with an image' : 'Test connection'),
      el('button', { onclick: async () => { if (confirm('Delete the stored API key for this model?')) { await call('settings:deleteKey', slot); await refreshSettings(); renderSettings(); toast('API key deleted'); } } }, 'Delete stored key')),
    result);
  const sync = () => {
    cloudBox.classList.toggle('hidden', sel.value === 'local'); localBox.classList.toggle('hidden', sel.value !== 'local');
    geminiNote.classList.toggle('hidden', sel.value !== 'gemini');
    if (sel.value === 'gemini') { baseUrl.value = GEMINI_URL; baseUrl.setAttribute('readonly', ''); } else baseUrl.removeAttribute('readonly');
  };
  sel.addEventListener('change', sync); sync();

  let mode = null;
  const body = el('div', {}, fields);
  const cardKids = [el('h3', { text: title }), el('p', { class: 'muted small', text: intro })];
  if (isVision) {
    mode = el('select', {}, el('option', { value: 'same' }, 'Use the Text model for images too (only if it can read images)'), el('option', { value: 'separate' }, 'Use a separate Vision model for images, screenshots and OCR'));
    mode.value = m.mode === 'separate' ? 'separate' : 'same';
    const msync = () => fields.classList.toggle('hidden', mode.value !== 'separate');
    mode.addEventListener('change', msync); msync();
    cardKids.push(field('Which model reads images?', mode));
  }
  cardKids.push(body);
  return { node: el('div', { class: 'card' }, cardKids), collect: () => ({ ...collect(), ...(mode ? { mode: mode.value } : {}) }), key };
}

function renderSettings() {
  const s = state.s;
  const box = $('#settingsForm');
  const textCard = slotCard('text', 'Text & chat model', 'Answers normal questions, coding, chat and file edits. A lightweight model is fine (for example qwen2.5 in Ollama).', s.models.text);
  const visionCard = slotCard('vision', 'Vision / OCR / screen-capture model', 'Tachyon sends every image (screenshots from the floating button, image attachments, OCR, object detection) to this model automatically, and everything else to the Text model. You never have to switch models yourself. It can run in a different place than the Text model (for example Text on Ollama, Vision on Gemini).', s.models.vision, { isVision: true });

  const timeout = el('input', { type: 'number', value: s.timeoutSec, min: 5, max: 300 });
  const sys = el('textarea', { rows: 3, placeholder: 'Optional extra instructions. Tachyon already answers directly, uses tables/bullets/numbered steps, and never creates files unless you ask.' });
  sys.value = s.systemPrompt;
  const themeSel = el('select', {}, el('option', { value: 'dark' }, 'Dark'), el('option', { value: 'light' }, 'Light'), el('option', { value: 'system' }, 'Follow my system'));
  themeSel.value = s.theme || 'dark';
  const fontSel = el('select', {}, [12, 13, 14, 15, 16, 18, 20].map((n) => el('option', { value: n }, n + ' px' + (n === 14 ? ' (default)' : ''))));
  fontSel.value = String(s.fontSize || 14);
  const preview = () => { state.s.theme = themeSel.value; state.s.fontSize = Number(fontSel.value); applyAppearance(); };
  themeSel.addEventListener('change', preview); fontSel.addEventListener('change', preview);
  const editMode = el('select', {}, el('option', { value: 'apply' }, 'Apply AI edits directly (a .nova-bak backup is always made first)'), el('option', { value: 'review' }, 'Show me the AI’s proposal and let me Save'));
  editMode.value = s.aiEditMode;

  // image generation
  const imgBackend = el('select', {}, el('option', { value: 'none' }, 'Off'), el('option', { value: 'a1111' }, 'Automatic1111 / SD WebUI / Forge / SD.Next (local)'), el('option', { value: 'gemini' }, 'Google Gemini image model (experimental)'), el('option', { value: 'openai' }, 'OpenAI-compatible images API (uses the Text model’s cloud settings)'), el('option', { value: 'invokeai' }, 'InvokeAI (connection check only)'));
  imgBackend.value = s.imageBackend;
  const imgUrl = el('input', { type: 'text', value: s.imageUrl, placeholder: 'http://127.0.0.1:7860' });
  const imgModel = el('input', { type: 'text', value: s.imageModel, placeholder: 'image model identifier' });
  const imgSteps = el('input', { type: 'number', value: s.imageSteps, min: 1, max: 150 });
  const imgW = el('input', { type: 'number', value: s.imageWidth, min: 64, max: 2048, step: 64 });
  const imgH = el('input', { type: 'number', value: s.imageHeight, min: 64, max: 2048, step: 64 });
  const imgNeg = el('input', { type: 'text', value: s.imageNegative, placeholder: 'e.g. blurry, low quality' });
  const imgResult = el('p', { class: 'small' });
  const imgLocal = el('div', {}, field('Server URL', imgUrl, 'Automatic1111 default: http://127.0.0.1:7860 (start it with --api). InvokeAI default: http://127.0.0.1:9090.'),
    field('Steps', imgSteps), field('Width × Height', el('div', { class: 'row' }, imgW, imgH)), field('Negative prompt (optional)', imgNeg));
  const imgModelBox = el('div', {}, field('Image model identifier', imgModel, 'Gemini: copy an image-capable model name from Google AI Studio (it uses the Google key from your Text or Vision model). Free-tier access to image models is limited and changes. OpenAI-compatible: an image model your provider supports.'));
  const imgSync = () => { imgLocal.classList.toggle('hidden', !['a1111', 'invokeai'].includes(imgBackend.value)); imgModelBox.classList.toggle('hidden', !['openai', 'gemini'].includes(imgBackend.value)); };
  imgBackend.addEventListener('change', imgSync); imgSync();

  const save = async () => {
    try {
      const r = await call('settings:save', {
        settings: {
          models: { text: textCard.collect(), vision: visionCard.collect() },
          timeoutSec: timeout.value, systemPrompt: sys.value, aiEditMode: editMode.value, theme: themeSel.value, fontSize: fontSel.value,
          imageBackend: imgBackend.value, imageUrl: imgUrl.value, imageModel: imgModel.value, imageSteps: imgSteps.value, imageWidth: imgW.value, imageHeight: imgH.value, imageNegative: imgNeg.value,
        },
        apiKeys: { text: textCard.key.value, vision: visionCard.key.value },
      });
      textCard.key.value = ''; visionCard.key.value = '';
      await refreshSettings();
      toast('Settings saved.' + (r.persisted ? '' : ' (An API key is kept in memory only — secure storage is unavailable.)'));
      renderSettings();
    } catch (e) { toast('Failed: ' + e.message); }
  };

  const overlayBox = el('input', { type: 'checkbox' });
  overlayBox.checked = s.overlayEnabled;
  overlayBox.addEventListener('change', async () => {
    try { await call('settings:save', { settings: { overlayEnabled: overlayBox.checked } }); state.s.overlayEnabled = overlayBox.checked; toast(overlayBox.checked ? 'Floating button is on.' : 'Floating button is off.'); } catch (e) { toast(e.message); }
  });

  box.replaceChildren(
    el('div', { class: 'row' }, el('button', { class: 'primary', onclick: save }, 'Save settings'), el('span', { class: 'muted small', text: 'Saves both models, the options below and any new keys.' })),
    textCard.node, visionCard.node,
    el('div', { class: 'card' }, el('h3', { text: 'Appearance' }), el('div', { class: 'row' }, field('Theme', themeSel), field('Text size', fontSel)),
      el('p', { class: 'muted small', text: 'Changes preview immediately; press “Save settings” to keep them. The ◐ button in the sidebar switches light/dark at any time.' })),
    el('div', { class: 'card' }, el('h3', { text: 'General' }), field('Request timeout (seconds, 5–300)', timeout), field('Custom instructions (optional)', sys),
      field('When the AI edits a file', editMode, 'Edits only touch text, code, CSV and JSON files inside folders you granted. JSON is validated before it is written.')),
    el('div', { class: 'card' }, el('h3', { text: 'Floating button & screen capture' }),
      el('label', {}, overlayBox, ' Show the floating “T” button at the top-right of my screen (always on top)'),
      el('p', { class: 'muted small', text: 'Click it to capture the whole screen or one window, ask a question, extract text (OCR) or find an error. The screenshot goes to your Vision model only when you press an action; it is hidden while capturing and stored privately in the app data folder (deleted after 14 days). Windows must not be minimized to be captured. With the button on, closing the main window keeps Tachyon running — use the tray icon or the panel to quit. macOS asks for Screen Recording permission the first time; on Linux/Wayland the system asks you to approve sharing.' })),
    el('div', { class: 'card' }, el('h3', { text: 'Image generation (optional, only for /image)' }), field('Backend', imgBackend), imgLocal, imgModelBox,
      el('div', { class: 'row' }, el('button', { onclick: async () => {
        imgResult.textContent = 'Testing…';
        try { imgResult.textContent = 'OK: ' + await call('image:test', { backend: imgBackend.value, url: imgUrl.value, model: imgModel.value, apiKey: '' }); } catch (e) { imgResult.textContent = 'Failed: ' + e.message; }
      } }, 'Test image backend')), imgResult,
      el('p', { class: 'muted small', text: 'Save settings first, then type /image followed by a description in the chat. OCR, screenshots and image analysis never use these settings.' })),
    voiceCard(), remindersCard(), skillsCard(),
    permissionsCard(), memoryCard(), activityCard(),
    el('div', { class: 'card' }, el('h3', { text: 'Privacy' }),
      el('p', { class: 'small', text: 'Conversations are stored on this computer only. With a cloud model, your messages — and the text of files or images you attach, analyze or let the AI edit — are sent over HTTPS to the URL you configured; each key is sent only to its own model’s URL. With Ollama, the same content goes to the host you entered (unencrypted http on your network). Local image servers receive only your prompt. Speech is recognized on this computer and never sent anywhere; speech models are downloaded only when you press Download. Tachyon never deletes files (Undo moves new files to its own undo folder), never uploads files on its own, never creates a file unless you ask, and always makes a .nova-bak backup before changing a file.' }),
      el('div', { class: 'row' }, el('button', { onclick: async () => { if (confirm('Delete ALL chat history?')) { await call('conv:clear'); newChat(); toast('History cleared'); } } }, 'Clear all chat history'))),
    el('div', { class: 'card' }, el('h3', { text: 'About' }), el('p', { class: 'small', text: `Tachyon ${state.version} (formerly NOVA AI). Settings, chats and keys from NOVA AI are copied over automatically on the first start.` })));
}

// ---------------------------------------------------------------- chat commands: reminders, apps, windows, search, tasks, skills
const HELP = `Here is what I can do besides answering questions:

| Say or type | What happens |
|---|---|
| **summarize C:\\Docs\\report.pdf**, **fix notes.txt** | Opens the file you name and works on it (you are asked first if it is outside your folders) |
| **save it to my desktop**, **auto-save answers to D:\\Notes** | Saves the answer there, no dialog |
| **remind me in 20 minutes to stretch**, **remind me tomorrow at 9am to pay rent** | Sets a reminder (desktop notification) |
| **show my reminders**, **cancel the reminder about rent** | Lists or cancels reminders |
| **open Notepad**, **launch Spotify** | Opens an installed app (shells and system tools are blocked) |
| **Open VS Code**, **open my project in VS Code**, **open File Explorer**, **go to example.com** | Starts the app and checks that it opened; you see every step in Task History |
| **git status**, **git log**, **run the tests**, **python version** | Fixed, safe commands in your project folder (tests always ask first) |
| **/do open my project in VS Code** | Your local model picks one allowed action; nothing runs until you approve |
| PowerShell / Windows Terminal | Only from their button in **Applications** (never from chat or the AI) |
| **switch to Chrome**, **minimize Word**, **show desktop**, **list open windows** | Window control (Windows) |
| **find files named budget**, **find files containing invoice 2024** | Searches your granted folders |
| **/task find my CV, convert it to PDF and copy it to my desktop** | Plans several steps, shows them to you, runs them on Run, and can Undo them |
| **create a skill that …**, **/skills**, **/yourcommand text** | Teaches me a new ability (you review and test it before installing) |
| **remember that …**, **what do you remember about me**, **forget …** | Personal memory, kept on this computer |
| **/image a red fox in snow** | Draws a picture (needs an image backend) |
| Microphone button or **“Hey Tachyon”** | Talk instead of typing (offline speech, Settings → Voice) |

Everything is checked against Settings → Permissions and recorded in the activity log.`;

const KNOWN_FOLDER_NAMES = /^(?:my\s+)?(?:desktop|documents|downloads|pictures|music|videos|home)(?:\s+folder)?$/i;
const when = (ms) => {
  const d = new Date(ms);
  const today = new Date();
  const tomorrow = new Date(); tomorrow.setDate(today.getDate() + 1);
  const t = d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  if (d.toDateString() === today.toDateString()) return 'today at ' + t;
  if (d.toDateString() === tomorrow.toDateString()) return 'tomorrow at ' + t;
  return d.toLocaleDateString([], { weekday: 'long', month: 'short', day: 'numeric' }) + ' at ' + t;
};

/** Handles commands that need no AI model. Returns true when the message was handled here. */
async function handleCommand(text) {
  const C = window.TachyonCommands;
  if (/^\/help$|^what can you do\??$/i.test(text)) { localExchange(text, HELP); return true; }
  if (/^\/do(\s|$)/i.test(text) && window.TachyonAgent) return window.TachyonAgent.handleChat(text);
  const skillReq = C.parseSkillRequest(text);
  if (skillReq) { await draftSkill(text, skillReq); return true; }
  if (/^\/skills$/i.test(text)) { await listSkillsInChat(text); return true; }
  if (/^\/task\b/i.test(text) || (configured() && C.isTaskRequest(text))) { await planTask(text); return true; }
  const sc = C.parseSkillCall(text);
  if (sc && sc.command !== 'image') { await runSkillCommand(text, sc); return true; }
  if (/^(?:please\s+)?(?:show|list|what\s+are)\s+(?:me\s+)?(?:all\s+)?(?:my\s+)?(?:upcoming\s+)?reminders\??$/i.test(text)) {
    const list = await call('reminders:list').catch(() => []);
    localExchange(text, list.length ? 'Your reminders:\n\n' + list.map((r) => `- **${r.text}**, ${when(r.at)}`).join('\n') + '\n\nSay “cancel the reminder about …” to remove one.' : 'You have no reminders. Say “remind me in 10 minutes to …”.');
    return true;
  }
  const cancel = /^(?:please\s+)?(?:cancel|delete|remove|clear)\s+(?:the\s+|my\s+)?(all\s+(?:my\s+)?)?reminders?(?:\s+(?:about|for|to|called))?\s*(.*)$/i.exec(text.replace(/[.!]+$/, ''));
  if (cancel) {
    const list = await call('reminders:list').catch(() => []);
    const q = cancel[2].trim().toLowerCase();
    const hits = cancel[1] ? list : list.filter((r) => q && r.text.toLowerCase().includes(q));
    const pick = hits.length ? hits : list.length === 1 && !q ? list : [];
    for (const r of pick) await call('reminders:delete', r.id).catch(() => {});
    localExchange(text, pick.length ? 'Cancelled:\n' + pick.map((r) => `- ${r.text} (${when(r.at)})`).join('\n') : q ? `I found no reminder about “${cancel[2].trim()}”.` : 'Which reminder? Say “cancel the reminder about …”.');
    return true;
  }
  const rem = C.parseReminder(text);
  if (rem) {
    if (!rem.at) { localExchange(text, `When should I remind you to “${rem.text}”? Try “remind me to ${rem.text.charAt(0).toLowerCase() + rem.text.slice(1)} at 5pm” or “… in 30 minutes”.`); return true; }
    try {
      const r = await call('reminders:add', { text: rem.text, at: rem.at });
      localExchange(text, `Okay, I’ll remind you **${when(r.at)}**: ${r.text}. Keep Tachyon running (it can stay in the tray) so the reminder can appear.`);
    } catch (e) { localExchange(text, 'Could not set the reminder: ' + e.message); }
    return true;
  }
  // Actions on this computer through connectors: “Open VS Code”, “git status”, “run the tests”, “go to example.com” …
  if (window.TachyonAgent && await window.TachyonAgent.handleChat(text)) return true;
  const cc = C.parseComputerCommand(text);
  if (cc) return runComputerCommand(text, cc);
  return false;
}

async function runComputerCommand(text, cc) {
  if (cc.kind === 'app') {
    if (KNOWN_FOLDER_NAMES.test(cc.name)) return false; // "open my downloads" is a folder, handled with files
    try {
      const r = await call('apps:open', cc.name);
      localExchange(text, `Opened **${r.name}**.`);
    } catch (e) {
      // "start a new story…" or "run the numbers…" are questions for the AI, not apps
      if (/could not find an app/i.test(e.message) && !/^\s*(?:please\s+|can\s+you\s+|could\s+you\s+)?(?:open|launch)\b/i.test(text)) return false;
      localExchange(text, e.message);
    }
    return true;
  }
  if (cc.kind === 'window') {
    try {
      const r = await call('windows:action', { action: cc.action, target: cc.target });
      if (cc.action === 'list') localExchange(text, r.length ? '| App | Window |\n|---|---|\n' + r.map((w) => `| ${w.app} | ${w.title.replace(/\|/g, '/')} |`).join('\n') : 'No open windows found.');
      else localExchange(text, { focus: 'Switched to', minimize: 'Minimized', maximize: 'Maximized', restore: 'Restored' }[cc.action] ? `${{ focus: 'Switched to', minimize: 'Minimized', maximize: 'Maximized', restore: 'Restored' }[cc.action]} **${r || cc.target}**.` : cc.action === 'minimizeAll' ? 'Showing the desktop.' : 'Restored all windows.');
    } catch (e) { localExchange(text, e.message); }
    return true;
  }
  if (cc.kind === 'search') {
    if (!state.s || !state.s.folders.length) { localExchange(text, 'Add a folder in **Files & PDFs** first so I know where to search (or name the file with its full path).'); return true; }
    state.conv.messages.push({ role: 'user', content: text, note: true, ts: Date.now() });
    $('#input').value = ''; autoGrow();
    state.busy = true; renderMessages();
    try {
      const hits = cc.mode === 'name' ? await call('fs:findName', { q: cc.query, kind: cc.fileKind }) : (await call('fs:findInside', { q: cc.query })).items;
      state.conv.messages.push({ role: 'assistant', note: true, ts: Date.now(), files: hits.slice(0, 50).map((h) => ({ path: h.path, name: h.name, snippet: h.snippet })),
        content: hits.length ? `Found ${hits.length}${hits.length >= 300 ? '+' : ''} file(s) ${cc.mode === 'name' ? 'named' : 'containing'} “${cc.query}”${hits.length > 50 ? ' (showing 50)' : ''}. Click one to attach it, then ask about it.` : `No files ${cc.mode === 'name' ? 'named' : 'containing'} “${cc.query}” in your folders.` });
    } catch (e) { state.conv.messages.push({ role: 'assistant', content: e.message, note: true, ts: Date.now() }); }
    state.busy = false; renderMessages(); saveConv();
    return true;
  }
  return false;
}

function fileHits(files) {
  return el('div', { class: 'file-hits' }, files.map((f) => el('div', { class: 'hit' },
    el('div', { class: 'name' }, el('b', { text: f.name }), el('span', { class: 'muted small', text: f.path }), f.snippet ? el('span', { class: 'small', text: '…' + f.snippet + '…' }) : null),
    el('button', { title: 'Attach to the chat', onclick: () => { addAttachment(f); renderAttachments(); $('#input').focus(); toast('Attached ' + f.name); } }, IC('paperclip'), ' Attach'),
    el('button', { onclick: () => call('files:open', f.path).catch((e) => toast(e.message)) }, 'Open'),
    el('button', { onclick: () => call('fs:reveal', f.path).catch((e) => toast(e.message)) }, 'Show'))));
}

function onReminderDue(r) {
  toast('Reminder: ' + r.text, 20000);
  if (state.s && (state.s.voiceAutoRead || state.s.voiceModel)) window.TachyonVoice.speakText('Reminder: ' + r.text, { voiceName: state.s.voiceName, rate: state.s.voiceRate });
  if ($('#view-settings').classList.contains('active')) renderSettings();
}

// ---- multi-step tasks
async function busyStep(text, fn) {
  state.conv.messages.push({ role: 'user', content: text, note: true, ts: Date.now() });
  $('#input').value = ''; autoGrow();
  state.busy = true; renderMessages();
  try { await fn(); } catch (e) { state.conv.messages.push({ role: 'assistant', content: e.message, note: true, error: true, ts: Date.now() }); }
  state.busy = false; renderMessages(); saveConv();
}
async function planTask(text) {
  if (!configured()) { toast('Set up a Text model in Settings first: it plans the steps.'); showView('settings'); return; }
  await busyStep(text, async () => {
    const plan = await call('task:plan', { text });
    state.conv.messages.push({ role: 'assistant', note: true, ts: Date.now(), content: 'Plan: ' + plan.title, task: { plan, status: 'planned', progress: {} } });
  });
}
const taskMsg = (id) => state.conv.messages.find((m) => m.task && m.task.plan.id === id);
function onTaskProgress(p) {
  const m = taskMsg(p.id);
  if (!m) return;
  m.task.progress[p.index] = p;
  renderMessages();
}
async function runTask(first) {
  const id = first.task.plan.id;
  first.task.status = 'running';
  renderMessages();
  let m = first;
  try {
    const r = await call('task:run', { id });
    m = taskMsg(id) || first; // the chat may have been reloaded from disk while the task ran
    m.task.status = 'running';
    m.task.result = r;
    m.task.status = r.stopped == null ? 'done' : 'stopped';
    r.steps.forEach((st) => { m.task.progress[st.index] = { status: st.ok ? 'done' : 'failed', summary: st.summary, error: st.error, path: st.path, text: st.text }; });
    m.content = (r.stopped == null ? 'Done: ' : 'Stopped: ') + m.task.plan.title;
    const out = [...r.steps].reverse().find((st) => st.ok && st.text && st.tool === 'ai_write');
    if (out && r.stopped == null) state.conv.messages.push({ role: 'assistant', content: out.text, ts: Date.now() }); // so “save it to …” works on it
  } catch (e) { m = taskMsg(id) || first; m.task.status = 'stopped'; m.task.error = e.message; }
  renderMessages(); saveConv();
}
async function undoTask(first) {
  const id = first.task.plan.id;
  try {
    const r = await call('task:undo', { id });
    const m = taskMsg(id) || first;
    m.task.undone = true;
    m.task.undoNote = (r.done.length ? 'Undone: ' + r.done.join('; ') : 'Nothing needed undoing.') + (r.failed.length ? ' Could not undo: ' + r.failed.join('; ') : '');
    toast(m.task.undoNote, 8000);
  } catch (e) { toast(e.message); }
  renderMessages(); saveConv();
}
function argText(a) {
  return Object.entries(a).map(([k, v]) => `${k}: ${String(v).length > 120 ? String(v).slice(0, 120) + '…' : v}`).join(' · ');
}
function taskCard(m) {
  const t = m.task;
  const icon = (i) => IC({ running: 'loader', done: 'check-circle', failed: 'x-circle' }[(t.progress[i] || {}).status] || 'circle-dot', 15);
  const steps = el('ol', { class: 'task-steps' }, t.plan.steps.map((st, i) => {
    const p = t.progress[i] || {};
    return el('li', { class: 'task-step ' + (p.status || '') },
      el('span', { class: 'st' }, icon(i)),
      el('div', {}, el('b', { text: st.label }), el('div', { class: 'muted small', text: argText(st.args) }), st.why ? el('div', { class: 'small', text: st.why }) : null,
        p.summary ? el('div', { class: 'small ok', text: '→ ' + p.summary }) : null, p.error ? el('div', { class: 'small bad', text: '→ ' + p.error }) : null,
        p.text ? el('details', {}, el('summary', { text: 'Show result' }), el('pre', {}, el('code', { text: p.text }))) : null,
        p.path ? el('button', { class: 'small-btn', onclick: () => call('fs:reveal', p.path).catch((e) => toast(e.message)) }, IC('folder-open'), ' Show') : null));
  }));
  const actions = el('div', { class: 'msg-actions' });
  if (t.status === 'planned') {
    actions.append(el('button', { class: 'primary', onclick: () => runTask(m) }, '▶ Run these steps'),
      el('button', { onclick: () => { t.status = 'cancelled'; m.content = 'Cancelled: ' + t.plan.title; renderMessages(); saveConv(); } }, 'Cancel'));
  } else if (t.status === 'running') actions.append(el('span', { class: 'muted small', text: 'Running… each step follows your permission settings.' }));
  else if (t.status === 'cancelled') actions.append(el('span', { class: 'muted small', text: 'Cancelled. Nothing was done.' }));
  else if (t.result && t.result.canUndo && !t.undone) actions.append(el('button', { onclick: () => undoTask(m) }, IC('undo'), ' Undo this task'));
  if (t.undoNote) actions.append(el('span', { class: 'muted small', text: t.undoNote }));
  if (t.error) actions.append(el('span', { class: 'small bad', text: t.error }));
  return el('div', { class: 'task-card' }, el('div', { class: 'task-title' }, el('b', {}, IC('sparkles'), ' ' + t.plan.title), el('span', { class: 'muted small', text: `${t.plan.steps.length} step(s)` })),
    t.plan.note ? el('p', { class: 'small muted', text: t.plan.note }) : null, steps, actions);
}

// ---- skills
async function draftSkill(text, request) {
  if (!configured()) { toast('Set up a Text model in Settings first: it writes the skill.'); showView('settings'); return; }
  await busyStep(text, async () => {
    const r = await call('skills:draft', { request });
    state.conv.messages.push({ role: 'assistant', note: true, ts: Date.now(), content: `New skill: ${r.skill.name} (/${r.skill.command})`, skillDraft: { ...r, status: 'draft' } });
  });
}
function skillCard(m) {
  const d = m.skillDraft;
  const s = d.skill;
  const codeFailed = s.kind === 'code' && d.tests.some((t) => !t.ok);
  const actions = el('div', { class: 'msg-actions' });
  if (d.status === 'draft') {
    actions.append(
      el('button', { class: 'primary', disabled: codeFailed, title: codeFailed ? 'A code skill can only be installed when all its tests pass' : 'Install this skill', onclick: async () => {
        try {
          const sk = await call('skills:install', { draftId: d.draftId });
          const cur = (state.conv.messages.find((x) => x.skillDraft && x.skillDraft.draftId === d.draftId) || m).skillDraft;
          cur.status = 'installed'; cur.version = sk.version; toast(`Installed /${sk.command}`);
        } catch (e) { toast(e.message); }
        renderMessages(); saveConv();
      } }, d.replaces ? `Install as version ${d.replaces.version + 1}` : 'Install skill'),
      el('button', { onclick: () => { d.status = 'discarded'; renderMessages(); saveConv(); } }, 'Discard'));
  } else actions.append(el('span', { class: 'muted small', text: d.status === 'installed' ? `Installed. Use it like this: /${s.command} your text. Manage it in Settings → Skills.` : 'Discarded. Nothing was installed.' }));
  return el('div', { class: 'task-card skill-card' },
    el('div', { class: 'task-title' }, el('b', {}, IC('package'), ` ${s.name}  ·  /${s.command}`), el('span', { class: 'muted small', text: s.kind === 'code' ? 'code skill (runs in a locked sandbox)' : 'prompt skill (uses your Text model)' })),
    s.description ? el('p', { class: 'small', text: s.description }) : null,
    d.replaces ? el('p', { class: 'small muted', text: `Replaces “${d.replaces.name}” version ${d.replaces.version}; the old version is kept and can be restored.` }) : null,
    el('details', { open: s.kind === 'code' }, el('summary', { text: s.kind === 'code' ? 'Code' : 'Instructions' }), el('pre', {}, el('code', { text: s.kind === 'code' ? s.code : s.prompt }))),
    d.tests.length ? el('div', { class: 'skill-tests' }, el('b', { class: 'small', text: 'Tests' }), d.tests.map((t) => el('div', { class: 'small ' + (t.ok ? 'ok' : 'bad') },
      `${t.ok ? 'Pass' : 'Fail'}: input “${t.input.slice(0, 80)}”${t.expect ? ` should contain “${t.expect}”` : ''} → ${t.error ? 'error: ' + t.error : '“' + t.output.slice(0, 160) + '”'}`))) : null,
    actions);
}
async function listSkillsInChat(text) {
  const list = await call('skills:list').catch(() => []);
  localExchange(text, list.length ? '| Command | Skill | Type | Version | On |\n|---|---|---|---|---|\n' + list.map((s) => `| /${s.command} | ${s.name} | ${s.kind} | ${s.version} | ${s.enabled ? 'yes' : 'no'} |`).join('\n') + '\n\nUse one with “/command your text”. Manage them in Settings → Skills.' : 'No skills yet. Say “create a skill that …” to teach me one.');
}
async function runSkillCommand(text, sc) {
  const list = await call('skills:list').catch(() => []);
  const skill = list.find((s) => s.command === sc.command);
  if (!skill) { localExchange(text, `I don’t know /${sc.command}. Type /help for commands or /skills for your skills.`); return; }
  if (!sc.input) { toast(`Add some text after the command, e.g. /${sc.command} your text`); return; }
  state.conv.messages.push({ role: 'user', content: text, ts: Date.now() });
  $('#input').value = ''; autoGrow();
  state.busy = true; renderMessages();
  try {
    const r = await call('skills:run', { command: sc.command, input: sc.input });
    const msg = { role: 'assistant', content: r.text, ts: Date.now(), skill: skill.command };
    state.conv.messages.push(msg);
    if (state.voiceTurn || (state.s && state.s.voiceAutoRead)) setTimeout(() => speak(msg), 50);
  } catch (e) { state.conv.messages.push({ role: 'assistant', content: e.message, error: true, ts: Date.now() }); }
  state.busy = false; state.voiceTurn = false; renderMessages(); saveConv();
}

// ---- voice: push-to-talk (microphone button), “Hey Tachyon”, replies read aloud
const voiceModelInfo = async () => {
  const id = state.s && state.s.voiceModel;
  if (!id) return null;
  const list = await call('voice:models').catch(() => []);
  return list.find((x) => x.id === id && x.installed) || null;
};
function setMicState(st) {
  state.listening = st;
  const b = $('#micBtn');
  if (!b) return;
  b.classList.toggle('live', st === 'listening');
  b.classList.toggle('wake', st === 'wake');
  b.title = st === 'listening' ? 'Listening… click to stop' : st === 'wake' ? 'Waiting for “Hey Tachyon”. Click to talk now.' : 'Talk to Tachyon (Ctrl+M)';
}
async function toggleMic() {
  const V = window.TachyonVoice;
  if (state.listening === 'listening') { V.stop(); setMicState('off'); resumeWake(); return; }
  const info = await voiceModelInfo();
  if (!info) { toast('Choose a speech model in Settings → Voice first (it works offline once downloaded).'); showView('settings'); return; }
  try {
    await V.startDictation(info, {
      onPartial: (t) => { $('#input').value = t; autoGrow(); },
      onFinal: (t) => { setMicState('off'); if (t.trim()) { $('#input').value = t; state.voiceTurn = true; send(); } else resumeWake(); },
      onState: (st) => setMicState(st === 'listening' ? 'listening' : 'off'),
      onError: (e) => { toast(e.message); setMicState('off'); },
    });
  } catch (e) { setMicState('off'); toast(/Permission|NotAllowed|NotFound/i.test(String(e.name || e.message)) ? 'No microphone is available or access was refused.' : e.message); }
}
async function resumeWake() {
  if (!state.s || !state.s.voiceWake || state.listening === 'listening' || state.busy) return;
  const info = await voiceModelInfo();
  if (!info) return;
  try {
    await window.TachyonVoice.startWake(info, state.s.voiceWakeWord || '', {
      onWake: () => { window.TachyonVoice.stop({ keepMic: true }); toggleMic(); },
      onState: (st) => setMicState(st === 'wake' ? 'wake' : 'off'),
      onError: () => setMicState('off'),
    });
  } catch { setMicState('off'); }
}
function onVoiceProgress(p) {
  const n = $('#voiceStatus');
  if (n) n.textContent = p.phase === 'download' ? `Downloading ${p.id}… ${p.pct}%` : p.phase === 'convert' ? `Preparing ${p.id}…` : `${p.id} is ready.`;
}
if ($('#micBtn')) $('#micBtn').addEventListener('click', toggleMic);
window.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && !e.altKey && e.key.toLowerCase() === 'm') { e.preventDefault(); toggleMic(); } });

// ---------------------------------------------------------------- settings: voice, reminders, skills
function voiceCard() {
  const s = state.s;
  const status = el('p', { id: 'voiceStatus', class: 'small muted' });
  const list = el('div', { class: 'list' });
  const wake = el('input', { type: 'checkbox' }); wake.checked = Boolean(s.voiceWake);
  const auto = el('input', { type: 'checkbox' }); auto.checked = Boolean(s.voiceAutoRead);
  const voiceSel = el('select', {});
  const wakeWord = el('input', { type: 'text', value: s.voiceWakeWord || '', placeholder: 'Hey Tachyon' });
  wakeWord.addEventListener('change', async () => { await saveV({ voiceWakeWord: wakeWord.value.trim() }); if (state.listening === 'wake') { window.TachyonVoice.stop(); resumeWake(); } });
  const rate = el('select', {}, [0.8, 0.9, 1, 1.1, 1.25, 1.5].map((r) => el('option', { value: r }, r + '×')));
  rate.value = String(s.voiceRate || 1);
  const fillVoices = () => {
    const vs = window.TachyonVoice.voices();
    voiceSel.replaceChildren(el('option', { value: '' }, 'System default voice'), ...vs.map((v) => el('option', { value: v.name }, `${v.name} (${v.lang})${v.localService ? '' : ' · online'}`)));
    voiceSel.value = s.voiceName || '';
  };
  fillVoices();
  if (window.speechSynthesis) speechSynthesis.onvoiceschanged = fillVoices;
  const saveV = async (patch) => { try { await call('settings:save', { settings: patch }); Object.assign(state.s, patch); } catch (e) { toast(e.message); } };
  wake.addEventListener('change', async () => { await saveV({ voiceWake: wake.checked }); if (wake.checked) resumeWake(); else if (state.listening === 'wake') { window.TachyonVoice.stop(); setMicState('off'); } });
  auto.addEventListener('change', () => saveV({ voiceAutoRead: auto.checked }));
  voiceSel.addEventListener('change', () => saveV({ voiceName: voiceSel.value }));
  rate.addEventListener('change', () => saveV({ voiceRate: Number(rate.value) }));
  const load = async () => {
    const models = await call('voice:models').catch(() => []);
    list.replaceChildren(...models.map((m) => el('div', { class: 'item' },
      el('div', { class: 'name' }, el('b', { text: (s.voiceModel === m.id ? '● ' : '') + m.label }), el('span', { text: m.installed ? 'On this computer' + (s.voiceModel === m.id ? ' · in use' : '') : `Download about ${m.sizeMb} MB once, then works offline` })),
      m.installed ? el('button', { disabled: s.voiceModel === m.id, onclick: async () => { await saveV({ voiceModel: m.id }); renderSettings(); toast(`Using ${m.label} for speech.`); } }, 'Use') : null,
      m.installed ? el('button', { onclick: async () => { if (!confirm(`Remove the ${m.label} speech model?`)) return; await call('voice:deleteModel', m.id); if (s.voiceModel === m.id) await saveV({ voiceModel: '' }); load(); } }, 'Remove')
        : el('button', { onclick: async (e) => { e.target.disabled = true; try { await call('voice:download', m.id); if (!s.voiceModel) await saveV({ voiceModel: m.id }); renderSettings(); } catch (err) { status.textContent = 'Failed: ' + err.message; e.target.disabled = false; } } }, 'Download'))));
  };
  load();
  return el('div', { class: 'card' }, el('h3', { text: 'Voice' }),
    el('p', { class: 'muted small', text: 'Talk to Tachyon with the microphone button (or Ctrl+M, or Ctrl+Shift+Space from anywhere). Speech is recognized on this computer with an offline Vosk model: no audio is ever sent anywhere. Download a model once, or import a Vosk model .zip you already have. Answers to spoken questions are read aloud with your system voices (Windows voices work offline).' }),
    list, el('div', { class: 'row' }, el('button', { onclick: async () => { try { const r = await call('voice:importModel'); if (r) { if (!s.voiceModel) await saveV({ voiceModel: r.id }); renderSettings(); } } catch (e) { status.textContent = 'Failed: ' + e.message; } } }, 'Import model file…')), status,
    el('label', {}, wake, ' Listen for “Hey Tachyon” while Tachyon is open (the microphone stays on, everything stays on this computer)'),
    field('Wake phrase (optional)', wakeWord, 'Leave empty for “Hey Tachyon”. A phrase made of common words (for example “hey computer”) is recognized more reliably by small models.'),
    el('label', {}, auto, ' Read every answer aloud (spoken questions are always answered aloud)'),
    el('div', { class: 'row' }, field('Voice', voiceSel), field('Speed', rate)),
    el('div', { class: 'row' }, el('button', { onclick: () => window.TachyonVoice.speakText('Hello, I am Tachyon. How can I help you today?', { voiceName: voiceSel.value, rate: Number(rate.value) }) }, IC('volume'), ' Test voice')));
}

function remindersCard() {
  const list = el('div', { class: 'list' });
  const load = async () => {
    const items = await call('reminders:list').catch(() => []);
    list.replaceChildren(...(items.length ? items.map((r) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: r.text }), el('span', { text: when(r.at) })),
      el('button', { onclick: async () => { await call('reminders:delete', r.id); load(); } }, 'Cancel'))) : [el('div', { class: 'item muted', text: 'No reminders. In the chat say “remind me in 20 minutes to …”.' })]));
  };
  load();
  return el('div', { class: 'card' }, el('h3', { text: 'Reminders' }),
    el('p', { class: 'muted small', text: 'Reminders appear as desktop notifications while Tachyon runs (also from the tray). Ones missed while it was closed appear when it starts.' }), list);
}

function skillsCard() {
  const list = el('div', { class: 'list' });
  const load = async () => {
    const items = await call('skills:list').catch(() => []);
    list.replaceChildren(...(items.length ? items.map((sk) => {
      const on = el('input', { type: 'checkbox' }); on.checked = sk.enabled;
      on.addEventListener('change', async () => { await call('skills:toggle', { id: sk.id, enabled: on.checked }).catch((e) => toast(e.message)); });
      return el('div', { class: 'item' },
        el('div', { class: 'name' }, el('b', { text: `/${sk.command}  ·  ${sk.name}` }), el('span', { text: `${sk.kind === 'code' ? 'Code (sandboxed)' : 'Prompt'} · version ${sk.version}${sk.description ? ' · ' + sk.description : ''}` })),
        el('label', { class: 'small' }, on, ' On'),
        sk.history && sk.history.length ? el('button', { title: 'Go back to the previous version', onclick: async () => { try { const r = await call('skills:rollback', sk.id); toast(`/${r.command} is back to version ${r.version}.`); load(); } catch (e) { toast(e.message); } } }, IC('undo'), ' Roll back') : null,
        el('button', { onclick: async () => { if (confirm(`Delete the skill /${sk.command}?`)) { await call('skills:delete', sk.id); load(); } } }, 'Delete'));
    }) : [el('div', { class: 'item muted', text: 'No skills yet. In the chat say “create a skill that …”.' })]));
  };
  load();
  return el('div', { class: 'card' }, el('h3', { text: 'Skills' }),
    el('p', { class: 'muted small', text: 'Skills are abilities you teach Tachyon. You see each one and its test results before installing it; Tachyon never changes itself. Code skills run in a locked sandbox with no file or network access and a 5-second limit. Every update keeps the old version for roll back.' }), list);
}

// ---------------------------------------------------------------- settings: permissions, memory, activity log
function permissionsCard() {
  const body = el('div', { class: 'perm-list' }, el('p', { class: 'muted small', text: 'Loading…' }));
  call('perms:get').then(({ categories, effective }) => {
    body.replaceChildren(...Object.entries(categories).map(([key, c]) => {
      const sel = el('select', { 'aria-label': c.label }, ...(c.noAllow ? [] : [el('option', { value: 'allow' }, 'Allow')]), el('option', { value: 'ask' }, 'Ask me every time'), el('option', { value: 'deny' }, 'Never'));
      sel.value = effective[key];
      sel.addEventListener('change', async () => {
        try { await call('settings:save', { settings: { permissions: { [key]: sel.value } } }); await refreshSettings(); toast('Permission saved.'); } catch (e) { toast(e.message); }
      });
      return el('div', { class: 'perm-row' }, el('span', { text: c.label }), sel);
    }));
  }).catch((e) => body.replaceChildren(el('p', { class: 'small', text: e.message })));
  return el('div', { class: 'card' }, el('h3', { text: 'Permissions' }),
    el('p', { class: 'muted small', text: 'Choose what Tachyon may do on its own. “Ask me every time” shows a confirmation first; “Never” blocks it. Deleting files and sending anything outside this computer always ask. Every action is recorded in the activity log below.' }), body);
}

function memoryCard() {
  const list = el('div', { class: 'list' });
  const on = el('input', { type: 'checkbox' });
  on.checked = state.s.memoryEnabled !== false;
  on.addEventListener('change', async () => { try { await call('settings:save', { settings: { memoryEnabled: on.checked } }); state.s.memoryEnabled = on.checked; toast(on.checked ? 'Memory is on.' : 'Memory is off.'); } catch (e) { toast(e.message); } });
  const input = el('input', { type: 'text', placeholder: 'Add something, e.g. “I am a student” or “I prefer short answers”' });
  const load = async () => {
    const items = await call('memory:list').catch(() => []);
    list.replaceChildren(...(items.length ? items.map((m) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: m.text }), el('span', { text: 'Added ' + new Date(m.createdAt).toLocaleString() })),
      el('button', { title: 'Delete', onclick: async () => { await call('memory:delete', m.id); load(); } }, 'Delete'))) : [el('div', { class: 'item muted', text: 'Nothing yet. In the chat say “remember that …”.' })]));
  };
  const add = async () => { if (!input.value.trim()) return; try { await call('memory:add', input.value); input.value = ''; load(); } catch (e) { toast(e.message); } };
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
  load();
  return el('div', { class: 'card' }, el('h3', { text: 'Memory' }),
    el('p', { class: 'muted small', text: 'Facts you ask Tachyon to remember are stored only on this computer and added to every request so answers fit you. With a cloud model they are sent with your messages. Say “remember that …”, “forget …” or “what do you remember about me”.' }),
    el('label', {}, on, ' Use my memory in answers'),
    el('div', { class: 'row' }, input, el('button', { onclick: add }, 'Add')), list,
    el('div', { class: 'row' }, el('button', { onclick: async () => { if (confirm('Delete everything Tachyon remembers about you?')) { await call('memory:clear'); load(); } } }, 'Delete all memories')));
}

function activityCard() {
  const list = el('div', { class: 'list activity' });
  const filter = el('select', {}, el('option', { value: '' }, 'All activity'), ...['files.read', 'files.edit', 'files.create', 'files.move', 'files.open', 'apps.open', 'windows', 'reminders', 'tasks', 'skills', 'voice', 'local', 'cloud', 'memory', 'settings', 'history']
    .map((c) => el('option', { value: c }, c)));
  const show = async () => {
    const rows = await call('audit:list', { limit: 300, category: filter.value || null }).catch(() => []);
    list.replaceChildren(...(rows.length ? rows.map((r) => el('div', { class: 'item' + (r.ok ? '' : ' bad') },
      el('div', { class: 'name' }, el('b', { text: `${r.ok ? 'OK' : 'Failed'}: ${r.action}  ·  ${r.category}` }), el('span', { text: `${new Date(r.ts).toLocaleString()}  ·  ${r.target || ''}${r.detail ? '  ·  ' + r.detail : ''}` }))))
      : [el('div', { class: 'item muted', text: 'No activity recorded yet.' })]));
  };
  filter.addEventListener('change', show);
  return el('div', { class: 'card' }, el('h3', { text: 'Activity log' }),
    el('p', { class: 'muted small', text: 'Every file read, change, new file, move, open, app launch, task step, skill run and AI request (local or cloud) is recorded here, on this computer only.' }),
    el('div', { class: 'row' }, filter, el('button', { onclick: show }, 'Show / refresh'), el('button', { onclick: async () => { if (confirm('Clear the activity log?')) { await call('audit:clear'); show(); } } }, 'Clear log')), list);
}

// ---------------------------------------------------------------- start
(async function init() {
  try { await refreshSettings(); } catch (e) { toast('Could not load settings: ' + e.message); }
  if (window.nova.onOpenConversation) window.nova.onOpenConversation((id) => { openConv(id).then(() => loadConvList()); });
  if (window.nova.onReminder) window.nova.onReminder(onReminderDue);
  if (window.nova.onTaskProgress) window.nova.onTaskProgress(onTaskProgress);
  if (window.nova.onVoiceProgress) window.nova.onVoiceProgress(onVoiceProgress);
  if (window.nova.onVoiceStart) window.nova.onVoiceStart(() => { showView('chat'); if (state.listening !== 'listening') toggleMic(); });
  resumeWake();
  renderMessages();
  renderAttachments();
  loadConvList();
})();
