(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TachyonCommands = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Chat commands Tachyon understands without asking the AI model: reminders, opening apps, windows, file search,
  // multi-step tasks and skills. Shared by the window (to decide what to do) and the main process (to do it).

  const DAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const UNIT_MS = { second: 1e3, sec: 1e3, minute: 6e4, min: 6e4, hour: 36e5, hr: 36e5, day: 864e5, week: 6048e5 };
  const WORDNUM = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, ten: 10, fifteen: 15, twenty: 20, thirty: 30, 'half an': 0.5 };

  /** Parses "5pm", "5:30 pm", "17:45", "9" -> {h, m} or null. */
  function parseClock(s) {
    const m = /^(\d{1,2})(?::|\.)?(\d{2})?\s*(am|pm|a\.m\.|p\.m\.)?$/i.exec(String(s).trim());
    if (!m) return null;
    let h = Number(m[1]);
    const min = m[2] ? Number(m[2]) : 0;
    const ap = m[3] ? m[3][0].toLowerCase() : null;
    if (h > 23 || min > 59) return null;
    if (ap === 'p' && h < 12) h += 12;
    if (ap === 'a' && h === 12) h = 0;
    return { h, m: min, explicit: Boolean(ap) || h > 12 || Boolean(m[2]) };
  }

  /**
   * Parses a reminder request. Returns null if it is not one, { text, at } when understood,
   * or { text, at: null, needTime: true } when the time is missing.
   */
  function parseReminder(input, now = new Date()) {
    const t = String(input || '').trim().replace(/[.!]+$/, '');
    const head = /^(?:please\s+|can\s+you\s+|could\s+you\s+)?(?:remind\s+me|set\s+(?:a\s+)?reminder|create\s+(?:a\s+)?reminder|reminder)\b[:,]?\s*/i.exec(t);
    if (!head) return null;
    let rest = t.slice(head[0].length);
    let at = null;
    const take = (re, fn) => {
      const m = re.exec(rest);
      if (!m) return false;
      const r = fn(m);
      if (r === false) return false;
      rest = (rest.slice(0, m.index) + ' ' + rest.slice(m.index + m[0].length)).replace(/\s+/g, ' ').trim();
      return true;
    };
    // in 10 minutes / in an hour / in half an hour / after 2 hours
    take(/\b(?:in|after)\s+(\d+(?:\.\d+)?|an?|one|two|three|four|five|ten|fifteen|twenty|thirty|half\s+an)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?|days?|weeks?)\b/i, (m) => {
      const n = /^\d/.test(m[1]) ? Number(m[1]) : WORDNUM[m[1].toLowerCase().replace(/\s+/g, ' ')];
      const unit = m[2].toLowerCase().replace(/s$/, '');
      at = new Date(now.getTime() + n * UNIT_MS[unit]);
    });
    let day = null;
    if (!at) {
      take(/\b(today|tonight|tomorrow|tmrw)\b/i, (m) => { day = m[1].toLowerCase(); });
      if (!day) take(/\b(?:on\s+|next\s+|this\s+)?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/i, (m) => { day = m[1].toLowerCase(); });
      let clock = null;
      take(/\b(?:at|by|@)\s*(\d{1,2}(?:[:.]\d{2})?\s*(?:am|pm|a\.m\.|p\.m\.)?)(?=\s|$|,)/i, (m) => { clock = parseClock(m[1]); return clock ? undefined : false; });
      if (!clock) take(/\b(\d{1,2}(?::\d{2})?\s*(?:am|pm))\b/i, (m) => { clock = parseClock(m[1]); return clock ? undefined : false; });
      if (!clock) take(/\b(noon|midday|midnight|morning|evening|night)\b/i, (m) => {
        clock = { noon: { h: 12, m: 0 }, midday: { h: 12, m: 0 }, midnight: { h: 0, m: 0 }, morning: { h: 9, m: 0 }, evening: { h: 18, m: 0 }, night: { h: 21, m: 0 } }[m[1].toLowerCase()];
      });
      if (day === 'tonight' && !clock) clock = { h: 20, m: 0 };
      if (clock || day) {
        const d = new Date(now.getTime());
        d.setSeconds(0, 0);
        if (!clock) clock = { h: 9, m: 0 };
        // "at 5" without am/pm means the next 5 o'clock (5 pm if 5 am has passed)
        if (!clock.explicit && clock.h < 12 && !day) {
          const am = new Date(d); am.setHours(clock.h, clock.m);
          if (am <= now) clock = { ...clock, h: clock.h + 12 };
        }
        d.setHours(clock.h, clock.m);
        if (day === 'tomorrow' || day === 'tmrw') d.setDate(d.getDate() + 1);
        else if (DAYS.includes(day)) {
          let add = (DAYS.indexOf(day) - d.getDay() + 7) % 7;
          if (add === 0 && d <= now) add = 7;
          d.setDate(d.getDate() + add);
        } else if (d <= now) d.setDate(d.getDate() + 1);
        at = d;
      }
    }
    let text = rest.replace(/^[,:\s]+|[,:\s]+$/g, '');
    for (let i = 0; i < 3; i++) text = text.replace(/^(?:for|to|that|about|of)\s+/i, '');
    text = text.replace(/\s+(?:to|at|on|in|for)$/i, '').trim();
    if (!text) return null;
    text = text.charAt(0).toUpperCase() + text.slice(1);
    return at ? { text, at: at.getTime() } : { text, at: null, needTime: true };
  }


  // ---------------------------------------------------------------- computer control
  /** null or { kind: 'app', name } | { kind: 'window', action, target } | { kind: 'search', mode: 'name'|'inside', query, fileKind } */
  function parseComputerCommand(text) {
    const t = String(text || '').trim().replace(/[.!?]+$/, '');
    let m;
    if (/^(?:please\s+)?(?:minimi[sz]e\s+(?:all|every)(?:\s+(?:the\s+)?windows)?|show\s+(?:me\s+)?(?:the\s+)?desktop|hide\s+all\s+windows)$/i.test(t)) return { kind: 'window', action: 'minimizeAll', target: '' };
    if (/^(?:please\s+)?(?:restore|bring\s+back)\s+all(?:\s+(?:the\s+)?windows)?$/i.test(t)) return { kind: 'window', action: 'restoreAll', target: '' };
    if (/^(?:please\s+)?(?:list|show)\s+(?:me\s+)?(?:all\s+)?(?:the\s+)?open\s+(?:windows|apps|programs)$|^what\s+(?:windows|apps|programs)\s+are\s+open$/i.test(t)) return { kind: 'window', action: 'list', target: '' };
    if ((m = /^(?:please\s+)?(?:switch\s+to|go\s+to|focus(?:\s+on)?|bring\s+up|activate)\s+(?:the\s+)?(.{2,60}?)(?:\s+window)?$/i.exec(t))) return { kind: 'window', action: 'focus', target: m[1] };
    if ((m = /^(?:please\s+)?(minimi[sz]e|maximi[sz]e|restore)\s+(?:the\s+)?(.{2,60}?)(?:\s+window)?$/i.exec(t))) return { kind: 'window', action: m[1].toLowerCase().replace(/ise$/, 'ize'), target: m[2] };
    if ((m = /^(?:please\s+)?(?:find|search\s+for|look\s+for|locate)\s+(?:all\s+)?(?:my\s+)?(files?|documents?|docs|pdfs?|images?|photos?|pictures?)\s+(?:named|called|with\s+(?:the\s+)?name|whose\s+name\s+(?:has|contains))\s+["“']?(.+?)["”']?$/i.exec(t))) {
      const k = m[1].toLowerCase();
      return { kind: 'search', mode: 'name', query: m[2], fileKind: /pdf/.test(k) ? 'pdf' : /image|photo|picture/.test(k) ? 'images' : /doc/.test(k) ? 'docs' : 'all' };
    }
    if ((m = /^(?:please\s+)?(?:find|search(?:\s+for)?|look\s+for)\s+(?:all\s+)?(?:my\s+)?(?:files?|documents?|docs|pdfs?|notes)\s+(?:containing|that\s+(?:contain|mention|talk\s+about)|which\s+(?:contain|mention)|with\s+(?:the\s+)?(?:text|word|words|phrase)|about|mentioning)\s+["“']?(.+?)["”']?$/i.exec(t))) return { kind: 'search', mode: 'inside', query: m[1] };
    if ((m = /^(?:please\s+)?search\s+(?:my\s+|all\s+my\s+)?(?:files|documents|folders)\s+for\s+["“']?(.+?)["”']?$/i.exec(t))) return { kind: 'search', mode: 'inside', query: m[1] };
    if ((m = /^(?:please\s+|can\s+you\s+|could\s+you\s+)?(?:open|launch|start|run)\s+(?:the\s+|my\s+)?(?:app\s+)?([a-z0-9][\w .+#&'-]{1,40}?)(?:\s+(?:app|application|program))?(?:\s+for\s+me)?$/i.exec(t))) {
      const name = m[1].trim();
      if (/[\\/:]|\.\w{2,4}$|\b(file|folder|document|pdf|it|this|that)\b/i.test(name)) return null; // files are handled elsewhere
      return { kind: 'app', name };
    }
    return null;
  }


  const ACTION_VERBS = /\b(find|search|read|summari[sz]e|write|draft|save|create|make|convert|copy|move|organi[sz]e|sort|open|launch|remind|list|rename|email|translate|edit|fix|put)\b/gi;
  /** "/task …", or a request that chains two or more actions ("find X, summarise it and save it to Desktop"). */
  function isTaskRequest(text) {
    const t = String(text || '').trim();
    if (/^\/task\b/i.test(t)) return true;
    if (t.length > 600 || /\?\s*$/.test(t) || /^(how|what|why|when|who|which|can you explain)\b/i.test(t)) return false;
    const verbs = new Set((t.match(ACTION_VERBS) || []).map((v) => v.toLowerCase().replace(/is(e)$/, 'iz$1')));
    return verbs.size >= 3 && /\b(then|and then|after that|next|finally)\b|,\s*(then\s+)?\w+.*\band\b/i.test(t);
  }


  /** "/command rest" -> { command, input } or null. */
  function parseSkillCall(text) {
    const m = /^\/([a-z][a-z0-9-]{1,23})(?:\s+([\s\S]*))?$/i.exec(String(text || '').trim());
    return m ? { command: m[1].toLowerCase(), input: (m[2] || '').trim() } : null;
  }
  /** "/skill …", "create a skill that …", "teach yourself to …", "make a new command that …" -> request text or null. */
  function parseSkillRequest(text) {
    const t = String(text || '').trim();
    let m = /^\/skill\s+([\s\S]{3,})$/i.exec(t);
    if (m) return m[1].trim();
    m = /^(?:please\s+|can\s+you\s+)?(?:create|make|add|build|write)\s+(?:a\s+|me\s+a\s+)?(?:new\s+)?(?:skill|command|ability|plugin)\s+(?:that|which|to|for|called\s+\S+\s+(?:that|to))\s+([\s\S]{3,})$/i.exec(t);
    if (m) return m[1].trim();
    m = /^(?:please\s+)?(?:teach\s+yourself|learn)\s+(?:how\s+)?to\s+([\s\S]{3,})$/i.exec(t);
    return m ? m[1].trim() : null;
  }

  return { parseReminder, parseClock, parseComputerCommand, isTaskRequest, parseSkillCall, parseSkillRequest };
});
