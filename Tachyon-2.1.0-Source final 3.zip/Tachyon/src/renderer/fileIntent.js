(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TachyonFiles = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Finds files and folders the user names in a chat message ("summarize C:\Docs\report.pdf",
  // "list the files in my Downloads folder", "fix the typos in notes.txt") and what they want done with them.
  // Only the user's own messages are parsed, never model output.

  const EXT = 'txt|md|csv|tsv|json|xml|html?|css|jsx?|tsx?|py|java|kt|c|cpp|h|cs|go|rs|rb|php|sh|bat|ps1|sql|ya?ml|toml|ini|cfg|log|tex|gradle|properties|rtf|pdf|docx?|xlsx?|pptx?|odt|ods|odp|epub|png|jpe?g|webp|gif|bmp|svg|tiff?|heic';
  const KNOWN = 'desktop|documents|downloads|pictures|music|videos';
  // Paths may contain spaces when they end in a known file extension; otherwise they stop at whitespace.
  const WIN_FILE = `[A-Za-z]:[\\\\/](?:[^\\\\/:*?"<>|\\r\\n]+[\\\\/])*[^\\\\/:*?"<>|\\r\\n]*?\\.(?:${EXT})(?![\\w.])`;
  const WIN_DIR = '[A-Za-z]:[\\\\/][^\\s"\'<>|?*]*';
  const NIX_FILE = `(?:~|/)(?:[^/\\r\\n"'<>|]+/)*[^/\\r\\n"'<>|]*?\\.(?:${EXT})(?![\\w.])`;
  const NIX_DIR = '(?:~(?=[/\\s]|$)|/)[^\\s"\'<>|]*';
  const RX = {
    quoted: /["“'`]([^"”'`\r\n]{2,260})["”'`]/g,
    win: new RegExp(`(?<![\\w])(?:${WIN_FILE}|${WIN_DIR})`, 'g'),
    nix: new RegExp(`(?<![\\w.:/\\\\~-])(?:${NIX_FILE}|${NIX_DIR})`, 'g'),
    known: new RegExp(`\\b(?:(?:my|the)\\s+(${KNOWN})(?:\\s+folder)?|(${KNOWN})\\s+folder)\\b`, 'gi'),
    name: new RegExp(`(?<![\\w\\\\/.~-])[\\w()\\[\\]-]+(?:[ .][\\w()\\[\\]-]+)*?\\.(?:${EXT})(?![\\w.])`, 'gi'),
  };
  const NAME_SIMPLE = new RegExp(`^[\\w()\\[\\]-]+(?:\\.[\\w()\\[\\]-]+)*\\.(?:${EXT})$`, 'i');
  const LOOKS_PATH = /^(?:[A-Za-z]:[\\/]|~(?:[\\/]|$)|\/)/;
  const ACTION = /\b(open|read|summari[sz]e|summary|analy[sz]e|check|review|look\s+(?:at|in|into|through)|explain|translate|edit|fix|update|change|modify|rewrite|correct|proofread|convert|resize|show|list|organi[sz]e|sort|tidy|use|load|attach|access|scan|go\s+through|extract|compare|count|describe|what(?:'s| is| are)\s+(?:in|inside)|find|reveal|locate|clean\s+up|refactor|format|add|insert|remove|delete|replace|rename|ocr|transcribe|tell\s+me\s+about|answer|grade|improve|shorten|simplify)\b/i;
  const IMG = /\.(png|jpe?g)$/i;
  const DOC_FORMATS = /\b(?:to|into|as)\s+(?:an?\s+)?\.?(pdf|docx|word(?:\s+doc(?:ument)?)?|markdown|md|html|txt|text|png|jpe?g)\b/i;

  function trimPunct(s) { return s.replace(/[)\].,;:!?]+$/, '').replace(/^[(\[]+/, ''); }

  /** Returns [{kind: 'path'|'known'|'name', value, start, end}] in message order, without overlaps. */
  function extractTargets(text) {
    const t = String(text || '');
    const found = [];
    const taken = [];
    const free = (s, e) => !taken.some(([a, b]) => s < b && e > a);
    const add = (kind, value, s, e) => { if (value && free(s, e)) { taken.push([s, e]); found.push({ kind, value, start: s, end: e }); } };
    for (const m of t.matchAll(RX.quoted)) {
      const v = m[1].trim();
      if (LOOKS_PATH.test(v)) add('path', v, m.index, m.index + m[0].length);
      else if (NAME_SIMPLE.test(v.replace(/ /g, '_'))) add('name', v, m.index, m.index + m[0].length);
    }
    for (const rx of [RX.win, RX.nix]) {
      for (const m of t.matchAll(rx)) {
        const v = trimPunct(m[0]);
        // skip "/image"-style commands, "and/or" and a lone "/"
        if (v.startsWith('/') && v.split('/').filter(Boolean).length < 2 && !/\.\w+$/.test(v)) continue;
        add('path', v, m.index, m.index + v.length);
      }
    }
    for (const m of t.matchAll(RX.known)) add('known', (m[1] || m[2]).toLowerCase(), m.index, m.index + m[0].length);
    for (const m of t.matchAll(RX.name)) {
      // "summarize my budget 2024.xlsx": the shortest name is "2024.xlsx"; longer word runs are offered as alternatives
      const words = m[0].split(' ');
      const v = words[words.length - 1];
      const s = m.index + m[0].length - v.length;
      const alts = [];
      for (let k = 2; k <= Math.min(5, words.length); k++) alts.push(words.slice(-k).join(' '));
      if (free(s, s + v.length)) { taken.push([s, s + v.length]); found.push({ kind: 'name', value: v, alts, start: s, end: s + v.length }); }
    }
    return found.sort((a, b) => a.start - b.start);
  }

  /** Decides what to do with the named files/folders. */
  function detectOp(text) {
    const t = String(text || '');
    const fm = DOC_FORMATS.exec(t);
    const format = fm ? normFormat(fm[1]) : null;
    if (/\bresize\b/i.test(t)) {
      const w = /(\d{2,5})\s*(?:px|pixels?)?\s*(?:wide|width)?/i.exec(t.replace(/\.(?:png|jpe?g)\b/gi, ''));
      return { op: 'resize', width: w ? Number(w[1]) : null };
    }
    if (/\bconvert\b/i.test(t) && format) return { op: 'convert', format };
    if (/\b(organi[sz]e|sort|tidy(?:\s+up)?|declutter)\b/i.test(t)) return { op: 'organize', mode: /\bmonth|date\b/i.test(t) ? 'month' : /\bextension\b/i.test(t) ? 'ext' : 'type' };
    if (/\b(reveal|locate)\b/i.test(t) || /\bshow\b.*\bin\s+(?:the\s+)?(?:folder|explorer|finder|file manager)\b/i.test(t)) return { op: 'reveal' };
    if (/\b(list|ls)\b/i.test(t) || /\bwhat(?:'s| is| are)\s+(?:the\s+)?(?:files?\s+)?(?:in|inside)\b/i.test(t) || /\b(show|see)\s+(?:me\s+)?(?:the\s+|all\s+)?(?:files|contents?)\b/i.test(t) || /\bcontents?\s+of\b/i.test(t)) return { op: 'list' };
    if (/^\s*(?:please\s+|can you\s+|could you\s+)?(open|launch)\b/i.test(t) && !/\b(and|then)\s+(?!open)\w+/i.test(t.replace(/^\s*\w+(\s+you)?\s+(open|launch)/i, ''))) return { op: 'open' };
    if (/\b(edit|fix|correct|change|modify|update|rewrite|replace|insert|add|remove|delete|rename|refactor|reformat|format|proofread|clean\s+up|improve|shorten|simplify)\b/i.test(t)
      && !/\b(how|what|why|which)\b.*\?\s*$/i.test(t)) return { op: 'edit' };
    return { op: 'ask' };
  }

  function normFormat(f) {
    f = f.toLowerCase();
    if (f.startsWith('word')) return 'docx';
    if (f === 'markdown') return 'md';
    if (f === 'text') return 'txt';
    if (f === 'jpeg') return 'jpg';
    return f;
  }

  /** null, or { targets, op, ...params } when the message asks to do something with a named file or folder. */
  function parseFileRequest(text) {
    const t = String(text || '').trim();
    if (!t || /^\/image(\s|$)/i.test(t)) return null;
    const targets = extractTargets(t);
    if (!targets.length) return null;
    if (!ACTION.test(t)) return null;
    // a bare file name with no folder only counts if it is clearly the subject of the request
    const strong = targets.filter((x) => x.kind !== 'name');
    const names = targets.filter((x) => x.kind === 'name');
    const keep = strong.length ? [...strong, ...names] : names;
    return { targets: keep.map(({ kind, value, alts }) => (alts && alts.length ? { kind, value, alts } : { kind, value })), ...detectOp(t) };
  }

  /** "fix the typo in it", "now update that file": a follow-up edit that refers to the file used just before. */
  function isEditFollowUp(text) {
    const t = String(text || '');
    return detectOp(t).op === 'edit' && /\b(it|this|that|the|same)\s*(?:file|document|script|code|one|csv|json|notes?)?\b/i.test(t) && !extractTargets(t).length;
  }

  const isImagePath = (p) => IMG.test(p);

  return { extractTargets, detectOp, parseFileRequest, isEditFollowUp, isImagePath };
});
