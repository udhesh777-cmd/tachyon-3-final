'use strict';
// Tachyon icon set: simple 24x24 line icons drawn for this app (Lucide-style: 2px round strokes, no fills).
// SVG is created with createElementNS, not from HTML strings, so it works under the strict CSP (no inline styles or scripts).
(function () {
  const L = (x1, y1, x2, y2) => ['line', { x1, y1, x2, y2 }];
  const C = (cx, cy, r) => ['circle', { cx, cy, r }];
  const R = (x, y, w, h, rx = 0) => ['rect', { x, y, width: w, height: h, rx }];
  const P = (d) => ['path', { d }];
  const PL = (points) => ['polyline', { points }];

  const ICONS = {
    plus: [L(12, 5, 12, 19), L(5, 12, 19, 12)],
    x: [L(18, 6, 6, 18), L(6, 6, 18, 18)],
    check: [PL('20 6 9 17 4 12')],
    'chevron-left': [PL('15 18 9 12 15 6')],
    'chevron-right': [PL('9 18 15 12 9 6')],
    'chevron-down': [PL('6 9 12 15 18 9')],
    'panel-left': [R(3, 3, 18, 18, 2), L(9, 3, 9, 21)],
    'message-square': [P('M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z')],
    history: [P('M3 12a9 9 0 1 0 3-6.7L3 8'), PL('3 3 3 8 8 8'), PL('12 7 12 12 15 14')],
    clock: [C(12, 12, 9), PL('12 7 12 12 15 14')],
    cpu: [R(6, 6, 12, 12, 2), R(9, 9, 6, 6, 1), L(9, 2, 9, 6), L(15, 2, 15, 6), L(9, 18, 9, 22), L(15, 18, 15, 22), L(2, 9, 6, 9), L(2, 15, 6, 15), L(18, 9, 22, 9), L(18, 15, 22, 15)],
    'layout-grid': [R(3, 3, 7, 7, 1), R(14, 3, 7, 7, 1), R(3, 14, 7, 7, 1), R(14, 14, 7, 7, 1)],
    wrench: [P('M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z')],
    folder: [P('M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z')],
    'folder-open': [P('M3 8V6a2 2 0 0 1 2-2h4l2 2h7a2 2 0 0 1 2 2v2'), P('M3 10h18l-1.6 7.2a2 2 0 0 1-2 1.8H5a2 2 0 0 1-2-2z')],
    briefcase: [R(3, 7, 18, 13, 2), P('M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2'), L(3, 13, 21, 13)],
    'list-checks': [L(11, 6, 21, 6), L(11, 12, 21, 12), L(11, 18, 21, 18), PL('3 6 4.5 7.5 7 4.5'), PL('3 12 4.5 13.5 7 10.5'), PL('3 18 4.5 19.5 7 16.5')],
    image: [R(3, 3, 18, 18, 2), C(9, 9, 1.5), P('M21 15l-5-5L5 21')],
    settings: [L(4, 7, 20, 7), L(4, 17, 20, 17), C(9, 7, 2.2), C(15, 17, 2.2)],
    'shield-check': [P('M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z'), PL('9 12 11 14 15 10')],
    activity: [PL('22 12 18 12 15 21 9 3 6 12 2 12')],
    'circle-help': [C(12, 12, 10), P('M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3'), L(12, 17, 12.01, 17)],
    code: [PL('16 18 22 12 16 6'), PL('8 6 2 12 8 18')],
    globe: [C(12, 12, 10), L(2, 12, 22, 12), P('M12 2a15 15 0 0 1 0 20a15 15 0 0 1 0-20')],
    terminal: [PL('4 17 10 11 4 5'), L(12, 19, 20, 19)],
    'square-terminal': [R(3, 3, 18, 18, 2), PL('7 9 10 12 7 15'), L(13, 15, 17, 15)],
    'git-branch': [L(6, 3, 6, 15), C(18, 6, 3), C(6, 18, 3), P('M18 9a9 9 0 0 1-9 9')],
    'app-window': [R(3, 4, 18, 16, 2), L(3, 9, 21, 9), L(7, 6.5, 7.01, 6.5)],
    play: [P('M6 4l14 8-14 8z')],
    search: [C(11, 11, 7), L(21, 21, 16.5, 16.5)],
    paperclip: [P('M21 11l-9.2 9.2a5.5 5.5 0 0 1-7.8-7.8L13.5 3a3.7 3.7 0 0 1 5.2 5.2L9.5 17.4a1.8 1.8 0 0 1-2.6-2.6L15 6.8')],
    mic: [R(9, 2, 6, 12, 3), P('M5 11a7 7 0 0 0 14 0'), L(12, 18, 12, 22)],
    send: [L(22, 2, 11, 13), P('M22 2l-7 20-4-9-9-4z')],
    square: [R(6, 6, 12, 12, 2)],
    download: [P('M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'), PL('7 10 12 15 17 10'), L(12, 15, 12, 3)],
    trash: [PL('3 6 5 6 21 6'), P('M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6'), L(10, 11, 10, 17), L(14, 11, 14, 17), P('M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2')],
    'alert-triangle': [P('M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z'), L(12, 9, 12, 13), L(12, 17, 12.01, 17)],
    'x-circle': [C(12, 12, 10), L(15, 9, 9, 15), L(9, 9, 15, 15)],
    'check-circle': [C(12, 12, 10), PL('8 12 11 15 16 9')],
    info: [C(12, 12, 10), L(12, 16, 12, 12), L(12, 8, 12.01, 8)],
    sun: [C(12, 12, 4), L(12, 2, 12, 4), L(12, 20, 12, 22), L(2, 12, 4, 12), L(20, 12, 22, 12), L(4.9, 4.9, 6.3, 6.3), L(17.7, 17.7, 19.1, 19.1), L(4.9, 19.1, 6.3, 17.7), L(17.7, 6.3, 19.1, 4.9)],
    moon: [P('M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z')],
    pencil: [P('M17 3l4 4L8 20l-5 1 1-5z')],
    save: [P('M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z'), PL('17 21 17 13 7 13 7 21'), PL('7 3 7 8 15 8')],
    refresh: [P('M3 12a9 9 0 0 1 15.5-6.2L21 8'), PL('21 3 21 8 16 8'), P('M21 12a9 9 0 0 1-15.5 6.2L3 16'), PL('3 21 3 16 8 16')],
    plug: [L(9, 2, 9, 8), L(15, 2, 15, 8), P('M6 8h12v4a6 6 0 0 1-12 0z'), L(12, 18, 12, 22)],
    eye: [P('M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z'), C(12, 12, 3)],
    'file-text': [P('M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'), PL('14 2 14 8 20 8'), L(8, 13, 16, 13), L(8, 17, 16, 17)],
    undo: [PL('3 4 3 10 9 10'), P('M3.5 10a9 9 0 1 1 2 6')],
    bell: [P('M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9'), P('M13.7 21a2 2 0 0 1-3.4 0')],
    zap: [P('M13 2L3 14h9l-1 8 10-12h-9z')],
    sparkles: [P('M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z'), L(19, 3, 19, 7), L(17, 5, 21, 5)],
    package: [P('M21 8l-9-5-9 5v8l9 5 9-5z'), PL('3 8 12 13 21 8'), L(12, 13, 12, 21)],
    volume: [P('M11 5L6 9H2v6h4l5 4z'), P('M15.5 8.5a5 5 0 0 1 0 7'), P('M19 5a10 10 0 0 1 0 14')],
    'arrow-right': [L(5, 12, 19, 12), PL('12 5 19 12 12 19')],
    'arrow-left': [L(19, 12, 5, 12), PL('12 19 5 12 12 5')],
    'external-link': [P('M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6'), PL('15 3 21 3 21 9'), L(10, 14, 21, 3)],
    loader: [P('M21 12a9 9 0 1 1-6.2-8.55')],
    copy: [R(9, 9, 13, 13, 2), P('M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1')],
    monitor: [R(2, 3, 20, 14, 2), L(8, 21, 16, 21), L(12, 17, 12, 21)],
    bot: [R(4, 8, 16, 12, 3), L(12, 4, 12, 8), C(9, 14, 1), C(15, 14, 1)],
    lock: [R(5, 11, 14, 10, 2), P('M8 11V7a4 4 0 0 1 8 0v4')],
    cloud: [P('M18 10h-1.3A6 6 0 1 0 5 15.6 4 4 0 0 0 6 20h12a5 5 0 0 0 0-10z')],
    link: [P('M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7'), P('M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7')],
    list: [L(8, 6, 21, 6), L(8, 12, 21, 12), L(8, 18, 21, 18), L(3, 6, 3.01, 6), L(3, 12, 3.01, 12), L(3, 18, 3.01, 18)],
    'file-up': [P('M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'), PL('14 2 14 8 20 8'), L(12, 18, 12, 12), PL('9 15 12 12 15 15')],
    'volume-x': [P('M11 5L6 9H2v6h4l5 4z'), L(22, 9, 16, 15), L(16, 9, 22, 15)],
    rotate: [P('M21 12a9 9 0 1 1-3-6.7L21 8'), PL('21 3 21 8 16 8')],
    'circle-dot': [C(12, 12, 10), C(12, 12, 2)],
    'minus-circle': [C(12, 12, 10), L(8, 12, 16, 12)],
    stethoscope: [P('M6 3v6a4 4 0 0 0 8 0V3'), P('M10 13v2a5 5 0 0 0 10 0v-2'), C(20, 11, 2)],
  };

  const NS = 'http://www.w3.org/2000/svg';
  function icon(name, size = 18) {
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('width', size);
    svg.setAttribute('height', size);
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '2');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('class', 'svg-icon');
    for (const [tag, attrs] of ICONS[name] || ICONS['circle-help']) {
      const e = document.createElementNS(NS, tag);
      for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
      svg.append(e);
    }
    return svg;
  }
  /** Fills every <span data-icon="name"> below root with its SVG (done once at start-up for the static HTML). */
  function hydrate(root = document) {
    for (const s of root.querySelectorAll('[data-icon]')) {
      if (s.firstChild && s.firstChild.nodeType === 1) continue;
      s.replaceChildren(icon(s.dataset.icon, Number(s.dataset.size) || 18));
    }
  }
  window.TachyonIcons = { icon, hydrate, names: Object.keys(ICONS), has: (n) => Object.prototype.hasOwnProperty.call(ICONS, n) };
})();
