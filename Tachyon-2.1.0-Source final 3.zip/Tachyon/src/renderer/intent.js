(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.NovaIntent = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Detects an EXPLICIT request to export/create a file, so files are only produced when the user asks.
  const QUESTION = /^\s*(how|what|why|where|which|who|when|does|do|is|are|should|will)\b/i;
  const VERB = /\b(export|save|download|convert|turn|generate|create|make|produce|write|prepare|give\s+me|put)\b/i;
  const FORMATS = '(pdf|docx|word(?:\\s+doc(?:ument)?)?|markdown|md|json|csv|html|txt|(?:plain\\s+)?text(?:\\s+file)?)';
  const TARGET = new RegExp('\\b(?:to|as|into|in)\\s+(?:an?\\s+|the\\s+|one\\s+)?\\.?' + FORMATS + '\\b', 'i');
  const NEWDOC = new RegExp('\\b(?:create|make|generate|produce|write|prepare|give\\s+me)\\s+(?:me\\s+)?(?:an?\\s+|the\\s+)?(?:[\\w-]+\\s+){0,3}?' + FORMATS + '(?:\\s+(?:file|document|report))?\\b', 'i');
  const REF = /\b(this|that|it|these|those|above|previous|last|answer|response|reply|result|output)\b/i;

  function norm(f) {
    f = f.toLowerCase().replace(/^\./, '');
    if (f.startsWith('word')) return 'docx';
    if (f === 'markdown') return 'md';
    if (f.includes('text')) return 'txt';
    return f;
  }

  /** Returns null or { format, scope: 'previous' | 'new' }. 'previous' = export the last answer. */
  function parseExportIntent(text) {
    const t = String(text || '').trim();
    if (!t || t.length > 160 || t.split(/\s+/).length > 22) return null;
    if (QUESTION.test(t) || !VERB.test(t)) return null;
    const m = TARGET.exec(t);
    if (m) return { format: norm(m[1]), scope: REF.test(t.replace(TARGET, ' ')) ? 'previous' : 'new' };
    const n = NEWDOC.exec(t);
    if (n) return { format: norm(n[1]), scope: /\b(of|from)\s+(this|that|it|the\s+(above|answer|reply|response|result))\b/i.test(t) ? 'previous' : 'new' };
    return null;
  }

  // ---------------------------------------------------------------- "save it to <place>" (no Save dialog)
  const SAVE_EXT = 'pdf|docx|txt|md|html?|csv|json|py|js|ts|java|kt|c|cpp|cs|go|rs|sh|sql|xml|ya?ml|css';
  const KNOWN = 'desktop|documents|downloads|pictures|music|videos|home';
  const STOP = `(?=\\s+(?:as|and|then|please|in\\s+(?:an?\\s+)?${FORMATS.slice(1, -1)}|with|named|called|from\\s+now)\\b|\\s*[,;!?]|\\.(?:\\s|$)|\\s*$)`;
  const LOC = new RegExp(
    '\\b(?:to|in|into|on|under|at|inside)\\s+(?:the\\s+)?(?:folder\\s+)?(?:' +
      '["“\'`]([^"”\'`\\r\\n]+)["”\'`]' +                                   // 1 quoted
      '|([A-Za-z]:[\\\\/][^\\r\\n"<>|?*]*?|~(?:[\\\\/][^\\r\\n"<>|]*?)?|/[^\\r\\n"<>|]+?)' + STOP + // 2 path
      `|(?:my\\s+|the\\s+)?(${KNOWN})(?:\\s+(?:folder|directory))?\\b` +   // 3 known folder
    ')', 'i');
  const SAVE_VERB = /\b(save|saved|export|store|put|keep|write|download|auto[- ]?save)\b/gi;
  const FILENAME = new RegExp(`\\b(?:as|named|called)\\s+["“'\`]?([^\\s"”'\`\\\\/]+\\.(?:${SAVE_EXT}))["”'\`]?(?![\\w.])`, 'i');
  const FMT_WORD = new RegExp('\\b(?:as|in|to|into)\\s+(?:an?\\s+|the\\s+)?\\.?' + FORMATS + '(?:\\s+(?:file|document|format))?\\b', 'i');
  const OFF = /\b(?:stop|turn\s+off|disable|cancel|no\s+more|don'?t|do\s+not)\s+(?:the\s+)?(?:auto[- ]?sav(?:e|ing)|saving\s+(?:the\s+)?(?:answers?|repl(?:y|ies)|responses?|everything|automatically))\b|\bauto[- ]?save\s+off\b/i;
  const ALWAYS = /\b(?:auto[- ]?save|from\s+now\s+on|always\s+save|keep\s+saving|save\s+(?:all|every|each)\s+(?:of\s+)?(?:my\s+|the\s+|your\s+)?(?:answers?|repl(?:y|ies)|responses?|outputs?|messages?)|automatically\s+save|save\s+.*\bautomatically)\b/i;
  const FILLER = /\b(please|kindly|and|then|also|now|it|this|that|these|those|the|above|previous|last|answer|response|reply|result|output|text|as|a|an|me|for|my|file|document|copy|of|can|could|you|would|will|just|here|there|ok|okay)\b/gi;

  /**
   * Returns null or { mode: 'once'|'always'|'off', scope: 'previous'|'new', location: {kind:'path'|'known', value}|null,
   * filename, format, clause: [start, end] }. A place (path, quoted path, "my desktop"…) or a file name is required.
   */
  function parseSaveIntent(text) {
    const t = String(text || '').trim();
    if (!t) return null;
    if (OFF.test(t)) return { mode: 'off', scope: 'previous', location: null, filename: null, format: null, clause: [0, t.length] };
    if (QUESTION.test(t)) return null;
    const verbs = [...t.matchAll(SAVE_VERB)].reverse(); // the verb nearest to the place wins ("write a poem and save it to …")
    let best = null;
    for (const v of verbs) {
      const rest = t.slice(v.index);
      const loc = LOC.exec(rest);
      const fn = FILENAME.exec(rest);
      const locOk = loc && loc.index <= 60;
      const fnOk = fn && fn.index <= 60;
      if (!locOk && !fnOk) continue;
      let end = v.index + Math.max(locOk ? loc.index + loc[0].length : 0, fnOk ? fn.index + fn[0].length : 0);
      const fm = FMT_WORD.exec(t.slice(v.index, end + 40));
      if (fm && v.index + fm.index <= end + 2) end = Math.max(end, v.index + fm.index + fm[0].length);
      let location = null;
      if (locOk) {
        if (loc[1]) location = { kind: 'path', value: loc[1].trim() };
        else if (loc[2]) location = { kind: 'path', value: loc[2].trim().replace(/[.,;:!?]+$/, '') };
        else location = { kind: 'known', value: loc[3].toLowerCase() };
      }
      best = { v, location, filename: fnOk ? fn[1] : null, format: fm ? norm(fm[1]) : null, clause: [v.index, end] };
      break;
    }
    if (!best) return null;
    if (best.location && best.location.kind === 'path' && /^https?:/i.test(best.location.value)) return null;
    const mode = ALWAYS.test(t) ? 'always' : 'once';
    const remainder = (t.slice(0, best.clause[0]) + ' ' + t.slice(best.clause[1])).replace(ALWAYS, ' ').replace(FILLER, ' ').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
    const scope = remainder.split(/\s+/).filter((w) => w.length > 1).length >= 2 ? 'new' : 'previous';
    return { mode, scope, location: best.location, filename: best.filename, format: best.format, clause: best.clause };
  }

  // ---------------------------------------------------------------- personal memory ("remember that …", "forget …")
  /** null or { op: 'add', text } | { op: 'forget', query } | { op: 'forgetAll' } | { op: 'list' } */
  function parseMemoryCommand(text) {
    const t = String(text || '').trim().replace(/[.!]+$/, '');
    if (!t || t.length > 400) return null;
    if (/^(?:please\s+)?(?:what\s+do\s+you\s+(?:remember|know)\s+about\s+me|show\s+(?:me\s+)?(?:my\s+|your\s+)?memor(?:y|ies)|list\s+(?:my\s+|your\s+)?memor(?:y|ies))\??$/i.test(t)) return { op: 'list' };
    if (/^(?:please\s+)?forget\s+(?:everything|all)(?:\s+(?:about\s+me|you\s+know|you\s+remember))?$/i.test(t)) return { op: 'forgetAll' };
    let m = /^(?:please\s+)?forget\s+(?:that\s+|about\s+)?(.{3,})$/i.exec(t);
    if (m) return { op: 'forget', query: m[1].trim() };
    m = /^(?:please\s+)?(?:remember|note|keep\s+in\s+mind|don'?t\s+forget)\s+(?:that\s+)?(.{3,})$/i.exec(t);
    if (m && !/^(?:when|how|what|where|why|who|the\s+time|to\s+remind)\b/i.test(m[1]) && !/\?$/.test(t)) {
      const fact = m[1].trim();
      return { op: 'add', text: fact.charAt(0).toUpperCase() + fact.slice(1) };
    }
    return null;
  }

  return { parseExportIntent, parseSaveIntent, parseMemoryCommand };
});
