(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.NovaMarkdown = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // Small, safe Markdown renderer: paragraphs, headings, bullet/numbered lists, tables, code blocks,
  // bold/italic/inline code. It builds DOM nodes with textContent only (never innerHTML) and never creates links.

  const INLINE = /(`[^`\n]+`)|(\*\*[^*\n]+\*\*|__[^_\n]+__)|(\*[^*\s][^*\n]*\*|(?<!\w)_[^_\n]+_(?!\w))|(\[[^\]\n]+\]\([^)\s]+\))/g;

  function parseInline(s) {
    const out = [];
    let last = 0;
    for (const m of s.matchAll(INLINE)) {
      if (m.index > last) out.push({ t: 'text', v: s.slice(last, m.index) });
      const tok = m[0];
      if (m[1]) out.push({ t: 'code', v: tok.slice(1, -1) });
      else if (m[2]) out.push({ t: 'b', c: parseInline(tok.slice(2, -2)) });
      else if (m[3]) out.push({ t: 'i', c: parseInline(tok.slice(1, -1)) });
      else {
        const mm = /^\[([^\]]+)\]\(([^)\s]+)\)$/.exec(tok);
        out.push({ t: 'link', v: mm[1], href: mm[2] });
      }
      last = m.index + tok.length;
    }
    if (last < s.length) out.push({ t: 'text', v: s.slice(last) });
    return out;
  }

  const FENCE = /^\s*```\s*([\w+#.-]*)\s*$/;
  const HEADING = /^(#{1,6})\s+(.*?)\s*#*\s*$/;
  const HR = /^\s*([-*_])(\s*\1){2,}\s*$/;
  const LIST = /^(\s*)([-*+]|\d+[.)])\s+(.*)$/;
  const TABLE_SEP_RE = /^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$/;
  const TABLE_SEP = { test: (l) => l.includes('|') && TABLE_SEP_RE.test(l) };

  function splitRow(line) {
    let s = line.trim();
    if (s.startsWith('|')) s = s.slice(1);
    if (s.endsWith('|') && !s.endsWith('\\|')) s = s.slice(0, -1);
    return s.split(/(?<!\\)\|/).map((c) => c.replace(/\\\|/g, '|').trim());
  }

  function parseMarkdown(src) {
    const lines = String(src).replace(/\r\n?/g, '\n').split('\n');
    const blocks = [];
    let i = 0;
    const isBlockStart = (idx) => {
      const l = lines[idx];
      return FENCE.test(l) || HEADING.test(l) || HR.test(l) || LIST.test(l) || (l.includes('|') && idx + 1 < lines.length && TABLE_SEP.test(lines[idx + 1]));
    };
    while (i < lines.length) {
      const line = lines[i];
      if (!line.trim()) { i++; continue; }
      let m = FENCE.exec(line);
      if (m) {
        const body = [];
        i++;
        while (i < lines.length && !/^\s*```\s*$/.test(lines[i])) body.push(lines[i++]);
        i++;
        blocks.push({ type: 'code', lang: m[1] || '', text: body.join('\n') });
        continue;
      }
      if ((m = HEADING.exec(line))) { blocks.push({ type: 'heading', level: m[1].length, inline: parseInline(m[2]) }); i++; continue; }
      if (HR.test(line)) { blocks.push({ type: 'hr' }); i++; continue; }
      if (line.includes('|') && i + 1 < lines.length && TABLE_SEP.test(lines[i + 1])) {
        const header = splitRow(line);
        const align = splitRow(lines[i + 1]).map((c) => (c.startsWith(':') && c.endsWith(':') ? 'center' : c.endsWith(':') ? 'right' : ''));
        i += 2;
        const rows = [];
        while (i < lines.length && lines[i].trim() && lines[i].includes('|')) rows.push(splitRow(lines[i++]));
        blocks.push({ type: 'table', align, header: header.map(parseInline), rows: rows.map((r) => r.map(parseInline)) });
        continue;
      }
      if ((m = LIST.exec(line))) {
        const ordered = /\d/.test(m[2]);
        const items = [];
        const start = ordered ? parseInt(m[2], 10) : 1;
        while (i < lines.length) {
          const lm = LIST.exec(lines[i]);
          if (lm && /\d/.test(lm[2]) === ordered) { items.push({ depth: Math.min(2, Math.floor(lm[1].length / 2)), inline: parseInline(lm[3]) }); i++; }
          else if (lines[i].trim() && /^\s{2,}\S/.test(lines[i]) && items.length && !LIST.test(lines[i])) { items[items.length - 1].inline.push({ t: 'text', v: ' ' + lines[i].trim() }); i++; }
          else break;
        }
        blocks.push({ type: ordered ? 'ol' : 'ul', start, items });
        continue;
      }
      const para = [line];
      i++;
      while (i < lines.length && lines[i].trim() && !isBlockStart(i)) para.push(lines[i++]);
      blocks.push({ type: 'p', inline: parseInline(para.join('\n')) });
    }
    return blocks;
  }

  function inlineTo(doc, parent, nodes) {
    for (const n of nodes) {
      if (n.t === 'text') parent.append(doc.createTextNode(n.v));
      else if (n.t === 'code') { const e = doc.createElement('code'); e.className = 'md-code'; e.textContent = n.v; parent.append(e); }
      else if (n.t === 'b') { const e = doc.createElement('strong'); inlineTo(doc, e, n.c); parent.append(e); }
      else if (n.t === 'i') { const e = doc.createElement('em'); inlineTo(doc, e, n.c); parent.append(e); }
      else if (n.t === 'link') {
        const e = doc.createElement('span'); e.className = 'md-link'; e.textContent = n.v; parent.append(e);
        if (n.href !== n.v) parent.append(doc.createTextNode(' (' + n.href + ')'));
      }
    }
  }

  /** Renders Markdown text into `container` (a DOM element). */
  function render(container, text, doc) {
    doc = doc || document;
    for (const b of parseMarkdown(text)) {
      let e;
      if (b.type === 'code') {
        e = doc.createElement('pre');
        const c = doc.createElement('code');
        c.textContent = b.text;
        if (b.lang) e.setAttribute('data-lang', b.lang);
        e.append(c);
      } else if (b.type === 'heading') {
        e = doc.createElement('div'); e.className = 'md-h md-h' + Math.min(b.level, 4); inlineTo(doc, e, b.inline);
      } else if (b.type === 'hr') e = doc.createElement('hr');
      else if (b.type === 'ul' || b.type === 'ol') {
        e = doc.createElement(b.type);
        if (b.type === 'ol' && b.start !== 1) e.setAttribute('start', String(b.start));
        for (const it of b.items) { const li = doc.createElement('li'); if (it.depth) li.className = 'depth' + it.depth; inlineTo(doc, li, it.inline); e.append(li); }
      } else if (b.type === 'table') {
        const wrap = doc.createElement('div'); wrap.className = 'md-table-wrap';
        const t = doc.createElement('table');
        const head = doc.createElement('thead'); const hr = doc.createElement('tr');
        b.header.forEach((cell, ci) => { const th = doc.createElement('th'); if (b.align[ci]) th.className = 'a-' + b.align[ci]; inlineTo(doc, th, cell); hr.append(th); });
        head.append(hr); t.append(head);
        const body = doc.createElement('tbody');
        for (const row of b.rows) {
          const tr = doc.createElement('tr');
          b.header.forEach((_h, ci) => { const td = doc.createElement('td'); if (b.align[ci]) td.className = 'a-' + b.align[ci]; inlineTo(doc, td, row[ci] || []); tr.append(td); });
          body.append(tr);
        }
        t.append(body); wrap.append(t); e = wrap;
      } else { e = doc.createElement('p'); inlineTo(doc, e, b.inline); }
      container.append(e);
    }
  }

  return { parseMarkdown, parseInline, render };
});
