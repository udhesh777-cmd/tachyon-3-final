'use strict';
// Tachyon speech engine. Runs in its own frame (voice-engine.html) because the speech recognizer (Vosk, WebAssembly)
// needs 'unsafe-eval'; the main window keeps its strict security policy and has the only link to Tachyon itself.
// Audio is processed here and never leaves the computer.
(function () {
  const WAKE_DEFAULT = /\b(?:hey|hi|okay|ok)?\s*(?:tachyon|tachy on|tacky on|tack(?:\s|-)?(?:y\s*)?on|tak(?:i|e)on|tech(?:\s)?on|taken)\b/i;
  let vosk = null;          // loader promise for vendor/vosk.js
  let model = null;         // { key, model }
  let mic = null;           // { stream, ctx, src, proc }
  let rec = null;           // active recognizer
  let mode = 'off';         // 'off' | 'dictate' | 'wake'
  let handlers = {};
  let silenceTimer = null;
  let wakeRe = WAKE_DEFAULT;

  function loadVosk() {
    if (window.Vosk) return Promise.resolve(window.Vosk);
    if (!vosk) {
      vosk = new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = 'vendor/vosk.js';
        s.onload = () => (window.Vosk ? resolve(window.Vosk) : reject(new Error('The speech engine did not load.')));
        s.onerror = () => reject(new Error('The speech engine is missing (vendor/vosk.js).'));
        document.head.append(s);
      }).catch((e) => { vosk = null; throw e; });
    }
    return vosk;
  }

  /** Loads the chosen model once (the recognizer keeps a cached copy, so later starts are fast). */
  async function ensureModel(info) {
    if (!info || !info.id) throw new Error('Choose or download a speech model in Settings → Voice first.');
    const key = `${info.id}@${info.version || 0}`;
    if (model && model.key === key) return model.model;
    if (model) { try { model.model.terminate(); } catch { /* already gone */ } model = null; }
    const V = await loadVosk();
    // The first load unpacks the model into the app's private storage (a few seconds); later loads are quick.
    const m = await Promise.race([
      V.createModel(`tachyon-model://${info.id}/model.tar.gz?v=${info.version || 0}`, -1),
      new Promise((_r, reject) => setTimeout(() => reject(new Error('The speech model could not be loaded. Try removing and adding it again in Settings → Voice.')), 120000)),
    ]);
    m.on('error', (e) => handlers.onError && handlers.onError(new Error(String(e.error || 'speech model error'))));
    model = { key, model: m };
    return m;
  }

  async function openMic() {
    if (mic) return mic;
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 }, video: false });
    const ctx = new AudioContext();
    const src = ctx.createMediaStreamSource(stream);
    const proc = ctx.createScriptProcessor(4096, 1, 1);
    proc.onaudioprocess = (e) => { if (rec) { try { rec.acceptWaveform(e.inputBuffer); } catch { /* recognizer closed */ } } };
    src.connect(proc);
    proc.connect(ctx.destination);
    mic = { stream, ctx, src, proc };
    return mic;
  }
  function closeMic() {
    if (!mic) return;
    try { mic.proc.disconnect(); mic.src.disconnect(); } catch { /* ignore */ }
    mic.stream.getTracks().forEach((t) => t.stop());
    mic.ctx.close().catch(() => {});
    mic = null;
  }
  function dropRecognizer() { if (rec) { try { rec.remove(); } catch { /* ignore */ } rec = null; } }

  function beep(freq = 880) {
    try {
      const c = new AudioContext(); const o = c.createOscillator(); const g = c.createGain();
      o.frequency.value = freq; g.gain.value = 0.06; o.connect(g); g.connect(c.destination); o.start();
      setTimeout(() => { o.stop(); c.close(); }, 120);
    } catch { /* no audio output */ }
  }

  /** Dictation: partial text as you speak, final text after a short pause. */
  async function startDictation(info, h = {}) {
    handlers = h;
    const m = await ensureModel(info);
    const ctx = (await openMic()).ctx;
    dropRecognizer();
    rec = new m.KaldiRecognizer(ctx.sampleRate);
    let finalText = '';
    rec.on('partialresult', (msg) => {
      const p = (msg.result && msg.result.partial) || '';
      if (p) { clearTimeout(silenceTimer); h.onPartial && h.onPartial((finalText + ' ' + p).trim()); }
    });
    rec.on('result', (msg) => {
      const t = (msg.result && msg.result.text) || '';
      if (!t) return;
      finalText = (finalText + ' ' + t).trim();
      h.onPartial && h.onPartial(finalText);
      clearTimeout(silenceTimer);
      silenceTimer = setTimeout(() => { const out = finalText; stop(); h.onFinal && h.onFinal(out); }, h.pauseMs || 1400);
    });
    mode = 'dictate';
    beep(880);
    h.onState && h.onState('listening');
  }

  /** Wake word: listens quietly until it hears "Hey Tachyon" (or your own phrase), then starts dictation. */
  async function startWake(info, phrase, h = {}) {
    const m = await ensureModel(info);
    const ctx = (await openMic()).ctx;
    wakeRe = phrase && phrase.trim() && !/^hey\s+tachyon$/i.test(phrase.trim()) ? new RegExp('\\b' + phrase.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\s+/g, '\\s+') + '\\b', 'i') : WAKE_DEFAULT;
    dropRecognizer();
    rec = new m.KaldiRecognizer(ctx.sampleRate);
    const check = (t) => {
      if (mode !== 'wake' || !wakeRe.test(t)) return;
      const after = t.split(wakeRe).pop().trim();
      h.onWake && h.onWake(after);
    };
    rec.on('partialresult', (msg) => check((msg.result && msg.result.partial) || ''));
    rec.on('result', (msg) => check((msg.result && msg.result.text) || ''));
    mode = 'wake';
    h.onState && h.onState('wake');
  }

  function stop({ keepMic = false } = {}) {
    clearTimeout(silenceTimer);
    dropRecognizer();
    mode = 'off';
    if (!keepMic) closeMic();
    handlers.onState && handlers.onState('off');
  }

  /** Recognizes recorded samples (used by the self-test in Settings). */
  async function recognizeSamples(info, samples, sampleRate) {
    const m = await ensureModel(info);
    const r = new m.KaldiRecognizer(sampleRate);
    const parts = [];
    return new Promise((resolve) => {
      let done = false;
      const finish = () => { if (!done) { done = true; try { r.remove(); } catch { /* ignore */ } resolve(parts.join(' ').trim()); } };
      r.on('result', (msg) => { const t = msg.result && msg.result.text; if (t) parts.push(t); });
      const step = 4096;
      for (let i = 0; i < samples.length; i += step) r.acceptWaveformFloat(samples.subarray(i, i + step), sampleRate);
      r.acceptWaveformFloat(new Float32Array(sampleRate), sampleRate); // a second of silence ends the phrase
      r.retrieveFinalResult();
      setTimeout(finish, 4000);
      r.on('result', () => setTimeout(finish, 300));
    });
  }


  // ---------------------------------------------------------------- messages from the Tachyon window
  const post = (m) => window.parent.postMessage(m, '*');
  const relay = { onPartial: (text) => post({ ev: 'partial', text }), onFinal: (text) => post({ ev: 'final', text }), onState: (st) => post({ ev: 'state', st }), onError: (e) => post({ ev: 'error', message: e.message }) };
  window.addEventListener('message', async (e) => {
    if (e.source !== window.parent) return;
    const m = e.data || {};
    try {
      if (m.cmd === 'dictate') await startDictation(m.info, { ...relay, pauseMs: m.pauseMs });
      else if (m.cmd === 'wake') await startWake(m.info, m.phrase, { ...relay, onWake: (after) => post({ ev: 'wake', after }) });
      else if (m.cmd === 'stop') stop({ keepMic: m.keepMic });
      else if (m.cmd === 'recognize') post({ ev: 'recognized', reqId: m.reqId, text: await recognizeSamples(m.info, m.samples, m.rate) });
    } catch (err) {
      const msg = String((err && (err.name === 'NotAllowedError' || err.name === 'NotFoundError') ? 'No microphone is available or access was refused.' : (err && err.message) || err));
      if (m.cmd === 'recognize') post({ ev: 'recognized', reqId: m.reqId, error: msg });
      else { post({ ev: 'error', message: msg }); post({ ev: 'state', st: 'off' }); }
    }
  });
  post({ ev: 'ready' });
})();
