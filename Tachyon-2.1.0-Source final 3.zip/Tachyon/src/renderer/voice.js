'use strict';
// Tachyon voice (main window side): talks to the speech engine frame (offline speech-to-text) and reads answers aloud
// with the system voices (Windows voices work offline).
(function () {
  const WAKE_DEFAULT = /\b(?:hey|hi|okay|ok)?\s*(?:tachyon|tachy on|tacky on|tack(?:\s|-)?(?:y\s*)?on|tak(?:i|e)on|tech(?:\s)?on|taken)\b/i;
  let frame = null;
  let ready = null;
  let handlers = {};
  let mode = 'off';
  let reqs = 0;
  const pending = new Map();

  function engine() {
    if (ready) return ready;
    ready = new Promise((resolve, reject) => {
      frame = document.createElement('iframe');
      frame.src = 'voice-engine.html';
      frame.allow = 'microphone *'; // file:// pages have no origin to name; the frame's address is fixed above
      frame.title = 'speech engine';
      frame.className = 'voice-engine';
      frame.setAttribute('aria-hidden', 'true');
      const timer = setTimeout(() => reject(new Error('The speech engine did not start.')), 20000);
      window.addEventListener('message', (e) => {
        if (!frame || e.source !== frame.contentWindow) return;
        const m = e.data || {};
        if (m.ev === 'ready') { clearTimeout(timer); resolve(); return; }
        if (m.ev === 'recognized') { const p = pending.get(m.reqId); if (p) { pending.delete(m.reqId); if (m.error) p.reject(new Error(m.error)); else p.resolve(m.text); } return; }
        if (m.ev === 'state') { mode = m.st === 'listening' ? 'dictate' : m.st === 'wake' ? 'wake' : 'off'; handlers.onState && handlers.onState(m.st); return; }
        if (m.ev === 'partial') handlers.onPartial && handlers.onPartial(m.text);
        else if (m.ev === 'final') { mode = 'off'; handlers.onFinal && handlers.onFinal(m.text); }
        else if (m.ev === 'wake') handlers.onWake && handlers.onWake(m.after);
        else if (m.ev === 'error') handlers.onError && handlers.onError(new Error(m.message));
      });
      document.body.append(frame);
    }).catch((e) => { ready = null; if (frame) frame.remove(); frame = null; throw e; });
    return ready;
  }
  const send = async (m) => { await engine(); frame.contentWindow.postMessage(m, '*'); };
  const plain = (info) => ({ id: info.id, version: info.version || 0 });

  async function startDictation(info, h = {}) {
    if (!info) throw new Error('Choose or download a speech model in Settings → Voice first.');
    stopSpeaking();
    handlers = h;
    await send({ cmd: 'dictate', info: plain(info), pauseMs: h.pauseMs || 1400 });
  }
  async function startWake(info, phrase, h = {}) {
    if (!info) throw new Error('Choose or download a speech model in Settings → Voice first.');
    handlers = h;
    await send({ cmd: 'wake', info: plain(info), phrase: phrase || '' });
  }
  function stop({ keepMic = false } = {}) { mode = 'off'; if (frame) frame.contentWindow.postMessage({ cmd: 'stop', keepMic }, '*'); }
  async function recognizeSamples(info, samples, rate) {
    await engine();
    const reqId = ++reqs;
    return new Promise((resolve, reject) => {
      pending.set(reqId, { resolve, reject });
      frame.contentWindow.postMessage({ cmd: 'recognize', reqId, info: plain(info), samples, rate }, '*', [samples.buffer]);
    });
  }

  // ---------------------------------------------------------------- read aloud
  let speakingDone = null;
  function voices() { return window.speechSynthesis ? speechSynthesis.getVoices() : []; }
  function speakText(text, { voiceName = '', rate = 1, onEnd } = {}) {
    if (!window.speechSynthesis) return false;
    speechSynthesis.cancel();
    const plain = String(text).replace(/```[\s\S]*?```/g, ' (code block) ').replace(/\|/g, ' ').replace(/[#*_`>]+/g, ' ').replace(/\s+-\s+/g, ', ');
    const u = new SpeechSynthesisUtterance(plain.slice(0, 6000));
    const v = voiceName && voices().find((x) => x.name === voiceName);
    if (v) { u.voice = v; u.lang = v.lang; }
    u.rate = rate || 1;
    speakingDone = onEnd || null;
    u.onend = u.onerror = () => { const f = speakingDone; speakingDone = null; f && f(); };
    speechSynthesis.speak(u);
    return true;
  }
  function stopSpeaking() { if (window.speechSynthesis) speechSynthesis.cancel(); }

  window.TachyonVoice = { startDictation, startWake, stop, recognizeSamples, speakText, stopSpeaking, voices, get mode() { return mode; }, WAKE_DEFAULT };
})();
