'use strict';
// Tachyon - new workspace pages: Applications, Tools, AI Models, Project Workspace, Task History, Image Generation,
// the collapsible sidebar, the quick-action bar and the chat cards for actions. Uses the helpers from app.js (el, call, toast ...).
// Everything is built with DOM calls and textContent only.

const STATUS_LABEL = { available: 'Available', not_installed: 'Not installed', needs_permission: 'Needs permission', unavailable: 'Unavailable' };
const STATUS_ICON = { available: 'check-circle', not_installed: 'minus-circle', needs_permission: 'lock', unavailable: 'x-circle' };
const STATE_LABEL = { planned: 'Planned', awaiting_approval: 'Awaiting approval', running: 'Running', completed: 'Completed', failed: 'Failed', cancelled: 'Cancelled', partial: 'Partially completed' };
const STATE_ICON = { planned: 'clock', awaiting_approval: 'lock', running: 'loader', completed: 'check-circle', failed: 'x-circle', cancelled: 'minus-circle', partial: 'alert-triangle' };
const CONNECTOR_ICON = { vscode: 'code', browser: 'globe', apps: 'app-window', terminal: 'square-terminal', git: 'git-branch', devcmd: 'terminal', ollama: 'cpu', filesystem: 'folder', system: 'monitor', project: 'briefcase' };
const VERIFY_LABEL = { verified: 'Verified', unverified: 'Not verified', failed: 'Check failed' };
const VERIFY_ICON = { verified: 'check-circle', unverified: 'info', failed: 'x-circle' };

const statusBadge = (st) => el('span', { class: 'status-badge st-' + st }, IC(STATUS_ICON[st] || 'info', 13), ' ' + (STATUS_LABEL[st] || st));
const stateBadge = (st) => el('span', { class: 'status-badge ss-' + st }, IC(STATE_ICON[st] || 'info', 13), ' ' + (STATE_LABEL[st] || st));
const fmtTime = (ts) => new Date(ts).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', second: '2-digit' });

/** Plain-text rendering of what an action returned (command output, project summary, model list ...). */
function resultText(rec) {
  const r = rec && rec.result;
  if (!r || typeof r !== 'object') return '';
  if (r.stdout !== undefined) {
    const head = `$ ${r.command}\nin ${r.cwd}\nexit code: ${r.exitCode}${r.timedOut ? ' (timed out)' : ''}${r.cancelled ? ' (cancelled)' : ''}${r.truncated ? ' (output shortened)' : ''}\n`;
    return head + '\n' + (r.stdout || '') + (r.stderr ? '\n[stderr]\n' + r.stderr : '');
  }
  if (r.models) return `${r.running ? 'Ollama is running' : 'Ollama is not running'} (${r.base})\n` + r.models.map((m) => `- ${m.name}  [${m.kind}]${m.sizeGB ? '  ' + m.sizeGB + ' GB' : ''}`).join('\n');
  if (r.cpus) return `${r.platform} ${r.release} (${r.arch})\nCPU: ${r.cpuModel} (${r.cpus} threads)\nMemory: ${r.freeMemGB} GB free of ${r.totalMemGB} GB\nGPU: ${r.gpu}`;
  if (r.kinds) {
    const sc = Object.entries(r.scripts || {}).map(([k, v]) => `  ${k}: ${v}`).join('\n');
    return `${r.name}  (${r.kinds.join(', ') || 'unknown type'})\n${r.path}\nGit repository: ${r.git ? 'yes' : 'no'}\nREADME: ${r.readme || 'none'}${sc ? '\nScripts:\n' + sc : ''}\n\nTop level:\n${r.files.join('\n')}`;
  }
  if (r.items) return r.items.map((i) => (i.dir ? i.name + '/' : i.name)).join('\n');
  if (r.text !== undefined) return r.text;
  return '';
}

// ---------------------------------------------------------------- running actions from buttons
async function runAction({ connector, op, args = {}, label }) {
  const rec = await call('agent:run', { connector, op, args, label });
  const ok = rec.state === 'completed' || rec.state === 'partial';
  toast((ok ? '' : STATE_LABEL[rec.state] + ': ') + (ok && rec.verification ? rec.verification.evidence : rec.error || STATE_LABEL[rec.state]), ok ? 5000 : 8000);
  if ($('#view-activity').classList.contains('active')) renderActivity();
  return rec;
}
const lastResult = new Map(); // card id -> record, shown under the card

function recordLine(rec) {
  const v = rec.verification;
  return el('div', { class: 'rec-line' + (rec.state === 'failed' ? ' bad' : '') },
    stateBadge(rec.state), ' ',
    el('span', { text: rec.state === 'failed' || rec.state === 'cancelled' ? (rec.error || '') : (v ? v.evidence : '') }),
    v && rec.state === 'completed' ? el('span', { class: 'vbadge v-' + v.status }, IC(VERIFY_ICON[v.status], 12), ' ' + VERIFY_LABEL[v.status]) : null);
}

// ---------------------------------------------------------------- projects (shared state)
const ws = { projects: [], active: null };
async function loadProjects() {
  const d = await call('projects:list');
  ws.projects = d.projects; ws.active = d.active;
  return d;
}
const activeProject = () => ws.projects.find((p) => p.id === ws.active) || ws.projects[0] || null;
function projectPicker(onChange) {
  const sel = el('select', { 'aria-label': 'Project' }, ws.projects.length ? ws.projects.map((p) => el('option', { value: p.id, selected: activeProject() && p.id === activeProject().id }, p.name)) : el('option', { value: '' }, 'No project yet'));
  sel.addEventListener('change', async () => { try { await call('projects:setActive', sel.value); ws.active = sel.value; if (onChange) onChange(); } catch (e) { toast(e.message); } });
  return sel;
}

// ---------------------------------------------------------------- Applications
async function renderApps() {
  const box = $('#appsBody');
  box.replaceChildren(el('p', { class: 'muted', text: 'Looking for installed apps…' }));
  let cards;
  try { [cards] = await Promise.all([call('agent:apps'), loadProjects()]); } catch (e) { box.replaceChildren(el('p', { class: 'bad', text: e.message })); return; }
  const proj = activeProject();
  const head = el('div', { class: 'card row apps-head' },
    el('div', { class: 'grow' }, el('b', { text: 'Click an icon to start an app.' }),
      el('div', { class: 'muted small', text: 'Tachyon checks each launch: it looks for the app’s window and tells you honestly when it cannot confirm. PowerShell and Windows Terminal open only from their button here, never from chat or the AI.' })),
    el('label', { class: 'proj-pick small' }, 'Project ', projectPicker(renderApps)),
    el('button', { onclick: async () => { try { const a = await call('apps:addCustom'); if (a) { toast('Added ' + a.name); renderApps(); } } catch (e) { toast(e.message); } } }, IC('plus', 14), ' Add an app'));
  const grid = el('div', { class: 'card-grid' }, cards.map((c) => appCard(c, proj)));
  box.replaceChildren(head, grid);
}

function appCard(c, proj) {
  const out = el('div', { class: 'app-result small' });
  const shown = lastResult.get(c.id);
  if (shown) out.append(recordLine(shown));
  const run = async (spec, extra = {}) => {
    out.replaceChildren(el('span', { class: 'muted', text: 'Working…' }));
    try {
      let args = { ...(spec.args || {}), ...extra };
      if (spec.needs === 'folder' || spec.needs === 'project') {
        if (!proj) { out.replaceChildren(el('span', { class: 'bad', text: 'Add a project in Project Workspace first; this runs inside a project folder.' })); return; }
        args = { ...args, project: proj.name };
      }
      if (spec.command) args.command = spec.command;
      if (c.custom) args.id = c.customId;
      const rec = await runAction({ connector: spec.connector, op: spec.op, args, label: spec.label ? `${c.label}: ${spec.label}` : `Open ${c.label}` });
      lastResult.set(c.id, rec);
      out.replaceChildren(recordLine(rec));
      if (rec.result && rec.result.stdout !== undefined) out.append(el('pre', { class: 'mini-out', text: (rec.result.stdout || rec.result.stderr || '').trim().slice(0, 600) }));
    } catch (e) { out.replaceChildren(el('span', { class: 'bad', text: e.message })); }
  };
  const usable = c.status === 'available';
  const primaryLabel = c.launch.label || 'Launch';
  const buttons = [el('button', { class: 'primary', disabled: !usable, 'data-tip': usable ? '' : (c.detail || STATUS_LABEL[c.status]), onclick: () => run(c.launch) }, IC(c.launch.command ? 'activity' : 'play', 14), ' ' + primaryLabel)];
  if (c.id === 'chrome') buttons.push(el('button', { disabled: !usable, onclick: async () => { const u = await askText('Web address to open (http or https)', 'https://'); if (u) run(c.launch, { url: u }); } }, IC('link', 14), ' Open a page…'));
  if (c.projectAction) buttons.push(el('button', { disabled: !usable || !proj, 'data-tip': proj ? 'Open the selected project' : 'Add a project first', onclick: () => run(c.projectAction, { project: proj.name }) }, IC('briefcase', 14), ' ' + c.projectAction.label));
  if (c.custom) buttons.push(el('button', { class: 'ghost', 'data-tip': 'Remove from this list', onclick: async () => { await call('apps:removeCustom', c.customId); renderApps(); } }, IC('trash', 14)));
  return el('div', { class: 'app-card' + (usable ? '' : ' dim') },
    el('div', { class: 'app-top' }, el('span', { class: 'app-ico' }, IC(c.icon, 26)), el('div', { class: 'grow' }, el('b', { text: c.label }), statusBadge(c.status))),
    c.detail ? el('div', { class: 'muted small', text: c.detail }) : null,
    el('div', { class: 'row app-actions' }, buttons), out);
}

// ---------------------------------------------------------------- Tools
async function renderTools() {
  const box = $('#toolsBody');
  box.replaceChildren(el('p', { class: 'muted', text: 'Checking what is ready…' }));
  let groups;
  try { groups = await call('agent:tools'); } catch (e) { box.replaceChildren(el('p', { class: 'bad', text: e.message })); return; }
  const panel = el('pre', { class: 'report hidden', id: 'toolOut' });
  box.replaceChildren(
    el('p', { class: 'muted', text: 'Every tool shown as Available has a working backend in this version. The others say why they are not ready.' }),
    ...groups.map((g) => el('div', { class: 'card' }, el('h3', { text: g.label }),
      el('div', { class: 'tool-grid' }, g.items.map((t) => el('div', { class: 'tool' + (t.status === 'available' ? '' : ' dim') },
        el('div', { class: 'row' }, el('b', { class: 'grow', text: t.label }), statusBadge(t.status)),
        t.detail ? el('div', { class: 'muted small', text: t.detail }) : null,
        t.action && t.status === 'available' ? el('button', { class: 'small-btn', onclick: () => toolAction(t, panel) }, t.action.run ? 'Run' : 'Open') : t.action && t.action.view && t.status !== 'available' && (t.status === 'needs_permission' || ['settings', 'models', 'files'].includes(t.action.view)) ? el('button', { class: 'small-btn ghost', onclick: () => showView(t.action.view) }, 'Fix') : null))))),
    panel);
}
async function toolAction(t, panel) {
  const a = t.action;
  if (a.view) { showView(a.view); return; }
  panel.classList.remove('hidden'); panel.textContent = 'Working…';
  try {
    if (a.run.diagnostics) {
      const d = await call('agent:diagnostics');
      panel.textContent = d.map((x) => `${(STATUS_LABEL[x.status] || x.status).padEnd(16)} ${x.label}${x.detail ? '  —  ' + x.detail : ''}`).join('\n');
    } else {
      const rec = await runAction({ connector: a.run.connector, op: a.run.op, args: a.run.args || {}, label: t.label });
      panel.textContent = resultText(rec) || rec.error || '';
    }
  } catch (e) { panel.textContent = e.message; }
}

// ---------------------------------------------------------------- AI Models
async function renderModels() {
  const box = $('#modelsBody');
  box.replaceChildren(el('p', { class: 'muted', text: 'Checking Ollama…' }));
  let m; let hw = null;
  try { m = await call('agent:models'); } catch (e) { box.replaceChildren(el('p', { class: 'bad', text: e.message })); return; }
  try { hw = (await call('agent:run', { connector: 'system', op: 'info', args: {}, label: 'Hardware information' })).result; } catch { /* optional */ }
  const row = (label, slot, note) => el('div', { class: 'model-row' },
    el('span', { class: 'app-ico' }, IC(slot.local ? 'cpu' : 'cloud', 20)),
    el('div', { class: 'grow' }, el('b', { text: label }), el('div', { class: 'small', text: slot.model ? slot.model + (slot.shared ? '  (uses the text model)' : '') : 'Not set' }),
      el('div', { class: 'muted small', text: note })),
    slot.model && slot.ready ? (slot.local ? (slot.installed === true ? statusBadge('available') : slot.installed === false ? statusBadge('not_installed') : statusBadge('unavailable')) : el('span', { class: 'status-badge st-needs_permission' }, IC('cloud', 13), ' Cloud')) : statusBadge('unavailable'));
  const kindBadge = (k) => el('span', { class: 'kind kind-' + k, text: k });
  box.replaceChildren(
    el('div', { class: 'card' },
      el('div', { class: 'row' }, el('b', { class: 'grow', text: 'Ollama (local models)' }),
        el('span', { class: 'status-badge ' + (m.ollama.running ? 'st-available' : 'st-unavailable') }, IC(m.ollama.running ? 'check-circle' : 'x-circle', 13), m.ollama.running ? ' Running' : ' Not running'),
        el('button', { class: 'small-btn', onclick: renderModels }, IC('refresh', 13), ' Refresh')),
      el('div', { class: 'muted small', text: m.ollama.running ? m.ollama.base : (m.ollama.error || 'Start Ollama to use local models.') }),
      el('p', { class: m.offlineReady ? 'ok' : 'muted' }, IC(m.offlineReady ? 'shield-check' : 'info', 15), m.offlineReady ? ' Offline-ready: your text model is installed locally, so chat works with no internet connection.' : ' Offline chat needs a local text model that is installed in Ollama and Ollama running.')),
    el('div', { class: 'card' }, el('h3', { text: 'Your models' }),
      row('Text model', m.text, 'Answers questions, edits files, plans tasks.'),
      row('Vision model', m.vision, 'Reads images and screenshots (needs a vision-capable model).'),
      el('div', { class: 'model-row' }, el('span', { class: 'app-ico' }, IC('package', 20)),
        el('div', { class: 'grow' }, el('b', { text: 'Embedding model' }),
          el('div', { class: 'small', text: m.embedding.length ? m.embedding.map((e) => e.name).join(', ') : 'None installed' }),
          el('div', { class: 'muted small', text: 'Detected and listed. This version has no feature that uses embeddings yet (folder search by meaning is planned for a later stage).' })),
        statusBadge(m.embedding.length ? 'available' : 'unavailable')),
      el('div', { class: 'row' }, el('button', { onclick: () => showView('settings') }, IC('settings', 14), ' Change models in Settings'))),
    el('div', { class: 'card' }, el('h3', { text: 'Installed in Ollama' }),
      m.installed.length ? el('div', { class: 'list' }, m.installed.map((x) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: x.name }), el('span', { class: 'muted small', text: x.sizeGB ? x.sizeGB + ' GB' : '' })), kindBadge(x.kind))))
        : el('p', { class: 'muted', text: m.ollama.running ? 'No models are installed yet.' : 'Ollama is not running, so the list is unavailable.' }),
      el('p', { class: 'muted small', text: 'Tachyon never downloads models by itself. To add one, run “ollama pull <name>” yourself. The kind (text / vision / embedding) is guessed from the model name.' })),
    hw ? el('div', { class: 'card' }, el('h3', { text: 'This computer' }), el('pre', { class: 'report', text: resultText({ result: hw }) }),
      el('p', { class: 'muted small', text: 'Rule of thumb: a model needs roughly its file size in free memory. Small 3B models run on most PCs; 7B+ models want 8 GB or more of free memory.' })) : null);
}

// ---------------------------------------------------------------- Project Workspace
const projState = { out: null, lastCmdRec: null };
async function renderProjects() {
  const box = $('#projectsBody');
  box.replaceChildren(el('p', { class: 'muted', text: 'Loading projects…' }));
  try { await loadProjects(); } catch (e) { box.replaceChildren(el('p', { class: 'bad', text: e.message })); return; }
  const proj = activeProject();
  const list = el('div', { class: 'proj-list' }, ws.projects.map((p) => el('div', { class: 'proj-chip' + (proj && p.id === proj.id ? ' active' : '') },
    el('button', { class: 'proj-name', onclick: async () => { await call('projects:setActive', p.id); ws.active = p.id; projState.out = null; renderProjects(); } }, IC('briefcase', 14), ' ' + p.name),
    el('button', { class: 'ghost small-btn', 'data-tip': 'Remove from this list (files are not touched)', onclick: async () => { await call('projects:remove', p.id); renderProjects(); } }, IC('x', 13)))));
  const addBtn = el('button', { class: 'primary', onclick: async () => { try { const p = await call('projects:add'); if (p) { toast('Added ' + p.name); renderProjects(); } } catch (e) { toast(e.message); } } }, IC('plus', 14), ' Add a project folder');
  if (!proj) {
    box.replaceChildren(el('div', { class: 'card' }, el('p', { text: 'A project is a folder you want Tachyon to work on. Add one to open it in VS Code, check its Git status, run its tests and edit its files, all inside folders you granted.' }), addBtn));
    return;
  }
  const out = el('pre', { class: 'report proj-out', id: 'projOut', text: projState.out ? projState.out.text : 'Pick an action above. Results appear here.' });
  const explain = el('button', { class: 'small-btn', disabled: !(projState.lastCmdRec && projState.lastCmdRec.result && projState.lastCmdRec.result.stdout !== undefined), onclick: async (e) => {
    e.currentTarget.disabled = true; out.textContent += '\n\nAsking your text model to explain this output…';
    try { const r = await call('agent:analyze', { id: projState.lastCmdRec.id }); out.textContent = resultText(projState.lastCmdRec) + '\n\n----- Explanation -----\n' + r.text; } catch (err) { out.textContent += '\n' + err.message; }
    e.currentTarget.disabled = false;
  } }, IC('sparkles', 13), ' Explain this output');
  const act = (label, icon, spec, tip) => el('button', { 'data-tip': tip || '', onclick: async () => {
    out.textContent = 'Working…';
    try {
      const rec = await runAction({ connector: spec.connector, op: spec.op, args: { ...(spec.args || {}), project: proj.name }, label: `${label} — ${proj.name}` });
      projState.lastCmdRec = rec;
      projState.out = { text: (STATE_LABEL[rec.state] + (rec.verification ? ' — ' + rec.verification.evidence : rec.error ? ' — ' + rec.error : '')) + '\n\n' + resultText(rec) };
      if (spec.op === 'inspect' && rec.result) projState.inspect = rec.result;
      renderProjects();
    } catch (e) { out.textContent = e.message; }
  } }, IC(icon, 14), ' ' + label);
  const files = projState.inspect && projState.inspect.path === proj.path ? projState.inspect.files.filter((f) => !f.endsWith('/')) : [];
  box.replaceChildren(
    el('div', { class: 'card row' }, list, addBtn),
    el('div', { class: 'card' },
      el('div', { class: 'row' }, el('b', { class: 'grow', text: proj.name }), el('span', { class: 'muted small', text: proj.path })),
      el('div', { class: 'group-label', text: 'Open' }),
      el('div', { class: 'row wrap' },
        act('VS Code', 'code', { connector: 'vscode', op: 'open' }), act('File Explorer', 'folder-open', { connector: 'apps', op: 'openExplorer' }),
        act('PowerShell', 'terminal', { connector: 'terminal', op: 'openPowerShell' }, 'Opens a PowerShell window in this folder'),
        act('Windows Terminal', 'square-terminal', { connector: 'terminal', op: 'openWindowsTerminal' }, 'Opens Windows Terminal in this folder')),
      el('div', { class: 'group-label', text: 'Inspect' }),
      el('div', { class: 'row wrap' }, act('Project summary', 'search', { connector: 'project', op: 'inspect' }),
        act('Git status', 'git-branch', { connector: 'git', op: 'read', args: { command: 'git.status' } }), act('Git branch', 'git-branch', { connector: 'git', op: 'read', args: { command: 'git.branch' } }),
        act('Git log', 'history', { connector: 'git', op: 'read', args: { command: 'git.log' } }), act('Git changes', 'file-text', { connector: 'git', op: 'read', args: { command: 'git.diffStat' } })),
      el('div', { class: 'group-label', text: 'Run (fixed list, no free-form commands)' }),
      el('div', { class: 'row wrap' },
        act('Python version', 'activity', { connector: 'devcmd', op: 'version', args: { command: 'python.version' } }), act('Node version', 'activity', { connector: 'devcmd', op: 'version', args: { command: 'node.version' } }),
        act('npm test', 'play', { connector: 'devcmd', op: 'test', args: { command: 'npm.test' } }, 'Asks first: this starts the project’s own test code'),
        act('pytest', 'play', { connector: 'devcmd', op: 'test', args: { command: 'python.pytest' } }, 'Asks first'), act('unittest', 'play', { connector: 'devcmd', op: 'test', args: { command: 'python.unittest' } }, 'Asks first'))),
    el('div', { class: 'card' }, el('div', { class: 'row' }, el('b', { class: 'grow', text: 'Result' }), explain), out),
    files.length ? el('div', { class: 'card' }, el('h3', { text: 'Files in this project' }),
      el('p', { class: 'muted small', text: 'Edit opens the built-in editor: ask the AI for a change, review it, then Save. The previous version is always kept as a .nova-bak backup.' }),
      el('div', { class: 'list' }, files.map((f) => { const full = proj.path + state.sep + f; return el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: f })),
        isText(f) ? el('button', { onclick: () => openEditor({ path: full, name: f }) }, IC('pencil', 14), ' Edit') : null,
        READABLE(f) ? el('button', { onclick: () => attachFile({ path: full, name: f }) }, IC('message-square', 14), ' Ask AI') : null); }))) : null);
}

// ---------------------------------------------------------------- Task History
async function renderActivity() {
  const box = $('#activityBody');
  let rows; let cmds;
  try { [rows, cmds] = await Promise.all([call('agent:activity', { limit: 100 }), call('agent:history')]); } catch (e) { box.replaceChildren(el('p', { class: 'bad', text: e.message })); return; }
  box.replaceChildren(
    el('div', { class: 'row' }, el('p', { class: 'muted grow', text: 'What Tachyon did for you, in order, and how each action was checked. Stored only on this computer.' }),
      el('button', { onclick: renderActivity }, IC('refresh', 14), ' Refresh'),
      el('button', { class: 'ghost', onclick: async () => { await call('agent:activityClear'); await call('agent:historyClear'); renderActivity(); } }, IC('trash', 14), ' Clear')),
    rows.length ? el('div', { class: 'list' }, rows.map((r) => el('details', { class: 'act' },
      el('summary', {}, stateBadge(r.state), el('b', { text: ' ' + (r.label || r.connector + '.' + r.op) }), el('span', { class: 'muted small', text: `  ·  ${new Date(r.ts).toLocaleString()}  ·  from ${r.source === 'ui' ? 'a button' : r.source}` })),
      el('div', { class: 'act-body small' },
        r.target ? el('div', { text: r.target }) : null,
        r.verification ? el('div', {}, el('span', { class: 'vbadge v-' + r.verification.status }, IC(VERIFY_ICON[r.verification.status], 12), ' ' + VERIFY_LABEL[r.verification.status]), ' ' + r.verification.evidence) : null,
        r.error ? el('div', { class: 'bad', text: r.error }) : null,
        el('ol', { class: 'act-steps' }, (r.steps || []).map((s) => el('li', {}, el('b', { text: STATE_LABEL[s.state] || s.state }), ' ' + fmtTime(s.ts) + (s.note ? ' — ' + s.note : '')))),
        resultText(r) ? el('pre', { class: 'report', text: resultText(r).slice(0, 4000) }) : null))))
      : el('div', { class: 'card' }, el('p', { class: 'muted', text: 'Nothing yet. Try “Open VS Code” in the chat or click an app in Applications.' })),
    cmds.length ? el('div', { class: 'card' }, el('h3', { text: 'Command history' }),
      el('div', { class: 'list' }, cmds.slice(0, 30).map((c) => el('div', { class: 'item' }, el('div', { class: 'name' }, el('b', { text: c.command }), el('span', { class: 'muted small', text: `${c.cwd}  ·  ${new Date(c.ts).toLocaleString()}` })),
        el('span', { class: 'status-badge ' + (c.exitCode === 0 ? 'ss-completed' : 'ss-failed') }, 'exit ' + (c.exitCode === null ? '—' : c.exitCode)))))) : null);
}

// ---------------------------------------------------------------- Image Generation
function renderImagePage() {
  const box = $('#imageBody');
  const on = state.s && state.s.imageBackend && state.s.imageBackend !== 'none';
  const prompt = el('textarea', { rows: 3, placeholder: 'Describe the picture, e.g. a glowing blue jellyfish in deep space', 'aria-label': 'Image prompt' });
  box.replaceChildren(el('div', { class: 'card' },
    el('div', { class: 'row' }, el('b', { class: 'grow', text: 'Image backend' }), statusBadge(on ? 'available' : 'unavailable')),
    el('p', { class: 'muted small', text: on ? 'Backend: ' + state.s.imageBackend + '. Pictures are drawn by that service and saved in Tachyon’s own folder.' : 'No image backend is set. Choose one (for example a local Automatic1111 or InvokeAI) in Settings → Images.' }),
    on ? [prompt, el('div', { class: 'row' }, el('button', { class: 'primary', onclick: () => { const t = prompt.value.trim(); if (!t) { toast('Describe the picture first.'); return; } showView('chat'); $('#input').value = '/image ' + t; send(); } }, IC('image', 14), ' Generate'))]
      : el('button', { class: 'primary', onclick: () => showView('settings') }, IC('settings', 14), ' Open Settings')));
}

window.TachyonViews = { apps: renderApps, tools: renderTools, models: renderModels, projects: renderProjects, activity: renderActivity, image: renderImagePage };

// ---------------------------------------------------------------- chat: action cards
function agentCard(m) {
  const a = m.agent;
  const rec = a.record;
  const live = ['planned', 'awaiting_approval', 'running'].includes(rec.state);
  const v = rec.verification;
  const out = resultText(rec);
  return el('div', { class: 'agent-card ss-card-' + rec.state },
    el('div', { class: 'row' }, el('span', { class: 'app-ico sm' }, IC(CONNECTOR_ICON[rec.connector] || 'activity', 18)), el('b', { class: 'grow', text: rec.label || rec.connector + '.' + rec.op }), stateBadge(rec.state)),
    el('ol', { class: 'act-steps compact' }, (rec.steps || []).map((s) => el('li', {}, STATE_LABEL[s.state] || s.state, s.note && s.state !== 'planned' ? el('span', { class: 'muted', text: ' — ' + s.note }) : null))),
    v ? el('div', { class: 'verify v-' + v.status }, IC(VERIFY_ICON[v.status], 15), el('b', { text: ' ' + VERIFY_LABEL[v.status] + ': ' }), v.evidence) : null,
    rec.error && !v ? el('div', { class: 'bad', text: rec.error }) : null,
    out ? el('details', { class: 'out-details', open: out.length < 400 }, el('summary', { text: 'Output' }), el('pre', { class: 'report', text: out.slice(0, 6000) })) : null,
    el('div', { class: 'msg-actions' },
      live ? el('button', { onclick: () => call('agent:cancel', rec.id).catch((e) => toast(e.message)) }, IC('square', 13), ' Cancel') : null,
      !live && rec.result && rec.result.stdout !== undefined ? el('button', { onclick: async (e) => {
        e.currentTarget.disabled = true;
        try { const r = await call('agent:analyze', { id: rec.id }); state.conv.messages.push({ role: 'assistant', content: r.text, note: true, ts: Date.now() }); renderMessages(); saveConv(); } catch (err) { toast(err.message); e.currentTarget.disabled = false; }
      } }, IC('sparkles', 13), ' Explain this output') : null,
      out && navigator.clipboard ? el('button', { onclick: () => navigator.clipboard.writeText(out).then(() => toast('Copied')) }, IC('copy', 13), ' Copy output') : null));
}

function proposalCard(m) {
  const p = m.proposal;
  return el('div', { class: 'agent-card ss-card-awaiting_approval' },
    el('div', { class: 'row' }, el('span', { class: 'app-ico sm' }, IC(CONNECTOR_ICON[p.connector] || 'activity', 18)), el('b', { class: 'grow', text: 'Proposed action: ' + p.label }), stateBadge(p.status || 'awaiting_approval')),
    p.explain ? el('div', { text: p.explain }) : null,
    el('div', { class: 'muted small', text: (p.project ? 'Project: ' + p.project + '. ' : '') + 'The model only chose this from Tachyon’s list of allowed actions. Nothing has run yet; permissions still apply when you approve.' }),
    p.status === 'awaiting_approval' || !p.status ? el('div', { class: 'msg-actions' },
      el('button', { class: 'primary', onclick: () => approveProposal(m) }, IC('check', 14), ' Approve and run'),
      el('button', { onclick: async () => { p.status = 'cancelled'; try { await call('agent:reject', { id: p.id }); } catch { /* gone */ } renderMessages(); saveConv(); } }, IC('x', 14), ' Cancel')) : null);
}

async function approveProposal(m) {
  const p = m.proposal;
  p.status = 'running'; renderMessages();
  trackLive(m);
  try {
    const rec = await call('agent:approve', { id: p.id });
    delete m.proposal; m.agent = { record: rec }; m.content = '';
  } catch (e) { p.status = 'failed'; m.content = e.message; }
  stopLive(); renderMessages(); saveConv();
}

// live updates: the card of the running action follows the activity events
let liveMsg = null;
function trackLive(m) { liveMsg = m; }
function stopLive() { liveMsg = null; }
if (window.nova && window.nova.onAgentActivity) {
  window.nova.onAgentActivity((rec) => {
    if (liveMsg && rec.source !== 'ui') { liveMsg.agent = { record: rec }; delete liveMsg.proposal; renderMessages(); }
    if ($('#view-activity').classList.contains('active')) renderActivity();
  });
}

/** A sentence from the chat. Returns true when it was an agent command (handled here). */
async function handleAgentChat(text) {
  if (/^\/do(\s|$)/i.test(text)) { await runDo(text); return true; }
  if (!window.TachyonAgentIntent.parseAgentCommand(text)) return false; // ordinary chat: no card, no flicker
  let r;
  state.conv.messages.push({ role: 'user', content: text, note: true, ts: Date.now() });
  const reply = { role: 'assistant', note: true, content: '', ts: Date.now() };
  $('#input').value = ''; autoGrow();
  try {
    // Show a working card straight away, then let the live events fill it in.
    state.conv.messages.push(reply);
    trackLive(reply);
    state.busy = true; renderMessages();
    r = await call('agent:chat', { text });
  } catch (e) { r = { handled: true, message: e.message }; }
  state.busy = false; stopLive();
  if (!r.handled) { state.conv.messages.splice(state.conv.messages.indexOf(reply) - 1, 2); renderMessages(); return false; }
  if (r.record) reply.agent = { record: r.record }; else reply.content = r.message || '';
  renderMessages(); saveConv();
  return true;
}

async function runDo(text) {
  state.conv.messages.push({ role: 'user', content: text, note: true, ts: Date.now() });
  $('#input').value = ''; autoGrow();
  state.busy = true; renderMessages();
  const reply = { role: 'assistant', note: true, content: '', ts: Date.now() };
  try {
    const r = await call('agent:propose', { text });
    if (r.proposal) reply.proposal = { ...r.proposal, status: 'awaiting_approval' }; else reply.content = r.message;
  } catch (e) { reply.content = e.message; reply.error = true; }
  state.conv.messages.push(reply);
  state.busy = false; renderMessages(); saveConv();
}
function cancelLive() { if (liveMsg && liveMsg.agent && liveMsg.agent.record) call('agent:cancel', liveMsg.agent.record.id).catch(() => {}); }
window.TachyonAgent = { handleChat: handleAgentChat, card: agentCard, proposal: proposalCard, cancelLive };

// ---------------------------------------------------------------- model badge (offline / local indicator)
async function refreshModelBadge() {
  const b = $('#modelBadge');
  if (!b || !state.s) return;
  let txt; let ico; let cls;
  const t = state.s.models.text;
  if (!t.model) { txt = 'No model set'; ico = 'alert-triangle'; cls = 'warn'; }
  else if (t.provider === 'cloud') { txt = `Cloud: ${t.model} (needs internet)`; ico = 'cloud'; cls = 'cloud'; }
  else {
    try {
      const m = await call('agent:models');
      if (!m.ollama.running) { txt = 'Ollama not running'; ico = 'alert-triangle'; cls = 'warn'; }
      else if (m.text.installed === false) { txt = `${t.model} is not installed in Ollama`; ico = 'alert-triangle'; cls = 'warn'; }
      else { txt = `Local: ${t.model} · works offline`; ico = 'shield-check'; cls = 'local'; }
    } catch { txt = 'Local model: status unknown'; ico = 'info'; cls = 'warn'; }
  }
  b.className = 'model-badge mb-' + cls;
  b.replaceChildren(IC(ico, 14), ' ' + txt);
  b.onclick = () => showView('models');
}
window.refreshModelBadge = refreshModelBadge;

// ---------------------------------------------------------------- sidebar, quick actions, start-up
function applySidebar() {
  const collapsed = Boolean(state.s && state.s.sidebarCollapsed);
  $('#app').classList.toggle('collapsed', collapsed);
  $('#collapseBtn').setAttribute('aria-expanded', String(!collapsed));
}
window.applySidebar = applySidebar;
$('#collapseBtn').addEventListener('click', async () => {
  if (!state.s) return;
  state.s.sidebarCollapsed = !state.s.sidebarCollapsed; applySidebar();
  try { await call('settings:save', { settings: { sidebarCollapsed: state.s.sidebarCollapsed } }); } catch { /* cosmetic */ }
});
$('#navHistory').addEventListener('click', () => {
  if (state.s && state.s.sidebarCollapsed) { state.s.sidebarCollapsed = false; applySidebar(); call('settings:save', { settings: { sidebarCollapsed: false } }).catch(() => {}); }
  $('#convSearch').focus();
});

async function quickAction(qa) {
  const say = async (text) => { showView('chat'); $('#input').value = text; await send(); };
  if (qa === 'vscode') return say(activeProject() || ws.projects.length ? 'open my project in vs code' : 'open vs code');
  if (qa === 'browser') { const u = await askText('Web address to open (http or https)', 'https://'); if (u) say('go to ' + u); return; }
  if (qa === 'explorer') return say('open file explorer');
  if (qa === 'projects') return showView('projects');
  if (qa === 'image') { showView('chat'); $('#input').value = '/image '; $('#input').focus(); return; }
  if (qa === 'task') { showView('chat'); $('#input').value = '/task '; $('#input').focus(); return; }
  if (qa === 'help') return say('/help');
}
$$('#quickbar .qa').forEach((b) => b.addEventListener('click', () => {
  if (!ws.projects.length) loadProjects().catch(() => {}).then(() => quickAction(b.dataset.qa)); else quickAction(b.dataset.qa);
}));

window.TachyonIcons.hydrate(document);
if (state.s) { applySidebar(); refreshModelBadge(); }
loadProjects().catch(() => {});
setInterval(() => { if ($('#view-chat').classList.contains('active') && !document.hidden) refreshModelBadge(); }, 60000);
