'use strict';
// End-to-end tests of the agent layer: chat sentence -> intent -> registry -> permission -> execution -> verification -> history.
// Programs are MOCK (a fake spawn and fake executables on a temporary PATH); the logic around them is real.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const Agent = require('../src/core/agent');
const { parseAgentCommand } = require('../src/renderer/agentIntent');

const tmp = () => fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'tachyon-agent-')));
const exe = (dir, name) => { fs.mkdirSync(path.dirname(path.join(dir, name)), { recursive: true }); fs.writeFileSync(path.join(dir, name), '#!/bin/sh\n', { mode: 0o755 }); return path.join(dir, name); };

function fakeSpawn(script = { exit: 0 }) {
  const calls = [];
  const spawn = (file, args, opts) => {
    const c = new EventEmitter(); c.stdout = new EventEmitter(); c.stderr = new EventEmitter(); c.pid = 777; c.unref = () => {}; c.kill = () => setImmediate(() => c.emit('close', null));
    calls.push({ file, args, opts });
    setImmediate(() => {
      c.emit('spawn');
      if (script.stdout) c.stdout.emit('data', Buffer.from(script.stdout));
      if (script.stderr) c.stderr.emit('data', Buffer.from(script.stderr));
      if (script.exit !== undefined) { c.emit('exit', script.exit); c.emit('close', script.exit); }
    });
    return c;
  };
  spawn.calls = calls;
  return spawn;
}

function setup({ withCode = true, spawnScript, guard, windows } = {}) {
  const root = tmp(); const user = tmp(); const bin = path.join(root, 'bin'); fs.mkdirSync(bin);
  const code = withCode ? exe(bin, 'code') : null;
  const gitExe = exe(bin, 'git'); const node = exe(bin, 'node'); exe(bin, 'node_modules/npm/bin/npm-cli.js'); exe(bin, 'python3');
  const project = path.join(root, 'demo'); fs.mkdirSync(project);
  fs.writeFileSync(path.join(project, 'package.json'), JSON.stringify({ name: 'demo', scripts: { test: 'node t.js' } }));
  let settings = { models: { text: { provider: 'local', host: '127.0.0.1', port: '11434', model: 'qwen2.5:3b' }, vision: { mode: 'same' } }, folders: [root], projects: [], customApps: [], imageBackend: 'none', permissions: {} };
  const spawn = fakeSpawn(spawnScript);
  const asked = [];
  const agent = Agent.create({
    userData: user, platform: 'linux', env: { PATH: bin, HOME: user }, spawn, roots: () => settings.folders,
    getSettings: () => settings, saveSettings: (p) => { settings = { ...settings, ...p }; return settings; },
    guard: guard || (async (cat, target) => { asked.push([cat, target]); }),
    listWindows: windows === undefined ? async () => [{ app: 'Code', title: 'demo - Visual Studio Code' }] : windows,
    fetch: async () => ({ ok: true, json: async () => ({ models: [{ name: 'qwen2.5:3b' }, { name: 'nomic-embed-text' }] }) }),
  });
  return { agent, root, user, bin, code, gitExe, node, project, spawn, asked, settings: () => settings };
}

test('VERTICAL SLICE: “Open VS Code” -> validate -> permission -> launch -> verify -> report -> history', async () => {
  const t = setup();
  const r = await t.agent.chat('Open VS Code');
  assert.equal(r.handled, true);
  const rec = r.record;
  assert.equal(rec.state, 'completed', rec.error);
  assert.deepEqual(rec.steps.map((s) => s.state), ['planned', 'awaiting_approval', 'running', 'completed']);
  assert.equal(rec.verification.status, 'verified');
  assert.equal(t.spawn.calls[0].file, t.code); assert.deepEqual(t.spawn.calls[0].args, []); assert.equal(t.spawn.calls[0].opts.shell, false);
  assert.deepEqual(t.asked[0][0], 'apps.open');
  const hist = t.agent.activity.list();
  assert.equal(hist.length, 1); assert.equal(hist[0].op, 'open'); assert.equal(hist[0].source, 'chat');
});

test('opening a project: unknown project gives a clear message; added project opens as an argument', async () => {
  const t = setup();
  assert.match((await t.agent.chat('open my project in VS Code')).message, /add a project folder/i);
  const proj = t.agent.addProject(t.project, 'Demo App');
  assert.equal(proj.id, 'demo-app');
  assert.match((await t.agent.chat('open nothing-here in vs code')).message, /do not know a project/);
  const r = await t.agent.chat('open my project in VS Code');
  assert.equal(r.record.state, 'completed');
  assert.deepEqual(t.spawn.calls.at(-1).args, [t.project]);
  const r2 = await t.agent.chat('open demo app in vs code');
  assert.deepEqual(t.spawn.calls.at(-1).args, [t.project]); assert.equal(r2.record.state, 'completed');
});

test('VS Code not installed: honest failure, nothing spawned', async () => {
  const t = setup({ withCode: false });
  const r = await t.agent.chat('open vscode');
  assert.equal(r.record.state, 'failed'); assert.match(r.record.error, /not installed/);
  assert.equal(t.spawn.calls.length, 0);
  const cards = await t.agent.apps();
  assert.equal(cards.find((c) => c.id === 'vscode').status, 'not_installed');
});

test('no window found: launch is reported as unverified, not as success', async () => {
  const t = setup({ windows: async () => [] });
  const old = Date.now;
  const r = await t.agent.run({ connector: 'vscode', op: 'open', args: {}, source: 'ui' });
  assert.equal(r.state, 'completed'); assert.equal(r.verification.status, 'unverified'); assert.match(r.verification.evidence, /no window showed up/);
  void old;
});

test('shells: chat refuses; the model cannot see them; only a UI call reaches the terminal connector', async () => {
  const t = setup();
  for (const s of ['open powershell', 'launch windows terminal', 'open cmd', 'run the command dir in cmd']) {
    const r = await t.agent.chat(s);
    assert.equal(r.refused, true, s); assert.match(r.message, /Applications/);
  }
  const direct = await t.agent.run({ connector: 'terminal', op: 'openPowerShell', args: { cwd: t.project }, source: 'chat' });
  assert.match(direct.error, /clicking its button/);
  assert.equal(t.spawn.calls.length, 0);
});

test('git status runs read-only in the project; permission category is commands.read', async () => {
  const t = setup({ spawnScript: { stdout: '## main\n', exit: 0 } });
  t.agent.addProject(t.project);
  const r = await t.agent.chat('git status');
  assert.equal(r.record.state, 'completed'); assert.match(r.record.result.stdout, /main/);
  assert.equal(t.spawn.calls[0].file, t.gitExe); assert.equal(t.spawn.calls[0].opts.cwd, t.project);
  assert.equal(t.asked[0][0], 'commands.read');
  assert.equal(t.agent.history.list().length, 1);
  assert.equal(t.agent.getRecord(r.record.id).id, r.record.id);
});

test('“run the tests” picks npm test from package.json, asks via commands.run, runs through node + npm-cli.js', async () => {
  const t = setup({ spawnScript: { stdout: 'ok\n', exit: 0 } });
  t.agent.addProject(t.project);
  const r = await t.agent.chat('run the tests');
  assert.equal(r.record.state, 'completed', r.record.error);
  const q = t.asked.find((a) => a[0] === 'commands.run');
  assert.ok(q, 'the user is asked before tests run'); assert.match(q[1], /npm test/);
  const c = t.spawn.calls[0];
  assert.equal(c.file, t.node); assert.match(c.args[0], /npm-cli\.js$/); assert.deepEqual(c.args.slice(1), ['test']); assert.equal(c.opts.shell, false);
});

test('declining the permission dialog cancels the action before anything runs', async () => {
  const t = setup({ guard: async (cat) => { if (cat === 'commands.run') throw new Error('Cancelled. Nothing was changed.'); } });
  t.agent.addProject(t.project);
  const r = await t.agent.chat('run the tests');
  assert.equal(r.record.state, 'cancelled');
  assert.equal(t.spawn.calls.length, 0);
});

test('failing tests are reported as failed with the exit code and the output is kept for “Explain this output”', async () => {
  const t = setup({ spawnScript: { stdout: '1 failing\n', stderr: 'AssertionError\n', exit: 1 } });
  t.agent.addProject(t.project);
  const r = await t.agent.chat('run npm test');
  assert.equal(r.record.state, 'failed'); assert.match(r.record.error, /code 1/);
  assert.match(t.agent.getRecord(r.record.id).result.stderr, /AssertionError/);
});

test('projects: must be inside granted folders, no duplicates, can be removed; default project is the active one', () => {
  const t = setup();
  assert.throws(() => t.agent.addProject(tmp()), /not inside a folder you granted/);
  assert.throws(() => t.agent.addProject(path.join(t.root, 'nope')), /does not exist/);
  const a = t.agent.addProject(t.project);
  assert.throws(() => t.agent.addProject(t.project), /already/);
  const other = path.join(t.root, 'other'); fs.mkdirSync(other);
  const b = t.agent.addProject(other, 'Other');
  assert.equal(t.agent.findProject('my project').id, a.id);
  assert.equal(t.agent.findProject('other').id, b.id);
  assert.equal(t.agent.findProject('xyz'), null);
  t.agent.removeProject(a.id);
  assert.deepEqual(t.agent.projects().map((p) => p.id), ['other']);
});

test('custom apps: need an existing .exe/file, shells refused, can be launched and removed', async () => {
  const t = setup();
  const tool = exe(t.root, 'MyTool');
  assert.throws(() => t.agent.addCustomApp('relative.exe'), /program file/);
  assert.throws(() => t.agent.addCustomApp(path.join(t.root, 'missing')), /program file/);
  const sh = exe(t.root, 'powershell'); assert.throws(() => t.agent.addCustomApp(sh), /Shells/);
  const a = t.agent.addCustomApp(tool, 'My Tool');
  const cards = await t.agent.apps();
  assert.ok(cards.find((c) => c.customId === a.id && c.status === 'available'));
  const rec = await t.agent.run({ connector: 'apps', op: 'launchCustom', args: { id: a.id }, source: 'ui' });
  assert.equal(rec.state, 'completed'); assert.equal(t.spawn.calls.at(-1).file, tool);
  t.agent.removeCustomApp(a.id);
  assert.equal((await t.agent.apps()).some((c) => c.customId === a.id), false);
});

test('launcher cards: the required apps are present with truthful statuses; Never in permissions shows Needs Permission', async () => {
  const t = setup();
  const cards = await t.agent.apps();
  assert.deepEqual(cards.map((c) => c.id), ['vscode', 'chrome', 'explorer', 'powershell', 'wt', 'git', 'python']);
  assert.equal(cards.find((c) => c.id === 'vscode').status, 'available');
  assert.equal(cards.find((c) => c.id === 'chrome').status, 'not_installed');
  assert.equal(cards.find((c) => c.id === 'powershell').status, 'unavailable', 'non-Windows platform');
  t.settings().permissions['apps.open'] = 'deny';
  assert.equal((await t.agent.apps()).find((c) => c.id === 'vscode').status, 'needs_permission');
});

test('tools workspace: 7 groups, valid statuses, nothing without a backend is shown as Available', async () => {
  const t = setup();
  const groups = await t.agent.tools();
  assert.equal(groups.length, 7);
  const ok = new Set(['available', 'not_installed', 'needs_permission', 'unavailable']);
  const all = groups.flatMap((g) => g.items);
  for (const i of all) assert.ok(ok.has(i.status), `${i.id}: ${i.status}`);
  const by = (id) => all.find((i) => i.id === id);
  assert.equal(by('indexing').status, 'unavailable'); assert.equal(by('nav').status, 'unavailable'); assert.equal(by('inspect').status, 'unavailable');
  assert.equal(by('embedding-model').status, 'unavailable'); assert.equal(by('image').status, 'unavailable');
  assert.equal(by('vscode').status, 'available'); assert.equal(by('hardware').status, 'available');
  t.settings().folders.length = 0;
  assert.equal((await t.agent.tools()).flatMap((g) => g.items).find((i) => i.id === 'search').status, 'needs_permission');
});

test('model status: Ollama running, models classified, never downloads; offline-ready needs the model installed', async () => {
  const t = setup();
  const m = await t.agent.modelStatus();
  assert.equal(m.ollama.running, true); assert.equal(m.text.installed, true); assert.equal(m.offlineReady, true);
  assert.deepEqual(m.embedding.map((x) => x.name), ['nomic-embed-text']);
  assert.equal(m.vision.shared, true);
});

test('intent parser: sentences that are normal chat are left alone', () => {
  for (const s of ['tell me a joke', 'open notepad', 'what is git?', 'run the numbers for Q3', 'open report.pdf', 'explain what a project is', '/task open vs code']) assert.equal(parseAgentCommand(s), null, s);
});

test('activity history persists and can be cleared', async () => {
  const t = setup();
  await t.agent.chat('open vs code'); await t.agent.chat('open vs code');
  assert.equal(t.agent.activity.list(10).length, 2);
  t.agent.activity.clear();
  assert.equal(t.agent.activity.list(10).length, 0);
});
