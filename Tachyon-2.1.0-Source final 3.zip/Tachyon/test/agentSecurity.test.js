'use strict';
// Static security and consistency checks for the Tachyon 2.1 additions (connectors, IPC, window, renderer).
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');

const SRC = path.join(__dirname, '..', 'src');
const read = (p) => fs.readFileSync(path.join(SRC, p), 'utf8');
const walk = (d, out = []) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) { if (e.name !== 'vendor') walk(p, out); } else out.push(p); } return out; };

test('every IPC channel registered in main.js is allowed in preload.js, and vice versa', () => {
  const main = read('main.js');
  const registered = new Set([...main.matchAll(/handle\('([a-zA-Z]+:[a-zA-Z]+)'/g)].map((m) => m[1]));
  const pre = read('preload.js');
  const allowed = new Set([...pre.slice(pre.indexOf('new Set(['), pre.indexOf(']);')).matchAll(/'([a-zA-Z]+:[a-zA-Z]+)'/g)].map((m) => m[1]));
  const missingInPreload = [...registered].filter((c) => !allowed.has(c));
  const unusedInPreload = [...allowed].filter((c) => !registered.has(c));
  assert.deepEqual(missingInPreload.filter((c) => !/^(overlay|capture)/.test(c)), [], 'registered but not reachable from the window');
  assert.deepEqual(unusedInPreload, [], 'allowed in preload but nothing handles it');
  for (const c of ['agent:run', 'agent:chat', 'agent:propose', 'agent:approve', 'projects:add', 'apps:addCustom']) assert.ok(allowed.has(c), c);
});

test('window hardening: context isolation, sandbox, no node, strict CSP without inline code', () => {
  const main = read('main.js');
  assert.match(main, /contextIsolation: true, nodeIntegration: false, sandbox: true, webSecurity: true/);
  assert.match(main, /setWindowOpenHandler\(\(\) => \(\{ action: 'deny' \}\)\)/);
  assert.match(main, /will-navigate/); assert.match(main, /will-attach-webview/);
  const html = read('renderer/index.html');
  const csp = /Content-Security-Policy" content="([^"]+)"/.exec(html)[1];
  assert.ok(!/unsafe-inline|unsafe-eval|\*/.test(csp), csp);
  assert.match(csp, /default-src 'none'/); assert.match(csp, /script-src 'self'/);
  assert.ok(!/<script(?![^>]*\bsrc=)[^>]*>/.test(html), 'no inline scripts'); assert.ok(!/\sstyle="/.test(html), 'no inline styles'); assert.ok(!/\son[a-z]+="/.test(html), 'no inline handlers');
});

test('handle() refuses requests that do not come from Tachyon’s own file:// pages', () => {
  const main = read('main.js');
  assert.match(main, /startsWith\('file:\/\/'\)\) throw new Error\('Blocked request\.'\)/);
});

test('connectors never use a shell or string commands', () => {
  for (const f of walk(path.join(SRC, 'core', 'connectors'))) {
    const t = fs.readFileSync(f, 'utf8');
    assert.ok(!/\bexec\(|execSync|spawnSync|shell:\s*true/.test(t), f);
    assert.ok(!/require\('child_process'\)\.exec\b/.test(t), f);
  }
  const launch = fs.readFileSync(path.join(SRC, 'core', 'connectors', 'util.js'), 'utf8');
  assert.match(launch, /shell: false/);
});

test('new renderer code builds the DOM with createElement/createElementNS, never innerHTML or eval', () => {
  for (const f of ['renderer/workspace.js', 'renderer/icons.js', 'renderer/agentIntent.js']) {
    const t = read(f);
    assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write|\beval\(|new Function/.test(t), f);
  }
});

test('no hard-coded user names or drive-specific profile paths in the source', () => {
  for (const f of walk(SRC)) {
    if (!/\.(js|html)$/.test(f)) continue;
    const t = fs.readFileSync(f, 'utf8').split('\n').filter((l) => !/^\s*(\*|\/\/|\/\*)/.test(l)).join('\n'); // comments may use example paths
    assert.ok(!/C:\\\\?Users\\\\?[A-Za-z0-9_.-]+\\\\?(AppData|Desktop|Documents)/i.test(t.replace(/\$\{[^}]*\}/g, '')), f);
    assert.ok(!/\/home\/[a-z0-9_-]+\//i.test(t), f);
  }
});

test('shell-like commands stay blocked for app opening and have no connector', () => {
  const C = require('../src/core/computer');
  for (const n of ['powershell', 'cmd', 'windows terminal', 'wt', 'bash', 'wsl', 'regedit']) assert.equal(C.blocked(n), true, n);
  const { createRegistry } = require('../src/core/connectors');
  const reg = createRegistry({ platform: 'linux', env: {}, roots: () => [] });
  const ops = reg.catalog({ forModel: true }).map((o) => `${o.connector}.${o.op}`);
  assert.ok(!ops.some((o) => /terminal|shell|powershell|exec|run\b/.test(o)), ops.join());
});

test('the runner allowlist has only fixed, non-destructive commands', () => {
  const R = require('../src/core/connectors/runner');
  const bad = /push|commit|reset|clean|checkout|rm\b|del\b|install|publish|remove|format|curl|wget|pip|-c\s|eval/i;
  for (const [id, c] of Object.entries(R.COMMANDS)) {
    assert.ok(!bad.test(id), id);
    const args = c.args({});
    assert.ok(args.every((a) => typeof a === 'string'), id);
    assert.ok(!args.includes('-c') || args[0] === '-c' && args[1] === 'core.fsmonitor=false', id + ' must not pass code on the command line');
  }
});

test('settings keys from the window cannot write projects or custom apps directly', () => {
  const main = read('main.js');
  const keys = /const SETTING_KEYS = \[([\s\S]*?)\];/.exec(main)[1];
  assert.ok(!/customApps|projects|activeProject/.test(keys));
});

test('permissions: new categories exist; test runs and sending can never be set to Always', () => {
  const P = require('../src/core/permissions');
  for (const k of ['commands.read', 'commands.run', 'browser.open', 'terminal.open']) assert.ok(P.CATEGORIES[k], k);
  assert.equal(P.effective({ permissions: { 'commands.run': 'allow', send: 'allow' } })['commands.run'], 'ask');
  assert.equal(P.sanitize({ 'commands.run': 'allow' })['commands.run'], 'ask');
});
