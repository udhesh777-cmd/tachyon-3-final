'use strict';
// Connector framework tests. Programs and the Windows file system are replaced by small fakes (MOCK) so the logic can be
// checked anywhere; real launching of VS Code / Chrome / Ollama can only be confirmed on a Windows PC (see docs/TEST-REPORT.md).
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const { validate } = require('../src/core/connectors/schema');
const { createRegistry, ConnectorRegistry } = require('../src/core/connectors');
const U = require('../src/core/connectors/util');
const R = require('../src/core/connectors/runner');
const T = require('../src/core/connectors/tools');

const tmp = () => fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'tachyon-conn-')));

/** MOCK child process. */
function fakeSpawn(script = {}) {
  const calls = [];
  const spawn = (exe, args, opts) => {
    const c = new EventEmitter();
    c.stdout = new EventEmitter(); c.stderr = new EventEmitter(); c.pid = 4242; c.killed = false;
    c.kill = () => { c.killed = true; setImmediate(() => c.emit('close', null)); };
    c.unref = () => {};
    calls.push({ exe, args, opts, child: c });
    setImmediate(() => {
      if (script.error) { c.emit('error', new Error(script.error)); return; }
      c.emit('spawn');
      if (script.hang) return;
      if (script.stdout) c.stdout.emit('data', Buffer.from(script.stdout));
      if (script.stderr) c.stderr.emit('data', Buffer.from(script.stderr));
      if (script.exit !== undefined) { c.emit('exit', script.exit); c.emit('close', script.exit); }
    });
    return c;
  };
  spawn.calls = calls;
  return spawn;
}

/** MOCK Windows file system: only the listed files exist. */
function fakeWinFs(files) {
  const set = new Set(files.map((f) => f.toLowerCase()));
  return {
    statSync: (p) => { if (!set.has(String(p).toLowerCase())) throw new Error('ENOENT'); return { isFile: () => true, isDirectory: () => false }; },
    readdirSync: () => { throw new Error('ENOENT'); },
  };
}
const WIN_ENV = { LOCALAPPDATA: 'C:\\Users\\Someone\\AppData\\Local', ProgramFiles: 'C:\\Program Files', 'ProgramFiles(x86)': 'C:\\Program Files (x86)', SystemRoot: 'C:\\Windows', PATH: '' };

function ctxFor(root, extra = {}) {
  return { platform: 'linux', env: { PATH: '/usr/bin:/bin' }, roots: () => [root], guard: async () => {}, ...extra };
}

// ------------------------------------------------------------------ schema
test('schema: types, required, enum, extra properties, length, NUL', () => {
  const s = { type: 'object', additionalProperties: false, required: ['a'], properties: { a: { type: 'string', maxLength: 3 }, n: { type: 'integer', minimum: 1, maximum: 5 }, e: { enum: ['x', 'y'] } } };
  assert.deepEqual(validate(s, { a: 'abc' }), []);
  assert.ok(validate(s, {}).some((e) => /required/.test(e)));
  assert.ok(validate(s, { a: 'abcd' }).some((e) => /too long/.test(e)));
  assert.ok(validate(s, { a: 'a', z: 1 }).some((e) => /not allowed/.test(e)));
  assert.ok(validate(s, { a: 'a', n: 9 }).length);
  assert.ok(validate(s, { a: 'a', n: 1.5 }).length);
  assert.ok(validate(s, { a: 'a', e: 'q' }).length);
  assert.ok(validate(s, { a: 'a\0' }).length);
  assert.ok(validate(s, 'text').length);
});

// ------------------------------------------------------------------ registry
test('registry: refuses bad connector definitions and duplicates', () => {
  const r = new ConnectorRegistry({});
  assert.throws(() => r.register({ id: 'Bad Id', operations: {} }));
  assert.throws(() => r.register({ id: 'x', operations: {} }));
  assert.throws(() => r.register({ id: 'x', operations: { a: { execute() {}, schema: { type: 'object' } } } }), /category/);
  r.register({ id: 'x', operations: { a: { execute() { return 1; }, schema: { type: 'object' }, category: 'status' } } });
  assert.throws(() => r.register({ id: 'x', operations: { a: { execute() {}, schema: { type: 'object' }, category: 'status' } } }), /already/);
});

test('registry: unknown connector / operation / prototype names never reach a connector', async () => {
  const reg = createRegistry(ctxFor(tmp()));
  for (const [c, o] of [['nope', 'open'], ['vscode', 'format_disk'], ['vscode', '__proto__'], ['vscode', 'constructor'], ['git', 'toString']]) {
    const rec = await reg.execute({ connector: c, op: o, args: {} });
    assert.equal(rec.state, 'failed', `${c}.${o}`);
    assert.match(rec.error, /Unknown connector|no operation/);
  }
});

test('registry: state transitions, permission refusal and audit record', async () => {
  const log = []; const seen = [];
  const r = new ConnectorRegistry({ guard: async (cat) => { if (cat === 'blocked') throw new Error('Blocked by your permission settings'); }, log: (x) => log.push(x), emit: (x) => seen.push(x.state) });
  r.register({ id: 't', operations: {
    ok: { schema: { type: 'object' }, category: 'status', execute: () => ({ v: 1 }), verify: () => ({ status: 'verified', evidence: 'yes' }) },
    no: { schema: { type: 'object' }, category: 'blocked', execute: () => { throw new Error('should not run'); } },
  } });
  const a = await r.execute({ connector: 't', op: 'ok', args: {} });
  assert.equal(a.state, 'completed'); assert.equal(a.verification.status, 'verified');
  assert.deepEqual(a.steps.map((s) => s.state), ['planned', 'awaiting_approval', 'running', 'completed']);
  const b = await r.execute({ connector: 't', op: 'no', args: {} });
  assert.equal(b.state, 'failed'); assert.match(b.error, /Blocked by your permission/);
  assert.equal(log.length, 2);
  assert.ok(seen.includes('running'));
});

test('registry: timeout and cancel stop a running action', async () => {
  const r = new ConnectorRegistry({});
  r.register({ id: 't', operations: {
    slow: { schema: { type: 'object' }, category: 'status', timeoutMs: 60, execute: (a, c, { signal }) => new Promise((res, rej) => { signal.addEventListener('abort', () => rej(new Error('aborted'))); }) },
    long: { schema: { type: 'object' }, category: 'status', timeoutMs: 5000, execute: (a, c, { signal }) => new Promise((res, rej) => { signal.addEventListener('abort', () => rej(new Error('aborted'))); }) },
  } });
  const t = await r.execute({ connector: 't', op: 'slow', args: {} });
  assert.equal(t.state, 'failed'); assert.match(t.error, /Timed out/);
  const p = r.execute({ connector: 't', op: 'long', args: {} });
  await new Promise((s) => setTimeout(s, 30));
  const id = [...r.running.keys()][0];
  assert.equal(r.cancelAction(id), true);
  const c = await p;
  assert.equal(c.state, 'cancelled');
  assert.equal(r.cancelAction('nothing'), false);
});

test('registry: UI-only operations (shells) cannot be started from chat or a model', async () => {
  const dir = tmp();
  const reg = createRegistry(ctxFor(dir));
  const chat = await reg.execute({ connector: 'terminal', op: 'openPowerShell', args: { cwd: dir }, source: 'chat' });
  assert.equal(chat.state, 'failed'); assert.match(chat.error, /clicking its button/);
  const model = await reg.execute({ connector: 'terminal', op: 'openWindowsTerminal', args: { cwd: dir }, source: 'model' });
  assert.match(model.error, /clicking its button/);
  assert.ok(!reg.catalog({ forModel: true }).some((o) => o.connector === 'terminal'), 'the model never sees shell operations');
  assert.ok(reg.catalog().some((o) => o.connector === 'terminal' && o.uiOnly));
});

// ------------------------------------------------------------------ path authorization
test('authorizedPath: inside ok; outside, relative, traversal and symlink escape rejected', () => {
  const root = tmp(); const outside = tmp();
  fs.mkdirSync(path.join(root, 'sub')); fs.writeFileSync(path.join(outside, 'secret.txt'), 'x');
  const ctx = ctxFor(root);
  assert.equal(U.authorizedPath(ctx, root), root);
  assert.equal(U.authorizedPath(ctx, path.join(root, 'sub')), path.join(root, 'sub'));
  assert.throws(() => U.authorizedPath(ctx, outside), /not inside a folder you granted/);
  assert.throws(() => U.authorizedPath(ctx, path.join(root, '..', path.basename(outside))), /not inside/);
  assert.throws(() => U.authorizedPath(ctx, 'relative/path'), /full path/);
  assert.throws(() => U.authorizedPath(ctx, path.join(root, 'missing')), /does not exist/);
  assert.throws(() => U.authorizedPath(ctx, root + 'evil'), /./);
  fs.symlinkSync(outside, path.join(root, 'link'));
  assert.throws(() => U.authorizedPath(ctx, path.join(root, 'link', 'secret.txt')), /not inside/);
  assert.throws(() => U.authorizedPath({ ...ctx, roots: () => [] }, root), /not inside/);
});

// ------------------------------------------------------------------ discovery (MOCK Windows)
test('discovery builds Windows paths from environment variables, with no fixed user name', () => {
  const code = 'C:\\Users\\Someone\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe';
  const ctx = { platform: 'win32', env: WIN_ENV, fs: fakeWinFs([code]) };
  assert.equal(U.findVsCode(ctx), code);
  assert.equal(U.findChrome(ctx), null);
  const env2 = { ...WIN_ENV, LOCALAPPDATA: 'D:\\Profiles\\Other\\Local' };
  const code2 = 'D:\\Profiles\\Other\\Local\\Programs\\Microsoft VS Code\\Code.exe';
  assert.equal(U.findVsCode({ platform: 'win32', env: env2, fs: fakeWinFs([code2]) }), code2);
  assert.equal(U.findVsCode({ platform: 'win32', env: {}, fs: fakeWinFs([]) }), null);
  const src = fs.readFileSync(path.join(__dirname, '../src/core/connectors/util.js'), 'utf8');
  assert.ok(!/C:\\\\Users\\\\[A-Za-z]/.test(src), 'no hardcoded user folder');
});

test('npm is run through node + npm-cli.js, never through a shell', () => {
  const node = 'C:\\Program Files\\nodejs\\node.exe'; const cli = 'C:\\Program Files\\nodejs\\node_modules\\npm\\bin\\npm-cli.js';
  const ctx = { platform: 'win32', env: WIN_ENV, fs: fakeWinFs([node, cli]) };
  assert.equal(U.findNpmCli(ctx), cli);
  assert.equal(U.findNpmCli({ ...ctx, fs: fakeWinFs([node]) }), null);
});

// ------------------------------------------------------------------ VS Code vertical slice (MOCK launch)
test('vscode.open: validates, launches with an argument array and no shell, verifies the window', async () => {
  const root = tmp(); const spawn = fakeSpawn({});
  const logs = [];
  const ctx = ctxFor(root, { spawn, listWindows: async () => [{ app: 'Code', title: 'proj - Visual Studio Code' }], log: (r) => logs.push(r) });
  ctx.platform = 'linux'; ctx.env.PATH = path.join(root, 'bin'); fs.mkdirSync(path.join(root, 'bin')); fs.writeFileSync(path.join(root, 'bin', 'code'), '#!/bin/sh\n', { mode: 0o755 });
  const reg = createRegistry(ctx);
  const rec = await reg.execute({ connector: 'vscode', op: 'open', args: { path: root } });
  assert.equal(rec.state, 'completed', rec.error);
  assert.equal(rec.verification.status, 'verified'); assert.match(rec.verification.evidence, /Visual Studio Code is open/);
  assert.equal(spawn.calls.length, 1);
  assert.deepEqual(spawn.calls[0].args, [root]); assert.equal(spawn.calls[0].opts.shell, false);
  assert.equal(logs.length, 1);
});

test('vscode.open: path outside granted folders is rejected before anything starts', async () => {
  const root = tmp(); const other = tmp(); const spawn = fakeSpawn({});
  const ctx = ctxFor(root, { spawn }); ctx.env.PATH = path.join(root, 'bin'); fs.mkdirSync(path.join(root, 'bin')); fs.writeFileSync(path.join(root, 'bin', 'code'), 'x', { mode: 0o755 });
  const rec = await createRegistry(ctx).execute({ connector: 'vscode', op: 'open', args: { path: other } });
  assert.equal(rec.state, 'failed'); assert.match(rec.error, /not inside a folder you granted/);
  assert.equal(spawn.calls.length, 0);
});

test('vscode.open: reports honestly when VS Code is missing or no window appears', async () => {
  const root = tmp();
  const missing = await createRegistry(ctxFor(root)).execute({ connector: 'vscode', op: 'open', args: {} });
  assert.equal(missing.state, 'failed'); assert.match(missing.error, /not installed/);
  const ctx = ctxFor(root, { spawn: fakeSpawn({}), listWindows: async () => [] });
  ctx.env.PATH = path.join(root, 'bin'); fs.mkdirSync(path.join(root, 'bin')); fs.writeFileSync(path.join(root, 'bin', 'code'), 'x', { mode: 0o755 });
  const { verifyLaunch } = require('../src/core/connectors/launchers');
  const v = await (async () => { const c = { ...ctx, listWindows: async () => [] }; const p = verifyLaunch(c, 'Visual Studio Code', ['Code'], { pid: 1, exited: false }); return p; })();
  assert.equal(v.status, 'unverified'); assert.match(v.evidence, /no window showed up/);
  const nocheck = await verifyLaunch({}, 'X', ['x'], { pid: 7 });
  assert.equal(nocheck.status, 'unverified');
});

// ------------------------------------------------------------------ browser
test('browser.open: only http/https, no credentials, bare domains get https', async () => {
  const reg = createRegistry(ctxFor(tmp()));
  for (const bad of ['javascript:alert(1)', 'file:///C:/Windows/win.ini', 'ftp://x.example/a', 'https://user:pw@example.com/', 'data:text/html,hi', 'http://']) {
    const v = await reg.validateAction('browser', 'open', { url: bad });
    assert.equal(v.ok, false, bad);
  }
  const ok = await reg.validateAction('browser', 'open', { url: 'example.com/docs' });
  assert.equal(ok.ok, true); assert.equal(ok.args.url, 'https://example.com/docs');
});

test('browser.open: falls back to the default browser (unverified) when Chrome is absent', async () => {
  const opened = [];
  const rec = await createRegistry(ctxFor(tmp(), { openExternal: async (u) => opened.push(u) })).execute({ connector: 'browser', op: 'open', args: { url: 'https://example.com' } });
  assert.equal(rec.state, 'completed'); assert.equal(rec.verification.status, 'unverified');
  assert.deepEqual(opened, ['https://example.com/']);
});

// ------------------------------------------------------------------ runner
test('runner: only allowlisted ids; cwd must be granted; fixed args; no shell; secrets stay out of the environment', async () => {
  const root = tmp(); const spawn = fakeSpawn({ stdout: '## main\n', exit: 0 });
  const bin = path.join(root, 'bin'); fs.mkdirSync(bin); fs.writeFileSync(path.join(bin, 'git'), 'x', { mode: 0o755 });
  const ctx = ctxFor(root, { spawn, env: { PATH: bin, OPENAI_API_KEY: 'sk-secret', GITHUB_TOKEN: 'ghp_x', HOME: '/home/u' } });
  await assert.rejects(R.runCommand(ctx, 'rm -rf /', root), /not an approved command/);
  await assert.rejects(R.runCommand(ctx, 'git.push', root), /not an approved command/);
  await assert.rejects(R.runCommand(ctx, 'git.status', tmp()), /not inside a folder you granted/);
  const r = await R.runCommand(ctx, 'git.status', root);
  assert.equal(r.exitCode, 0); assert.match(r.stdout, /main/);
  const call = spawn.calls[0];
  assert.equal(call.opts.shell, false);
  assert.deepEqual(call.args, ['-c', 'core.fsmonitor=false', 'status', '--short', '--branch']);
  assert.equal(call.opts.env.OPENAI_API_KEY, undefined); assert.equal(call.opts.env.GITHUB_TOKEN, undefined);
  assert.equal(call.opts.env.GIT_TERMINAL_PROMPT, '0');
  assert.equal(Object.keys(R.COMMANDS).filter((k) => /push|commit|reset|clean|checkout|rm|install|publish/.test(k)).length, 0);
});

test('runner: reports a missing program and a missing package.json clearly', async () => {
  const root = tmp();
  await assert.rejects(R.runCommand(ctxFor(root, { env: { PATH: '' } }), 'git.status', root), /not installed/);
  const bin = path.join(root, 'bin'); fs.mkdirSync(bin); fs.writeFileSync(path.join(bin, 'node'), 'x', { mode: 0o755 });
  const ctx = ctxFor(root, { env: { PATH: bin } });
  await assert.rejects(R.runCommand(ctx, 'npm.test', root), /No package.json/);
});

test('runner: timeout kills the process; cancel kills it; output is capped', async () => {
  const root = tmp(); const bin = path.join(root, 'bin'); fs.mkdirSync(bin); fs.writeFileSync(path.join(bin, 'git'), 'x', { mode: 0o755 });
  const hang = fakeSpawn({ hang: true });
  const t = await R.runCommand(ctxFor(root, { spawn: hang, env: { PATH: bin } }), 'git.log', root, { timeoutMs: 40 });
  assert.equal(t.timedOut, true); assert.equal(hang.calls[0].child.killed, true);
  const hang2 = fakeSpawn({ hang: true }); const ac = new AbortController();
  const p = R.runCommand(ctxFor(root, { spawn: hang2, env: { PATH: bin } }), 'git.log', root, { signal: ac.signal });
  setTimeout(() => ac.abort(), 20);
  const c = await p;
  assert.equal(c.cancelled, true);
  const big = fakeSpawn({ stdout: 'x'.repeat(R.MAX_OUT * 3), exit: 0 });
  const b = await R.runCommand(ctxFor(root, { spawn: big, env: { PATH: bin } }), 'git.log', root);
  assert.equal(b.truncated, true); assert.ok(b.stdout.length <= R.MAX_OUT);
});

test('devcmd.test is a separate permission category that always asks; git.read is read-only', () => {
  const reg = createRegistry(ctxFor(tmp()));
  const P = require('../src/core/permissions');
  assert.equal(reg.get('devcmd').operations.test.category, 'commands.run');
  assert.equal(P.CATEGORIES['commands.run'].noAllow, true);
  assert.equal(P.effective({ permissions: { 'commands.run': 'allow' } })['commands.run'], 'ask');
  assert.equal(reg.get('git').operations.read.category, 'commands.read');
  const e = reg.get('git').operations.read.schema.properties.command.enum;
  assert.deepEqual(e.sort(), ['git.branch', 'git.diffStat', 'git.log', 'git.status']);
});

test('git.read through the registry: failing command is reported as failed with evidence', async () => {
  const root = tmp(); const bin = path.join(root, 'bin'); fs.mkdirSync(bin); fs.writeFileSync(path.join(bin, 'git'), 'x', { mode: 0o755 });
  const spawn = fakeSpawn({ stderr: 'fatal: not a git repository\n', exit: 128 });
  const hist = []; const reg = createRegistry(ctxFor(root, { spawn, env: { PATH: bin }, history: { add: (r) => hist.push(r) } }));
  const rec = await reg.execute({ connector: 'git', op: 'read', args: { command: 'git.status', cwd: root } });
  assert.equal(rec.state, 'failed'); assert.match(rec.error, /code 128/); assert.equal(hist.length, 1);
  const bad = await reg.execute({ connector: 'git', op: 'read', args: { command: 'git.push', cwd: root } });
  assert.equal(bad.state, 'failed'); assert.match(bad.error, /one of/);
});

test('RunHistory keeps summaries and clears', () => {
  const dir = tmp(); const h = new R.RunHistory(dir);
  h.add({ id: 'git.status', command: 'git status', cwd: '/x', exitCode: 0, durationMs: 5, stdout: 'ok', stderr: '' });
  assert.equal(h.list().length, 1); assert.equal(h.list()[0].command, 'git status');
  h.clear(); assert.equal(h.list().length, 0);
});

// ------------------------------------------------------------------ ollama, filesystem, project
test('ollama: model kinds are classified; status uses the given fetch (MOCK) and never downloads', async () => {
  assert.equal(T.classifyModel({ name: 'nomic-embed-text:latest' }), 'embedding');
  assert.equal(T.classifyModel({ name: 'qwen2.5vl:3b' }), 'vision');
  assert.equal(T.classifyModel({ name: 'llava:7b' }), 'vision');
  assert.equal(T.classifyModel({ name: 'qwen2.5:3b' }), 'text');
  const urls = [];
  const f = async (u) => { urls.push(u); return { ok: true, json: async () => ({ models: [{ name: 'qwen2.5:3b', size: 1.9e9 }, { name: 'bge-m3', size: 1e9 }] }) }; };
  const rec = await createRegistry(ctxFor(tmp(), { fetch: f, ollamaBase: () => 'http://127.0.0.1:11434' })).execute({ connector: 'ollama', op: 'status', args: {} });
  assert.equal(rec.state, 'completed'); assert.equal(rec.result.models.length, 2);
  assert.deepEqual(urls, ['http://127.0.0.1:11434/api/tags']);
  const down = await createRegistry(ctxFor(tmp(), { fetch: async () => { throw new Error('ECONNREFUSED'); } })).execute({ connector: 'ollama', op: 'status', args: {} });
  assert.equal(down.state, 'failed'); assert.match(down.error, /not running/);
});

test('filesystem + project: read inside granted folders only; binary refused; project summary', async () => {
  const root = tmp(); fs.writeFileSync(path.join(root, 'a.txt'), 'hello'); fs.writeFileSync(path.join(root, 'b.bin'), Buffer.from([1, 0, 2]));
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ name: 'demo', version: '1.2.3', scripts: { test: 'node t.js', build: 'x' } })); fs.mkdirSync(path.join(root, '.git'));
  const reg = createRegistry(ctxFor(root));
  const ls = await reg.execute({ connector: 'filesystem', op: 'list', args: { path: root } });
  assert.equal(ls.state, 'completed'); assert.ok(ls.result.items.some((i) => i.name === 'a.txt'));
  assert.equal((await reg.execute({ connector: 'filesystem', op: 'read', args: { path: path.join(root, 'a.txt') } })).result.text, 'hello');
  assert.match((await reg.execute({ connector: 'filesystem', op: 'read', args: { path: path.join(root, 'b.bin') } })).error, /binary/);
  assert.match((await reg.execute({ connector: 'filesystem', op: 'read', args: { path: path.join(os.tmpdir()) } })).error, /not inside|not a file/);
  const pr = await reg.execute({ connector: 'project', op: 'inspect', args: { path: root } });
  assert.equal(pr.state, 'completed'); assert.deepEqual(pr.result.kinds, ['Node.js']); assert.equal(pr.result.git, true); assert.equal(pr.result.hasTestScript, true);
});

test('system.info reads hardware from the OS', async () => {
  const rec = await createRegistry(ctxFor(tmp())).execute({ connector: 'system', op: 'info', args: {} });
  assert.equal(rec.state, 'completed'); assert.ok(rec.result.cpus >= 1); assert.ok(rec.result.totalMemGB > 0);
});

test('terminal ops (button): need Windows, a granted folder, and refuse chat', async () => {
  const dir = tmp();
  const lin = await createRegistry(ctxFor(dir)).execute({ connector: 'terminal', op: 'openPowerShell', args: { cwd: dir }, source: 'ui' });
  assert.match(lin.error, /Windows only/);
});

test('apps.launchCustom: unknown id, missing file and shell executables are refused', async () => {
  const root = tmp(); const exe = path.join(root, 'tool.exe'); fs.writeFileSync(exe, 'x');
  const sh = path.join(root, 'powershell.exe'); fs.writeFileSync(sh, 'x');
  const apps = [{ id: 'tool', name: 'My Tool', path: exe }, { id: 'ps', name: 'PS', path: sh }, { id: 'gone', name: 'Gone', path: path.join(root, 'gone.exe') }];
  const spawn = fakeSpawn({});
  const reg = createRegistry(ctxFor(root, { settings: () => ({ customApps: apps }), spawn }));
  assert.match((await reg.execute({ connector: 'apps', op: 'launchCustom', args: { id: 'zzz' } })).error, /not in your Applications/);
  assert.match((await reg.execute({ connector: 'apps', op: 'launchCustom', args: { id: 'gone' } })).error, /was not found/);
  assert.match((await reg.execute({ connector: 'apps', op: 'launchCustom', args: { id: 'ps' } })).error, /Shells/);
  assert.equal((await reg.execute({ connector: 'apps', op: 'launchCustom', args: { id: 'tool', _app: { exe: '/bin/sh' } } })).state, 'failed', 'a model cannot smuggle its own executable');
  const ok = await reg.execute({ connector: 'apps', op: 'launchCustom', args: { id: 'tool' } });
  assert.equal(ok.state, 'completed'); assert.equal(spawn.calls[0].exe, exe);
});

test('which: PATH is split with the host separator, so Windows drive letters survive (regression: CI on windows-latest)', () => {
  const real = Object.getOwnPropertyDescriptor(process, 'platform');
  const want = path.join('D:\\a\\bin', 'git');
  const fakeFs = { statSync: (p) => { if (p === want) return { isFile: () => true, isDirectory: () => false }; throw new Error('ENOENT'); } };
  Object.defineProperty(process, 'platform', { value: 'win32' });
  try { assert.equal(U.which({ platform: 'linux', env: { PATH: 'C:\\Windows;D:\\a\\bin' }, fs: fakeFs }, 'git'), want); }
  finally { Object.defineProperty(process, 'platform', real); }
});
