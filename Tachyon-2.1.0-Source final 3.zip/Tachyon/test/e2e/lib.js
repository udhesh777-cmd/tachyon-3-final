'use strict';
// Shared helpers for the end-to-end checks: mock Ollama servers, app launch with an isolated profile, check counter.
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
// Needs Playwright: npm i --no-save playwright  (or set PLAYWRIGHT to its folder). Run on Linux under xvfb-run.
const { _electron: electron } = require(process.env.PLAYWRIGHT || 'playwright');

function mockServer(name, handler) {
  const log = [];
  const srv = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      if (req.url === '/api/tags') { res.end(JSON.stringify({ models: [{ name: name === 'text' ? 'qwen2.5:latest' : 'qwen2.5vl:3b' }] })); return; }
      if (req.url === '/api/chat') {
        const j = JSON.parse(body);
        log.push(j);
        const content = handler(j);
        res.end(JSON.stringify({ message: { role: 'assistant', content } }));
        return;
      }
      res.statusCode = 404; res.end('{}');
    });
  });
  return new Promise((r) => srv.listen(0, '127.0.0.1', () => r({ srv, log, port: srv.address().port })));
}

const lastUser = (j) => [...j.messages].reverse().find((m) => m.role === 'user') || { content: '' };
const sysOf = (j) => (j.messages.find((m) => m.role === 'system') || { content: '' }).content;

function textHandler(j) {
  const u = lastUser(j).content;
  const sys = sysOf(j);
  const ed = /Editable files:\n- (.+)/.exec(sys);
  if (ed && /OUTSIDE/.test(u)) return `Done.\n<<<NOVA_EDIT path="/etc/hostname-not-allowed.txt">>>\nhack\n<<<END_EDIT>>>`;
  if (ed && /\b(fix|edit|change|update|correct|replace)\b/i.test(u)) return `Fixed it.\n<<<NOVA_EDIT path="${ed[1].trim()}">>>\nedited by model\n<<<END_EDIT>>>`;
  if (/^Instruction:/.test(u)) return 'edited by model';
  if (/table/i.test(u)) return 'Comparison below.\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n- point one\n- point two\n\n1. step one\n2. step two\n\n```js\nconsole.log(1)\n```';
  return 'TEXT-MODEL answer to: ' + u.replace(/\s+/g, ' ').slice(-80);
}
function visionHandler(j) {
  const u = lastUser(j).content;
  if (/colour/i.test(u)) return 'Red';
  return 'VISION-MODEL sees the image. Text found: HELLO';
}

function makeProfile(textPort, visionPort, extra = {}) {
  const base = fs.mkdtempSync(path.join(os.tmpdir(), 'e2e-'));
  const cfg = path.join(base, 'config');
  const work = path.join(base, 'work');
  const docs = path.join(base, 'Documents');
  fs.mkdirSync(work, { recursive: true }); fs.mkdirSync(docs, { recursive: true });
  fs.mkdirSync(cfg, { recursive: true });
  fs.writeFileSync(path.join(cfg, 'user-dirs.dirs'), 'XDG_DOCUMENTS_DIR="$HOME/Documents"\nXDG_DESKTOP_DIR="$HOME/Desktop"\n');
  return { base, cfg, work, docs, settings: {
    models: {
      text: { provider: 'local', preset: 'custom', baseUrl: '', model: 'qwen2.5', host: '127.0.0.1', port: String(textPort) },
      vision: { provider: 'local', preset: 'custom', baseUrl: '', model: 'qwen2.5vl:3b', host: '127.0.0.1', port: String(visionPort), mode: 'separate' },
    },
    timeoutSec: 30, systemPrompt: 'CUSTOM-RULE-XYZ', folders: [work], overlayEnabled: true, ...extra,
  } };
}

async function launch(appDir, prof, userDataName, extraArgs = []) {
  const ud = path.join(prof.cfg, userDataName);
  fs.mkdirSync(ud, { recursive: true });
  if (prof.settings) fs.writeFileSync(path.join(ud, 'settings.json'), JSON.stringify(prof.settings));
  const app = await electron.launch({
    executablePath: require(path.resolve(appDir, 'node_modules/electron')),
    args: ['--no-sandbox', ...extraArgs, path.resolve(appDir)],
    env: { ...process.env, XDG_CONFIG_HOME: prof.cfg, HOME: prof.base, XDG_DOCUMENTS_DIR: prof.docs },
  });
  return { app, ud };
}

async function mainPage(app, titleRe) {
  for (let i = 0; i < 60; i++) {
    for (const w of app.windows()) {
      try { if (/renderer[\\/]index\.html$/.test(w.url())) { await w.waitForLoadState('domcontentloaded'); return w; } } catch { /* closing */ }
    }
    await new Promise((r) => setTimeout(r, 250));
  }
  throw new Error('main window not found');
}

function checker() {
  const results = [];
  const check = async (name, fn) => {
    try { const ok = await fn(); results.push({ name, ok: ok !== false }); console.log((ok !== false ? 'PASS ' : 'FAIL ') + name); } catch (e) { results.push({ name, ok: false, err: e.message }); console.log('FAIL ' + name + ' :: ' + e.message.split('\n')[0]); }
  };
  return { results, check };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(fn, ms = 8000) {
  const t = Date.now();
  for (;;) { const v = await fn(); if (v) return v; if (Date.now() - t > ms) return v; await sleep(100); }
}

/** Replace the Save dialog with a stub that counts calls and returns the next queued path (or cancel). */
async function stubDialogs(app) {
  await app.evaluate(({ dialog }) => {
    global.__dlg = { save: 0, open: 0, msg: 0, queue: [], openQueue: [], msgQueue: [] };
    dialog.showSaveDialog = async () => { global.__dlg.save++; const p = global.__dlg.queue.shift(); return p ? { canceled: false, filePath: p } : { canceled: true }; };
    dialog.showOpenDialog = async () => { global.__dlg.open++; const p = global.__dlg.openQueue.shift(); return p ? { canceled: false, filePaths: p } : { canceled: true, filePaths: [] }; };
    dialog.showMessageBox = async () => { global.__dlg.msg++; const r = global.__dlg.msgQueue.shift(); return { response: r == null ? 0 : r }; };
  });
}
const dlg = (app) => app.evaluate(() => global.__dlg);
const queueSave = (app, p) => app.evaluate((_e, p) => { global.__dlg.queue.push(p); }, p);

module.exports = { lastUser, sysOf, mockServer, textHandler, visionHandler, makeProfile, launch, mainPage, checker, sleep, waitFor, stubDialogs, dlg, queueSave };
