'use strict';
// End-to-end checks for the new Tachyon features. usage: xvfb-run -a node test/e2e/new.js .
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const [appDir] = process.argv.slice(2);
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAEklEQVR4nGP4z8CAFWEXHbQSACj/P8Fu7N9hAAAAAElFTkSuQmCC', 'base64');

(async () => {
  const T = await L.mockServer('text', L.textHandler);
  const V = await L.mockServer('vision', L.visionHandler);
  const prof = L.makeProfile(T.port, V.port, { overlayEnabled: false });
  const outside = path.join(prof.base, 'outside');
  fs.mkdirSync(outside);
  fs.writeFileSync(path.join(prof.work, 'notes.txt'), 'hello world\nsecret-phrase-42\n');
  fs.writeFileSync(path.join(prof.work, 'pic.png'), PNG);
  fs.writeFileSync(path.join(outside, 'far away.txt'), 'outside-content-77\n');
  fs.writeFileSync(path.join(outside, 'picked.txt'), 'picked-content-99\n');
  fs.mkdirSync(path.join(prof.work, 'messy'));
  for (const f of ['a.pdf', 'b.png', 'c.txt']) fs.writeFileSync(path.join(prof.work, 'messy', f), 'x');

  // migration source: an old NOVA AI profile next to the new one
  const oldDir = path.join(prof.cfg, 'nova-ai-desktop');
  fs.mkdirSync(oldDir, { recursive: true });
  fs.writeFileSync(path.join(oldDir, 'conversations.json'), JSON.stringify([{ id: 'old1', title: 'Chat from NOVA', updatedAt: 1, createdAt: 1, messages: [{ role: 'user', content: 'old question' }] }]));
  fs.writeFileSync(path.join(oldDir, 'settings.json'), JSON.stringify(prof.settings));
  prof.settings = null; // let the app migrate instead of pre-writing settings

  const { app } = await L.launch(appDir, prof, 'tachyon');
  const { results, check } = L.checker();
  const page = await L.mainPage(app);
  let confirms = 0;
  page.on('dialog', (d) => { confirms++; d.accept().catch(() => {}); });
  await L.stubDialogs(app);
  await app.evaluate(({ shell }) => { global.__opened = []; shell.openPath = async (p) => { global.__opened.push(p); return ''; }; shell.showItemInFolder = (p) => { global.__opened.push('reveal:' + p); }; });
  await page.waitForSelector('#sendBtn');
  await L.sleep(800);
  const inv = (ch, ...a) => page.evaluate(([c, args]) => window.nova.invoke(c, ...args), [ch, a]);
  const calls = () => T.log.length + V.log.length;
  const msgCount = () => page.$$eval('#messages .msg:not(.thinking)', (x) => x.length);
  async function send(text, minNew = 2) {
    const before = await msgCount();
    await page.fill('#input', text);
    await page.click('#sendBtn');
    await L.waitFor(async () => (await page.textContent('#sendBtn')).includes('Send') && (await msgCount()) >= before + minNew, 15000);
    await L.sleep(250);
  }
  const lastMsgText = () => page.$$eval('#messages .msg', (x) => x[x.length - 1].textContent);
  const sentTo = (log, re) => log.length && log.at(-1).messages.some((m) => re.test(m.content));
  const dl = () => L.dlg(app);
  const queueMsg = (r) => app.evaluate((_e, r) => { global.__dlg.msgQueue.push(r); }, r);

  await check('N1 window title is Tachyon and data migrated from NOVA AI', async () => {
    await L.sleep(300);
    const titles = await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows().map((w) => w.getTitle()));
    return titles.includes('Tachyon') && /Chat from NOVA/.test(await page.textContent('#convList')) && fs.existsSync(path.join(prof.cfg, 'tachyon', 'settings.json'));
  });
  await check('N2 migrated settings are in use (no setup banner)', async () => page.$eval('#banner', (b) => b.classList.contains('hidden')));

  const notes = path.join(prof.work, 'notes.txt');
  let n = calls();
  await send(`summarize ${notes}`);
  await check('N3 a path typed in the chat (granted folder) is read without asking', async () => (await dl()).msg === 0 && sentTo(T.log, /secret-phrase-42/) && calls() === n + 1);

  const far = path.join(outside, 'far away.txt');
  await queueMsg(1); // "Allow for this session"
  await send(`please read ${far} and tell me what it says`);
  await check('N4 a path outside the granted folders asks first, then is read', async () => (await dl()).msg === 1 && sentTo(T.log, /outside-content-77/));
  await check('N5 the chat shows the file as an attachment', async () => /far away\.txt/.test(await page.$$eval('#messages .msg.user', (x) => x.at(-1).textContent)));

  n = calls();
  await queueMsg(0); // Cancel
  const before = await msgCount();
  await page.fill('#input', `summarize ${path.join(outside, 'picked.txt')}`);
  await page.click('#sendBtn');
  await L.sleep(800);
  await check('N6 cancelling the permission sends nothing to the model', async () => calls() === n && (await msgCount()) === before);
  await page.fill('#input', '');

  await send(`fix the typo in ${notes}`);
  await check('N7 "fix … in <path>" edits the file directly with a .nova-bak backup', async () => fs.readFileSync(notes, 'utf8') === 'edited by model\n' && /secret-phrase-42/.test(fs.readFileSync(notes + '.nova-bak', 'utf8')) && /Edited notes\.txt/.test(await lastMsgText()));
  fs.writeFileSync(notes, 'version two\n');
  await send('now fix the typo in it again');
  await check('N8 a follow-up edit ("…in it") reuses the file from the previous message', async () => fs.readFileSync(notes, 'utf8') === 'edited by model\n' && /version two/.test(fs.readFileSync(notes + '.nova-bak', 'utf8')));
  fs.writeFileSync(notes, 'hello world\nsecret-phrase-42\n');

  await page.click('#newChat');
  await send('summarize notes.txt');
  await check('N9 a bare file name is found in the granted folders', async () => sentTo(T.log, /secret-phrase-42/));

  n = calls();
  await send(`list the files in ${prof.work}`);
  await check('N10 "list the files in <folder>" answers with a table, without the model', async () => calls() === n && Boolean(await page.$('#messages .msg.assistant:last-child table')) && /notes\.txt/.test(await lastMsgText()));

  await send(`convert ${notes} to pdf`);
  await check('N11 "convert <file> to pdf" creates a PDF next to it (no model)', async () => calls() === n && fs.existsSync(path.join(prof.work, 'notes.pdf')) && fs.readFileSync(path.join(prof.work, 'notes.pdf')).subarray(0, 4).toString() === '%PDF');
  const pic = path.join(prof.work, 'pic.png');
  await send(`convert ${pic} to jpg`);
  await check('N12 "convert <image> to jpg" creates a JPEG copy', async () => fs.existsSync(path.join(prof.work, 'pic.jpg')));
  await send(`resize ${pic} to 32 px`);
  await check('N13 "resize <image> to 32 px" resizes with a backup', async () => fs.existsSync(pic + '.nova-bak') && /32×32/.test(await lastMsgText()));
  const c0 = confirms;
  await send(`organize ${path.join(prof.work, 'messy')}`);
  await check('N14 "organize <folder>" asks, then sorts files into sub-folders', async () => confirms === c0 + 1 && fs.existsSync(path.join(prof.work, 'messy', 'PDFs', 'a.pdf')));
  await send(`open ${notes}`);
  await send(`show ${notes} in the folder`);
  await check('N15 "open" and "show in folder" work from the chat', async () => { const o = await app.evaluate(() => global.__opened); return o.includes(notes) && o.includes('reveal:' + notes); });
  await check('N16 executables are never opened from the chat', async () => { fs.writeFileSync(path.join(prof.work, 'x.bat'), 'echo'); const r = await inv('files:open', path.join(prof.work, 'x.bat')); return !r.ok; });

  // ---- auto-save
  const saves0 = (await dl()).save;
  await send('Give me a table comparing A and B');
  n = calls();
  await send(`save it to ${prof.docs}`);
  const docsFiles = () => fs.readdirSync(prof.docs);
  await check('N17 "save it to <folder>" writes the last answer there without a dialog or model call', async () => calls() === n && (await dl()).save === saves0 && docsFiles().some((f) => /^Comparison below\.pdf$/.test(f)));
  await send(`save it to ${prof.docs}`);
  await check('N18 saving again never overwrites ("name (1).pdf")', async () => docsFiles().includes('Comparison below (1).pdf'));
  await send('save this to my documents folder as table.md');
  await check('N19 "my documents folder as table.md" uses the named file and format', async () => fs.existsSync(path.join(prof.docs, 'table.md')) && /\| A \| B \|/.test(fs.readFileSync(path.join(prof.docs, 'table.md'), 'utf8')));
  const out = path.join(prof.base, 'out', 'new folder');
  n = calls();
  await send(`write a short poem about rain and save it to "${out}" as poem.txt`, 3);
  await check('N20 "write X and save it to <new folder>" asks the model once, creates the folder and saves', async () => calls() === n + 1 && fs.existsSync(path.join(out, 'poem.txt')) && /TEXT-MODEL/.test(fs.readFileSync(path.join(out, 'poem.txt'), 'utf8')));
  const auto = path.join(prof.base, 'auto');
  await send(`from now on save answers to ${auto} as markdown`);
  await check('N21 "from now on save answers to X" turns on auto-save (badge shown)', async () => !(await page.$eval('#autoSaveBadge', (b) => b.classList.contains('hidden'))));
  await send('what is the capital of France', 3);
  await check('N22 every new answer is then saved automatically', async () => fs.existsSync(auto) && fs.readdirSync(auto).filter((f) => f.endsWith('.md')).length === 1);
  await send('stop auto-saving');
  await send('and of Spain?');
  await check('N23 "stop auto-saving" turns it off', async () => fs.readdirSync(auto).length === 1 && (await page.$eval('#autoSaveBadge', (b) => b.classList.contains('hidden'))));

  // ---- composer extras
  await page.click('#newChat');
  await app.evaluate((_e, p) => { global.__dlg.openQueue.push([p]); }, path.join(outside, 'picked.txt'));
  await page.click('#attachBtn');
  await page.waitForSelector('#attachRow .chip');
  await send('what does this say?');
  await check('N24 📎 attach picks files from anywhere and sends them', async () => sentTo(T.log, /picked-content-99/));
  await page.evaluate((b64) => {
    const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    const dt = new DataTransfer();
    dt.items.add(new File([bytes], 'shot.png', { type: 'image/png' }));
    document.querySelector('#input').dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
  }, PNG.toString('base64'));
  await page.waitForSelector('#attachRow .img-chip', { timeout: 5000 }).catch(() => {});
  const v0 = V.log.length;
  await send('what is in this screenshot?');
  await check('N25 a pasted image is sent to the Vision model', async () => V.log.length === v0 + 1 && (V.log.at(-1).messages.at(-1).images || []).length === 1);
  await check('N26 code blocks get a Copy button', async () => { await send('another table please'); return (await page.$$('#messages pre .copy-code')).length > 0; });
  await check('N27 read-aloud button on answers', async () => (await page.$$('#messages .msg.assistant .msg-actions button')).some(Boolean) && /Read aloud/.test(await page.textContent('#messages')));
  await check('N28 edit the last question puts it back in the box', async () => {
    const c = await msgCount();
    await page.click('#messages .user-actions button');
    return (await page.inputValue('#input')) === 'another table please' && (await msgCount()) === c - 2;
  });
  await page.fill('#input', '');
  await check('N29 theme toggle switches to light and is remembered', async () => {
    const t0 = await page.evaluate(() => document.documentElement.dataset.theme);
    await page.click('#themeToggle');
    await L.sleep(300);
    const t1 = await page.evaluate(() => document.documentElement.dataset.theme);
    const r = await inv('settings:get');
    await page.click('#themeToggle');
    return t0 === 'dark' && t1 === 'light' && r.data.settings.theme === 'light';
  });
  await check('N30 chat search filters the history', async () => {
    await page.fill('#convSearch', 'from NOVA');
    const shown = await page.$$eval('#convList .conv', (x) => x.map((e) => e.textContent));
    await page.fill('#convSearch', '');
    return shown.length === 1 && /Chat from NOVA/.test(shown[0]);
  });
  const chatFile = path.join(prof.base, 'chat.md');
  await L.queueSave(app, chatFile);
  await page.click('#exportChat');
  await page.waitForSelector('dialog.small-dialog select');
  await page.selectOption('dialog.small-dialog select', 'md');
  await page.click('dialog.small-dialog button.primary');
  await L.waitFor(() => fs.existsSync(chatFile));
  await check('N31 export the whole chat', async () => fs.existsSync(chatFile) && /\*\*You:\*\*/.test(fs.readFileSync(chatFile, 'utf8')));
  await check('N32 keyboard shortcut Ctrl+N starts a new chat', async () => { await page.keyboard.press('Control+n'); return Boolean(await page.$('.welcome')); });
  await check('N33 normal questions still create no files and open no dialogs', async () => {
    const s0 = (await dl()).save; const m0 = (await dl()).msg; const d0 = fs.readdirSync(prof.docs).length;
    await send('What is a PDF?');
    await send('how do I save a file to my desktop?');
    return (await dl()).save === s0 && (await dl()).msg === m0 && fs.readdirSync(prof.docs).length === d0;
  });

  await app.evaluate(({ app: a }) => a.exit(0)).catch(() => {});
  T.srv.close(); V.srv.close();
  const pass = results.filter((r) => r.ok).length;
  console.log(`\n${pass}/${results.length} new-feature checks passed`);
  process.exit(pass === results.length ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
