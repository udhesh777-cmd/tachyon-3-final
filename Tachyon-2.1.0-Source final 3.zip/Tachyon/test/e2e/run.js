'use strict';
// 45 end-to-end regression checks against the real Electron app with separate mock Text and Vision servers.
// usage: xvfb-run -a node test/e2e/run.js . Tachyon tachyon
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const [appDir, brand, udName] = process.argv.slice(2);
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAEklEQVR4nGP4z8CAFWEXHbQSACj/P8Fu7N9hAAAAAElFTkSuQmCC', 'base64');

(async () => {
  const T = await L.mockServer('text', L.textHandler);
  const V = await L.mockServer('vision', L.visionHandler);
  const prof = L.makeProfile(T.port, V.port);
  fs.writeFileSync(path.join(prof.work, 'notes.txt'), 'hello world\nsecret-phrase-42\n');
  fs.writeFileSync(path.join(prof.work, 'pic.png'), PNG);
  fs.mkdirSync(path.join(prof.work, 'messy'));
  for (const f of ['a.pdf', 'b.png', 'c.txt']) fs.writeFileSync(path.join(prof.work, 'messy', f), 'x');
  const { app } = await L.launch(appDir, prof, udName);
  const { results, check } = L.checker();
  const page = await L.mainPage(app);
  page.on('dialog', (d) => d.accept());
  await L.stubDialogs(app);
  await page.waitForSelector('#sendBtn');
  await L.sleep(800);
  const inv = (ch, ...a) => page.evaluate(([c, args]) => window.nova.invoke(c, ...args), [ch, a]);
  const msgCount = () => page.$$eval('#messages .msg:not(.thinking)', (x) => x.length);
  async function send(text) {
    const before = await msgCount();
    await page.fill('#input', text);
    await page.click('#sendBtn');
    await L.waitFor(async () => (await page.textContent('#sendBtn')).includes('Send') && (await msgCount()) >= before + 2, 15000);
    await L.sleep(150);
  }
  const lastMsgText = () => page.$$eval('#messages .msg', (x) => x[x.length - 1].textContent);

  await check('1 main window title shows the app name', async () => (await page.title()) === brand || (await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows().map((w) => w.getTitle()))).includes(brand));
  await check('2 sidebar has Chat, Files and Settings', async () => (await page.$$('.nav')).length >= 3);
  await check('3 no-provider banner hidden when a Text model is configured', async () => page.$eval('#banner', (b) => b.classList.contains('hidden')));
  await check('4 welcome screen shown on an empty chat', async () => Boolean(await page.$('.welcome')));

  await send('Give me a table comparing A and B');
  await check('5 text question goes to the Text model only', async () => T.log.length === 1 && V.log.length === 0);
  await check('6 reply rendered in the chat', async () => (await lastMsgText()).includes('Comparison below'));
  const sys = T.log[0].messages[0].content;
  await check('7 system prompt carries the built-in output rules', async () => /Open with the answer/.test(sys));
  await check('8 custom instructions come after the rules', async () => sys.indexOf('CUSTOM-RULE-XYZ') > sys.indexOf('Open with the answer'));
  await check('9 Markdown table rendered as a table', async () => Boolean(await page.$('#messages .msg.assistant table')));
  await check('10 bullet and numbered lists rendered', async () => Boolean(await page.$('#messages .msg.assistant ul')) && Boolean(await page.$('#messages .msg.assistant ol')));
  await check('11 code block rendered as pre', async () => Boolean(await page.$('#messages .msg.assistant pre')));

  // image attachment through the Files view "Ask AI" flow
  await page.click('.nav[data-view="files"]');
  await page.waitForSelector('#tab-browse .item button');
  await page.click('#tab-browse .item button');
  await page.waitForSelector('#tab-browse .item:has-text("pic.png") button:has-text("Ask AI")');
  await page.click('#tab-browse .item:has-text("pic.png") button:has-text("Ask AI")');
  await send('What is in this picture?');
  await check('12 image attachment goes to the Vision model with the image', async () => V.log.length === 1 && (V.log[0].messages.at(-1).images || []).length === 1 && T.log.length === 1);
  await check('13 Vision reply is labelled', async () => /Answered by the Vision model/.test(await lastMsgText()));
  await send('And what does that mean?');
  const fu = T.log.at(-1); 
  await check('14 text follow-up after an image goes to the Text model without images', async () => T.log.length === 2 && fu.messages.every((m) => !m.images));
  await check('15 follow-up sees the Vision model answer in history', async () => fu.messages.some((m) => m.role === 'assistant' && /VISION-MODEL/.test(m.content)));
  await check('16 no Save dialog after normal replies', async () => (await L.dlg(app)).save === 0);
  await check('17 no files created after normal replies', async () => fs.readdirSync(prof.docs).length === 0 && fs.readdirSync(prof.work).sort().join() === 'messy,notes.txt,pic.png');

  const pdfOut = path.join(prof.base, 'out.pdf');
  await L.queueSave(app, pdfOut);
  const calls = () => T.log.length + V.log.length;
  const tBefore = calls();
  await send('Export this to PDF');
  await check('18 "Export this to PDF" opens exactly one Save dialog', async () => (await L.dlg(app)).save === 1);
  await check('19 ...without calling the model again', async () => calls() === tBefore);
  await check('20 the PDF file is written', async () => fs.existsSync(pdfOut) && fs.readFileSync(pdfOut).subarray(0, 4).toString() === '%PDF');
  await send('What is a PDF?');
  await check('21 "What is a PDF?" asks the model and opens no dialog', async () => calls() === tBefore + 1 && (await L.dlg(app)).save === 1);
  const rep = path.join(prof.base, 'report.pdf');
  await L.queueSave(app, rep);
  await send('Create a PDF report about cats');
  await L.waitFor(async () => (await L.dlg(app)).save === 2);
  await check('22 "Create a PDF report about X" answers then opens the Save dialog', async () => calls() === tBefore + 2 && (await L.dlg(app)).save === 2 && fs.existsSync(rep));
  await check('23 Export… button present on answers', async () => (await page.$$('#messages .export-btn')).length > 0);
  const docx = path.join(prof.base, 'a.docx');
  await L.queueSave(app, docx);
  await page.hover('#messages .msg.assistant >> nth=0');
  await page.click('#messages .export-btn >> nth=0');
  await page.waitForSelector('dialog.small-dialog select');
  await page.selectOption('dialog.small-dialog select', 'docx');
  await page.click('dialog.small-dialog button.primary');
  await L.waitFor(() => fs.existsSync(docx));
  await check('24 Export… button writes a valid .docx', async () => fs.existsSync(docx) && fs.readFileSync(docx).subarray(0, 2).toString() === 'PK');
  await send('Export that to markdown');
  await check('25 cancelled export is reported and saves nothing', async () => /Export cancelled/.test(await lastMsgText()));

  await check('26 listing a granted folder works', async () => { const r = await inv('fs:list', prof.work); return r.ok && r.data.some((x) => x.name === 'notes.txt'); });
  await check('27 listing outside granted folders is refused', async () => { const r = await inv('fs:list', prof.docs); return !r.ok && /outside/.test(r.error); });
  await check('28 find by name', async () => { const r = await inv('fs:findName', { q: 'notes', kind: 'all' }); return r.ok && r.data.length === 1; });
  await check('29 search inside files', async () => { const r = await inv('fs:findInside', { q: 'secret-phrase' }); return r.ok && r.data.items.length === 1; });

  await page.click('#newChat');
  await page.click('.nav[data-view="files"]');
  await page.click('#tab-browse .item:has-text("notes.txt") button:has-text("Ask AI")');
  await send('Summarize this file');
  await check('30 attached text file content reaches the Text model', async () => T.log.at(-1).messages.some((m) => /secret-phrase-42/.test(m.content)));
  await page.click('.nav[data-view="files"]');
  await page.click('#tab-browse .item:has-text("notes.txt") button:has-text("Ask AI")');
  await page.check('#allowEdits');
  await send('Please fix the typo');
  const notes = path.join(prof.work, 'notes.txt');
  await check('31 allowed AI edit writes the file and keeps a .nova-bak backup', async () => fs.readFileSync(notes, 'utf8') === 'edited by model\n' && fs.existsSync(notes + '.nova-bak'));
  await check('32 edit result is shown', async () => /Edited notes\.txt/.test(await lastMsgText()));
  await check('33 restore backup brings the original back', async () => { const r = await inv('fs:restoreBackup', notes); return r.ok && /secret-phrase-42/.test(fs.readFileSync(notes, 'utf8')); });
  await page.click('.nav[data-view="files"]');
  await page.click('#tab-browse .item:has-text("notes.txt") button:has-text("Ask AI")');
  await page.check('#allowEdits');
  await send('Please fix OUTSIDE');
  await check('34 edit blocks for files that were not attached are ignored', async () => /Not one of the files you attached/.test(await lastMsgText()));
  await check('35 organize: plan, move and undo', async () => {
    const folder = path.join(prof.work, 'messy');
    const p = await inv('fs:planSort', { folder, mode: 'type' });
    const a = await inv('fs:applySort', { folder, mode: 'type' });
    const moved = fs.existsSync(path.join(folder, 'PDFs', 'a.pdf'));
    const u = await inv('fs:undoSort');
    return p.ok && p.data.length === 3 && a.ok && a.data.moved === 3 && moved && u.ok && fs.existsSync(path.join(folder, 'a.pdf'));
  });

  await page.click('.nav[data-view="settings"]');
  await check('36 settings shows the two model cards', async () => (await page.$$('#settingsForm .card')).length >= 2 && /Vision \/ OCR/.test(await page.textContent('#settingsForm')));
  await check('37 vision test sends an image and recognises red', async () => { const r = await inv('provider:test', { slot: 'vision', vision: true }); return r.ok && /can read images/.test(r.data); });
  await check('38 text test connection', async () => { const r = await inv('provider:test', { slot: 'text' }); return r.ok && /Connected/.test(r.data); });
  await check('39 settings save persists', async () => { await inv('settings:save', { settings: { timeoutSec: 45 } }); const r = await inv('settings:get'); return r.data.settings.timeoutSec === 45 && r.data.settings.models.vision.mode === 'separate'; });

  const wins = await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows().map((w) => w.getTitle()));
  await check('40 floating button and quick-assist panel exist', async () => wins.length >= 3);
  const panel = await L.waitFor(() => app.windows().find((w) => /panel\.html$/.test(w.url())));
  const pinv = (ch, a) => panel.evaluate(([c, x]) => window.novaOverlay.invoke(c, x), [ch, a]);
  let shot;
  await check('41 window/screen list for capture', async () => { const r = await pinv('capture:list'); return r.ok && Array.isArray(r.data); });
  await check('42 real screen capture on the virtual display', async () => { const r = await pinv('capture:take', {}); shot = r.data; return r.ok && fs.existsSync(r.data.path) && r.data.dataUrl.startsWith('data:image/jpeg'); });
  await check('43 screenshot question goes to the Vision model', async () => { const n = V.log.length; const r = await pinv('overlay:ask', { text: 'What is this?', imagePath: shot.path }); return r.ok && V.log.length === n + 1 && r.data.route.slot === 'vision'; });
  await check('44 plain quick question goes to the Text model', async () => { const n = T.log.length; const r = await pinv('overlay:ask', { text: 'hi' }); return r.ok && T.log.length === n + 1 && r.data.route.slot === 'text'; });
  await check('45 OCR works while the image backend is unreachable', async () => {
    await inv('settings:save', { settings: { imageBackend: 'a1111', imageUrl: 'http://127.0.0.1:1' } });
    const r = await inv('image:analyze', { path: path.join(prof.work, 'pic.png'), mode: 'ocr' });
    return r.ok && /HELLO/.test(r.data);
  });

  await app.evaluate(({ app: a }) => a.exit(0)).catch(() => {});
  T.srv.close(); V.srv.close();
  const pass = results.filter((r) => r.ok).length;
  console.log(`\n${pass}/${results.length} checks passed`);
  process.exit(pass === results.length ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
