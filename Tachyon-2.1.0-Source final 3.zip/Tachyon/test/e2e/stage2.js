'use strict';
// Stage 2 end-to-end checks: memory, permissions, activity log. usage: xvfb-run -a node test/e2e/stage2.js .
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const [appDir] = process.argv.slice(2);

(async () => {
  const T = await L.mockServer('text', L.textHandler);
  const V = await L.mockServer('vision', L.visionHandler);
  const prof = L.makeProfile(T.port, V.port, { overlayEnabled: false });
  const notes = path.join(prof.work, 'notes.txt');
  fs.writeFileSync(notes, 'hello world\n');
  const { app } = await L.launch(appDir, prof, 'tachyon');
  const { results, check } = L.checker();
  const page = await L.mainPage(app);
  page.on('dialog', (d) => d.accept().catch(() => {}));
  await L.stubDialogs(app);
  await page.waitForSelector('#sendBtn');
  await L.sleep(800);
  const inv = (ch, ...a) => page.evaluate(([c, args]) => window.nova.invoke(c, ...args), [ch, a]);
  const calls = () => T.log.length + V.log.length;
  const msgCount = () => page.$$eval('#messages .msg:not(.thinking)', (x) => x.length);
  async function send(text, minNew = 2) {
    const before = await msgCount();
    await page.fill('#input', text);
    await page.click('#sendBtn');
    await L.waitFor(async () => (await page.textContent('#sendBtn')).includes('Send') && (await msgCount()) >= before + minNew, 15000);
    await L.sleep(250);
  }
  const lastMsgText = () => page.$$eval('#messages .msg', (x) => x[x.length - 1].textContent);
  const sys = () => T.log.at(-1).messages[0].content;
  const queueMsg = (r) => app.evaluate((_e, r) => { global.__dlg.msgQueue.push(r); }, r);
  const setPerm = (k, v) => inv('settings:save', { settings: { permissions: { [k]: v } } });

  let n = calls();
  await send('remember that I prefer short answers');
  await check('S1 "remember that …" is stored without asking the model', async () => calls() === n && /I’ll remember/.test(await lastMsgText()));
  await send('what is 2+2');
  await check('S2 memories are added to the system prompt', async () => /I prefer short answers/.test(sys()));
  await send('What do you remember about me?');
  await check('S3 "what do you remember about me" lists them', async () => /I prefer short answers/.test(await lastMsgText()));
  await inv('settings:save', { settings: { memoryEnabled: false } });
  await send('what is 3+3');
  await check('S4 memory can be switched off', async () => !/I prefer short answers/.test(sys()));
  await inv('settings:save', { settings: { memoryEnabled: true } });
  await send('forget short answers');
  await send('what is 4+4');
  await check('S5 "forget …" removes it', async () => !/short answers/.test(sys()) && (await inv('memory:list')).data.length === 0);

  await setPerm('files.edit', 'deny');
  await send(`fix the typo in ${notes}`);
  await check('S6 files.edit = Never blocks AI edits; the file is unchanged', async () => fs.readFileSync(notes, 'utf8') === 'hello world\n' && /Blocked by your permission settings/.test(await lastMsgText()));
  await setPerm('files.edit', 'ask');
  const m0 = (await L.dlg(app)).msg;
  await queueMsg(0);
  await send(`fix the typo in ${notes}`);
  await check('S7 files.edit = Ask shows a confirmation; Cancel changes nothing', async () => (await L.dlg(app)).msg === m0 + 1 && fs.readFileSync(notes, 'utf8') === 'hello world\n');
  await queueMsg(1);
  await send(`fix the typo in ${notes}`);
  await check('S8 Allow once applies the edit (with backup)', async () => fs.readFileSync(notes, 'utf8') === 'edited by model\n' && fs.existsSync(notes + '.nova-bak'));
  await queueMsg(2);
  const r = await inv('fs:write', { path: notes, text: 'manual\n' });
  await check('S9 Always allow saves the choice', async () => r.ok && (await inv('perms:get')).data.effective['files.edit'] === 'allow');
  await setPerm('files.read', 'deny');
  n = calls();
  await send(`summarize ${notes}`, 1);
  await check('S10 files.read = Never: named files are not read or sent', async () => !T.log.slice(n).some((j) => j.messages.some((m) => /manual/.test(m.content))));
  await setPerm('files.read', 'allow');
  await check('S11 delete cannot be set to Allow', async () => { await setPerm('files.delete', 'allow'); return (await inv('perms:get')).data.effective['files.delete'] === 'ask'; });

  const log = (await inv('audit:list', {})).data;
  const has = (pred) => log.some(pred);
  await check('S12 the activity log records AI requests, edits, reads, blocks and settings', async () =>
    has((x) => x.action === 'ai.request' && x.category === 'local') && has((x) => x.action === 'ai.edit' && x.ok) && has((x) => x.action === 'files:resolve')
    && has((x) => x.action === 'blocked' && x.category === 'files.edit') && has((x) => x.action === 'cancelled') && has((x) => x.category === 'memory') && has((x) => x.action === 'settings:save'));
  await page.click('.nav[data-view="settings"]');
  await L.sleep(500);
  await check('S13 Settings shows Permissions, Memory and Activity log', async () => { const t = await page.textContent('#settingsForm'); return /Permissions/.test(t) && /Memory/.test(t) && /Activity log/.test(t) && (await page.$$('.perm-row select')).length === Object.keys((await inv('perms:get')).data.categories).length; });
  await page.click('button:has-text("Show / refresh")');
  await L.sleep(500);
  await check('S14 the activity list shows entries', async () => (await page.$$('.list.activity .item')).length > 5);
  await check('S15 the activity log can be cleared', async () => { await inv('audit:clear'); return (await inv('audit:list', {})).data.length === 1; });

  await app.evaluate(({ app: a }) => a.exit(0)).catch(() => {});
  T.srv.close(); V.srv.close();
  const pass = results.filter((x) => x.ok).length;
  console.log(`\n${pass}/${results.length} stage-2 checks passed`);
  process.exit(pass === results.length ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
