'use strict';
// Tachyon 2.0 end-to-end checks: reminders, apps, windows, file search, multi-step tasks with undo, skills, voice.
// usage: xvfb-run -a node test/e2e/v2.js .
// Voice recognition checks run when TACHYON_TEST_MODEL (a Vosk model .zip) and TACHYON_TEST_WAV (16-bit mono speech) are set.
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const [appDir] = process.argv.slice(2);
const MODEL = process.env.TACHYON_TEST_MODEL;
const WAV = process.env.TACHYON_TEST_WAV;
const WAV_WORDS = (process.env.TACHYON_TEST_WORDS || 'infantry platoon move').split(/\s+/);

let plan = null;      // what the mock model answers to the task planner
let skillDraft = null; // what the mock model answers to the skill drafter
function text(j) {
  const sys = L.sysOf(j);
  if (/task planner of Tachyon/.test(sys)) return typeof plan === 'string' ? plan : '```json\n' + JSON.stringify(plan) + '\n```';
  if (/You create small "skills"/.test(sys)) return JSON.stringify(skillDraft);
  if (/carrying out one step of a task/.test(sys)) return 'SUMMARY: ' + L.lastUser(j).content.replace(/\s+/g, ' ').slice(0, 60);
  return L.textHandler(j);
}

(async () => {
  const T = await L.mockServer('text', text);
  const V = await L.mockServer('vision', L.visionHandler);
  const prof = L.makeProfile(T.port, V.port, { overlayEnabled: false });
  const W = prof.work;
  fs.writeFileSync(path.join(W, 'notes.txt'), 'hello world\nsecret-phrase-42\n');
  fs.mkdirSync(path.join(W, 'messy'));
  for (const f of ['a.pdf', 'b.png', 'c.txt']) fs.writeFileSync(path.join(W, 'messy', f), 'x');
  const desktop = path.join(prof.base, 'Desktop');
  fs.mkdirSync(desktop, { recursive: true });
  const { app } = await L.launch(appDir, prof, 'tachyon', ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream']);
  const { results, check } = L.checker();
  const page = await L.mainPage(app);
  page.on('dialog', (d) => d.accept().catch(() => {}));
  await L.stubDialogs(app);
  await page.waitForSelector('#sendBtn');
  await L.sleep(800);
  const inv = (ch, ...a) => page.evaluate(([c, args]) => window.nova.invoke(c, ...args), [ch, a]);
  const calls = () => T.log.length;
  const msgCount = () => page.$$eval('#messages .msg:not(.thinking)', (x) => x.length);
  async function send(t, minNew = 2) {
    const before = await msgCount();
    await page.fill('#input', t);
    await page.click('#sendBtn');
    await L.waitFor(async () => (await page.textContent('#sendBtn')).includes('Send') && (await msgCount()) >= before + minNew, 15000);
    await L.sleep(250);
  }
  const last = () => page.$$eval('#messages .msg', (x) => x[x.length - 1].textContent);
  const toastText = () => page.textContent('#toast');

  // ---- help, reminders
  let n = calls();
  await send('/help');
  await check('V1 /help lists the commands without asking the model', async () => calls() === n && /remind me in 20 minutes/.test(await last()) && /Hey Tachyon/.test(await last()));
  await send('remind me in 10 minutes to stretch');
  const rem = (await inv('reminders:list')).data;
  await check('V2 “remind me in 10 minutes to stretch” sets a reminder', async () => rem.length === 1 && rem[0].text === 'Stretch' && Math.abs(rem[0].at - Date.now() - 600000) < 60000 && /I’ll remind you/.test(await last()));
  await send('remind me to buy milk');
  await check('V3 a reminder without a time asks when', async () => /When should I remind you/.test(await last()) && (await inv('reminders:list')).data.length === 1);
  await send('show my reminders');
  await check('V4 “show my reminders” lists them', async () => /Stretch/.test(await last()));
  await send('cancel the reminder about stretch');
  await check('V5 “cancel the reminder about …” removes it', async () => (await inv('reminders:list')).data.length === 0 && /Cancelled/.test(await last()));
  await inv('reminders:add', { text: 'Drink water', at: Date.now() - 1000 });
  await check('V6 a due reminder shows a notification in the app', async () => L.waitFor(async () => /Reminder: Drink water/.test(await toastText()), 20000));
  await check('V7 a fired reminder is no longer pending', async () => (await inv('reminders:list')).data.length === 0);

  // ---- apps, windows, file search
  await send('open cmd');
  await check('V8 shells are never opened', async () => /does not open/.test(await last()));
  await send('open zzqqunknownapp');
  await check('V9 an unknown app gets a clear answer', async () => /could not find an app/.test(await last()));
  n = calls();
  await send('start a story about a brave cat');
  await check('V10 “start a story …” still goes to the AI', async () => calls() === n + 1 && /TEXT-MODEL answer/.test(await last()));
  await inv('settings:save', { settings: { permissions: { 'apps.open': 'deny' } } });
  await check('V11 opening apps follows Settings → Permissions', async () => /Blocked by your permission settings/.test((await inv('apps:open', 'notepad')).error));
  await inv('settings:save', { settings: { permissions: { 'apps.open': 'allow' } } });
  await send('show desktop');
  await check('V12 window control answers clearly off Windows', async () => (process.platform === 'win32' ? /desktop/i : /available on Windows/).test(await last()));
  await send('find files named notes');
  await check('V13 “find files named …” lists matches with Attach/Open/Show', async () => (await page.$$('.file-hits .hit')).length >= 1 && /notes\.txt/.test(await last()));
  await send('find files containing secret-phrase-42');
  await check('V14 “find files containing …” searches inside files', async () => /notes\.txt/.test(await last()) && /secret-phrase-42/.test(await last()));
  await page.click('.file-hits .hit button:has-text("Attach")');
  await check('V15 a search result can be attached to the chat', async () => /notes\.txt/.test(await page.textContent('#attachRow')));
  await page.click('#attachRow .chip button');

  // ---- multi-step tasks
  plan = { title: 'Summarize notes and file a copy', steps: [
    { tool: 'read_file', args: { path: path.join(W, 'notes.txt') }, why: 'read it' },
    { tool: 'ai_write', args: { instruction: 'Summarize this', input: '$1' } },
    { tool: 'save_text', args: { text: '$2', location: W, filename: 'summary.txt' } },
    { tool: 'make_folder', args: { path: path.join(W, 'archive') } },
    { tool: 'copy_file', args: { from: path.join(W, 'notes.txt'), to: path.join(W, 'archive') } },
    { tool: 'move_file', args: { from: path.join(W, 'messy', 'c.txt'), to: path.join(W, 'archive') } },
    { tool: 'remind', args: { text: 'check the archive', when: 'in 2 hours' } },
  ] };
  await send('/task summarize my notes, save the summary and archive a copy');
  await check('V16 /task shows the plan first and runs nothing yet', async () => (await page.$$('.task-step')).length === 7 && !fs.existsSync(path.join(W, 'summary.txt')) && (await page.$('button:has-text("Run these steps")')) !== null);
  await page.locator('button:has-text("Run these steps")').last().click();
  await L.waitFor(async () => (await page.$('button:has-text("Undo this task")')) !== null, 15000);
  await check('V17 Run executes every step', async () => fs.readFileSync(path.join(W, 'summary.txt'), 'utf8').includes('SUMMARY')
    && fs.existsSync(path.join(W, 'archive', 'notes.txt')) && fs.existsSync(path.join(W, 'archive', 'c.txt')) && !fs.existsSync(path.join(W, 'messy', 'c.txt'))
    && (await inv('reminders:list')).data.some((r) => r.text === 'Check the archive') && (await page.$$('.task-step.done')).length === 7);
  await check('V18 “$1” passes a step’s result to the next step', async () => T.log.some((j) => /hello world/.test(j.messages.map((m) => m.content).join(' ')) && /Summarize this/.test(L.lastUser(j).content)));
  await page.click('button:has-text("Undo this task")');
  await L.sleep(800);
  await check('V19 Undo reverses the whole task (nothing is deleted)', async () => !fs.existsSync(path.join(W, 'summary.txt')) && !fs.existsSync(path.join(W, 'archive'))
    && fs.existsSync(path.join(W, 'messy', 'c.txt')) && fs.existsSync(path.join(W, 'notes.txt')) && (await inv('reminders:list')).data.length === 0
    && fs.readdirSync(path.join(prof.cfg, 'tachyon', 'tasks')).some((d) => d.startsWith('undo-')));
  plan = { title: 'Make a copy then save', steps: [
    { tool: 'copy_file', args: { from: path.join(W, 'notes.txt'), to: path.join(W, 'copy.txt') } },
    { tool: 'save_text', args: { text: 'x', location: W, filename: 'blocked.txt' } },
  ] };
  await inv('settings:save', { settings: { permissions: { 'files.create': 'deny' } } });
  await send('/task copy notes then save');
  await page.locator('button:has-text("Run these steps")').last().click();
  await L.waitFor(async () => (await page.$$('.task-step.failed')).length === 1, 15000);
  await check('V20 a step blocked by permissions stops the task safely', async () => !fs.existsSync(path.join(W, 'copy.txt')) && !fs.existsSync(path.join(W, 'blocked.txt')) && /Blocked by your permission/.test(await last()));
  await inv('settings:save', { settings: { permissions: { 'files.create': 'allow' } } });
  plan = { title: 'Bad', steps: [{ tool: 'delete_file', args: { path: path.join(W, 'notes.txt') } }] };
  await send('/task delete my notes');
  await check('V21 plans with unknown actions (like deleting) are refused', async () => /cannot do/.test(await last()) && fs.existsSync(path.join(W, 'notes.txt')));
  plan = { title: 'Desktop copy', steps: [{ tool: 'save_text', args: { text: 'hello desktop', location: 'desktop', filename: 'hi.txt' } }] };
  await send('find my notes, summarize them and then save the summary to my desktop');
  await check('V22 a chained request (3 actions) becomes a plan automatically', async () => (await page.$$('.task-card')).length === 3 && /Desktop copy/.test(await last()));
  await page.locator('button:has-text("Run these steps")').last().click();
  await L.waitFor(async () => fs.existsSync(path.join(desktop, 'hi.txt')), 8000);
  await check('V23 tasks can save to Desktop like “save it to my desktop”', async () => fs.readFileSync(path.join(desktop, 'hi.txt'), 'utf8').includes('hello desktop'));
  const expired = await inv('task:run', { id: 'not-a-plan' });
  await check('V24 only plans Tachyon showed can be run', async () => !expired.ok && /expired/.test(expired.error));

  // ---- skills
  skillDraft = { name: 'Word counter', command: 'wc', description: 'Counts words', kind: 'code',
    code: 'function run(input) { return String(input.trim().split(/\\s+/).filter(Boolean).length); }', tests: [{ input: 'a b c', expect: '3' }] };
  await send('create a skill that counts the words in my text');
  await check('V25 a drafted skill is shown with its code and passing tests, not installed', async () => (await page.$$('.skill-card')).length === 1 && /Pass: input “a b c”/.test(await last()) && (await inv('skills:list')).data.length === 0);
  await page.locator('button:has-text("Install skill")').last().click();
  await L.sleep(400);
  await check('V26 Install adds it', async () => (await inv('skills:list')).data.some((s) => s.command === 'wc' && s.version === 1));
  await send('/wc the quick brown fox');
  await check('V27 /wc runs the code skill in the sandbox', async () => (await last()).trim().startsWith('4'));
  skillDraft = { ...skillDraft, code: 'function run(input) { return "words: " + input.trim().split(/\\s+/).length; }', tests: [{ input: 'a b', expect: 'words: 2' }] };
  await send('/skill count words and say "words:" first');
  await page.click('button:has-text("Install as version 2")');
  await L.sleep(400);
  await send('/wc one two');
  await check('V28 an update installs version 2', async () => /words: 2/.test(await last()));
  const sk = (await inv('skills:list')).data.find((s) => s.command === 'wc');
  await inv('skills:rollback', sk.id);
  await send('/wc one two three');
  await check('V29 Roll back restores version 1', async () => (await last()).trim().startsWith('3') && (await inv('skills:list')).data.find((s) => s.command === 'wc').version === 1);
  skillDraft = { name: 'Fetcher', command: 'grab', kind: 'code', code: 'function run(u) { return fetch(u); }', tests: [{ input: 'x', expect: '' }] };
  await send('create a skill that downloads a web page');
  await check('V30 code that uses the network is refused before install', async () => /not allowed to use/.test(await last()));
  skillDraft = { name: 'Escape', command: 'probe', kind: 'code', tests: [{ input: 'x', expect: '' }],
    code: 'async function run() { const g = globalThis; let net = "net-ok"; try { await g["fet" + "ch"]("http://127.0.0.1:' + T.port + '/api/tags"); } catch (e) { net = "net-blocked"; } return [typeof g["req" + "uire"], typeof g["pro" + "cess"], typeof g.nova, net].join(","); }' };
  await send('create a skill that probes the sandbox');
  await page.locator('button:has-text("Install skill")').last().click();
  await L.sleep(300);
  await send('/probe go');
  await check('V31 code skills have no Node, no Tachyon API and no network', async () => /undefined,undefined,undefined,net-blocked/.test(await last()));
  skillDraft = { name: 'Spinner', command: 'spin', kind: 'code', tests: [{ input: 'x', expect: '' }], code: 'function run() { for (;;) {} }' };
  const t0 = Date.now();
  await send('create a skill that spins forever');
  await check('V32 a skill that never finishes is stopped after 5 seconds', async () => /longer than 5 seconds/.test(await last()) && Date.now() - t0 < 15000 && (await page.$('.skill-card button.primary[disabled]')) !== null);
  skillDraft = { name: 'Polite rewrite', command: 'polite', kind: 'prompt', description: 'Rewrites text politely', prompt: 'Rewrite politely: {{input}}', tests: [] };
  await send('create a skill that rewrites my text politely');
  await page.locator('button:has-text("Install skill")').last().click();
  await L.sleep(300);
  await send('/polite give me the file');
  await check('V33 prompt skills use the Text model', async () => /TEXT-MODEL answer to: Rewrite politely: give me the file/.test(await last()));
  await inv('skills:toggle', { id: (await inv('skills:list')).data.find((s) => s.command === 'polite').id, enabled: false });
  await send('/polite hello');
  await check('V34 a switched-off skill does not run', async () => /switched off/.test(await last()));
  await send('/nosuchskill hello');
  await check('V35 unknown /commands get a hint', async () => /I don’t know \/nosuchskill/.test(await last()));

  // ---- settings and activity log
  await page.click('.nav[data-view="settings"]');
  await L.sleep(600);
  await check('V36 Settings has Voice, Reminders and Skills', async () => { const t = await page.textContent('#settingsForm'); return /Voice/.test(t) && /Reminders/.test(t) && /\/wc/.test(t) && /English \(US\)/.test(t); });
  const log = (await inv('audit:list', {})).data;
  await check('V37 the activity log records tasks, skills, apps and reminders', async () => ['task.step', 'task.undo', 'skills:run', 'skills:install', 'reminders:add', 'reminder.due'].every((a) => log.some((x) => x.action === a)));
  await page.click('.nav[data-view="chat"]');

  // ---- voice
  await check('V38 the microphone button is in the composer', async () => (await page.$('#micBtn')) !== null);
  await page.click('#micBtn');
  await L.sleep(300);
  await check('V39 without a speech model, 🎤 explains what to do', async () => /speech model/.test(await toastText()));
  if (MODEL && WAV) {
    const tmp = path.join(prof.base, path.basename(MODEL));
    fs.copyFileSync(MODEL, tmp);
    await app.evaluate((_e, p) => { global.__dlg.openQueue.push([p]); }, tmp);
    const imp = await inv('voice:importModel');
    await check('V40 a Vosk model .zip can be imported', async () => imp.ok && (await inv('voice:models')).data.some((m) => m.id === imp.data.id && m.installed));
    await inv('settings:save', { settings: { voiceModel: imp.data.id } });
    await page.evaluate(() => window.nova.invoke('settings:get').then((r) => { /* refresh */ return r; }));
    const wav = fs.readFileSync(WAV);
    const rate = wav.readUInt32LE(24);
    const pcm = new Float32Array((wav.length - 44) / 2);
    for (let i = 0; i < pcm.length; i++) pcm[i] = wav.readInt16LE(44 + i * 2) / 32768;
    const b64 = Buffer.from(pcm.buffer).toString('base64');
    const heard = await page.evaluate(async ([id, b, r]) => {
      const info = (await window.nova.invoke('voice:models')).data.find((m) => m.id === id);
      const bin = atob(b); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
      try { return await window.TachyonVoice.recognizeSamples(info, new Float32Array(u8.buffer), r); } catch (e) { return 'ERR ' + e.message; }
    }, [imp.data.id, b64, rate]);
    console.log('   recognized: “' + heard + '”');
    await check('V41 offline speech recognition understands spoken words', async () => WAV_WORDS.every((w) => heard.includes(w)));
    await page.evaluate(() => window.nova.invoke('settings:get'));
    await page.reload();
    await page.waitForSelector('#micBtn');
    await L.sleep(800);
    await page.click('#micBtn');
    await check('V42 🎤 starts listening with the microphone', async () => L.waitFor(async () => page.$eval('#micBtn', (b) => b.classList.contains('live')), 20000));
    await page.click('#micBtn');
    await check('V43 clicking 🎤 again stops listening', async () => L.waitFor(async () => !(await page.$eval('#micBtn', (b) => b.classList.contains('live'))), 5000));
    await inv('settings:save', { settings: { voiceWake: true } });
    await page.reload();
    await page.waitForSelector('#micBtn');
    await check('V44 with “Hey Tachyon” on, Tachyon listens for the wake phrase', async () => L.waitFor(async () => page.$eval('#micBtn', (b) => b.classList.contains('wake')), 20000));
  } else console.log('SKIP V40–V44 voice recognition (set TACHYON_TEST_MODEL and TACHYON_TEST_WAV)');

  await app.evaluate(({ app: a }) => a.exit(0)).catch(() => {});
  T.srv.close(); V.srv.close();
  const pass = results.filter((x) => x.ok).length;
  console.log(`\n${pass}/${results.length} Tachyon 2.0 checks passed`);
  process.exit(pass === results.length ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
