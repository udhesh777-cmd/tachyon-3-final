'use strict';
// Regression tests for "the folder is granted but the chat says it is not allowed" (Windows paths, OneDrive, model-written paths).
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const F = require('../src/core/fsTools');
const FE = require('../src/core/fileEdits');
const S = require('../src/core/saveTarget');

const W = path.win32;
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'tachyon-fa-'));

test('Windows paths inside a granted folder are accepted whatever the case, slashes or trailing backslash', () => {
  const root = 'C:\\Users\\Me\\Documents\\Work\\';
  for (const t of ['c:\\users\\me\\documents\\work\\a.txt', 'C:/Users/Me/Documents/Work/sub/b.pdf', 'C:\\Users\\Me\\Documents\\Work', 'C:\\Users\\Me\\Documents\\Work\\.\\x\\..\\c.txt']) {
    assert.equal(F.insideLexical(root, t, W), true, t);
  }
  for (const t of ['C:\\Users\\Me\\Documents\\Workshop\\a.txt', 'C:\\Users\\Me\\Documents\\a.txt', 'D:\\Users\\Me\\Documents\\Work\\a.txt', 'C:\\Users\\Me\\Documents\\Work\\..\\x.txt']) {
    assert.equal(F.insideLexical(root, t, W), false, t);
  }
  assert.equal(F.insideLexical('D:\\', 'd:\\any\\where.txt', W), true, 'a whole drive');
  assert.equal(F.insideLexical('\\\\server\\share\\team', '\\\\SERVER\\share\\team\\x.docx', W), true, 'network share');
});

test('a file inside a granted folder is allowed even when typed with a trailing slash or a different but equal form', () => {
  const root = tmp();
  fs.writeFileSync(path.join(root, 'a.txt'), 'x');
  F.assertInside([root + path.sep], path.join(root, 'a.txt'));
  F.assertInside([root], path.join(root, '.', 'sub', '..', 'a.txt'));
  assert.throws(() => F.assertInside([root], path.join(tmp(), 'b.txt')), /outside the folders you granted .*Allow/);
});

test('edits are applied when the model writes the path a little differently', () => {
  const allowed = ['C:\\Users\\Me\\Notes\\todo.txt', 'C:\\Users\\Me\\Notes\\data.json'];
  for (const raw of ['c:/users/me/notes/todo.txt', 'C:\\\\Users\\\\Me\\\\Notes\\\\todo.txt', '"C:\\Users\\Me\\Notes\\TODO.TXT"', 'todo.txt', 'Notes/todo.txt']) {
    assert.equal(FE.matchAllowedPath(allowed, raw, W), allowed[0], raw);
  }
  for (const raw of ['C:\\Windows\\todo.txt', 'D:\\todo2.txt', '', 'other.txt']) assert.equal(FE.matchAllowedPath(allowed, raw, W), null, raw);
  // the same name attached twice is ambiguous, so a bare name is refused
  assert.equal(FE.matchAllowedPath(['C:\\a\\x.txt', 'C:\\b\\x.txt'], 'x.txt', W), null);
});

test('edit blocks with a bare file name or different spelling really write the attached file', async () => {
  const root = tmp();
  const f = path.join(root, 'notes.txt');
  fs.writeFileSync(f, 'old\n');
  const r = await FE.applyEdits([root], [f], [{ path: 'notes.txt', content: 'new' }]);
  assert.equal(r[0].ok, true);
  assert.equal(fs.readFileSync(f, 'utf8'), 'new\n');
  assert.equal(fs.readFileSync(f + '.nova-bak', 'utf8'), 'old\n');
  const bad = await FE.applyEdits([root], [f], [{ path: path.join(root, 'other.txt'), content: 'x' }]);
  assert.equal(bad[0].ok, false);
});

test('Documents/Desktop typed without OneDrive are found in OneDrive (and the other way round)', () => {
  const ctx = { home: 'C:\\Users\\me', known: { documents: 'C:\\Users\\me\\OneDrive\\Documents', desktop: 'C:\\Users\\me\\OneDrive\\Desktop', downloads: 'C:\\Users\\me\\Downloads' } };
  assert.equal(S.remapKnownFolder('C:\\Users\\me\\Documents\\a b\\x.pdf', ctx, W), 'C:\\Users\\me\\OneDrive\\Documents\\a b\\x.pdf');
  assert.equal(S.remapKnownFolder('c:\\users\\ME\\desktop\\x.pdf', ctx, W), 'C:\\Users\\me\\OneDrive\\Desktop\\x.pdf');
  assert.equal(S.remapKnownFolder('C:\\Users\\me\\Downloads\\x.pdf', ctx, W), null, 'already the real folder');
  assert.equal(S.remapKnownFolder('D:\\x.pdf', ctx, W), null);
  const plain = { home: 'C:\\Users\\me', known: { documents: 'C:\\Users\\me\\Documents' } };
  assert.equal(S.remapKnownFolder('C:\\Users\\me\\OneDrive\\Documents\\x.pdf', plain, W), 'C:\\Users\\me\\Documents\\x.pdf');
});
