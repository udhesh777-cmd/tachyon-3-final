'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { normalize } = require('../src/core/store');
const R = require('../src/core/router');
const rules = require('../src/core/rules');
const Intent = require('../src/renderer/intent');
const MD = require('../src/renderer/markdown');
const P = require('../src/core/providers');
const I = require('../src/core/imageGen');

const keys = { text: 'sk-text', vision: '' };
const getKey = (slot) => keys[slot] || '';
const settings = (over = {}) => normalize({
  models: {
    text: { provider: 'local', host: '127.0.0.1', port: '11434', model: 'qwen2.5' },
    vision: { provider: 'cloud', preset: 'gemini', baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai/', model: 'gemini-flash', mode: 'separate' },
    ...over,
  },
});

// ---------------------------------------------------------------- routing
test('text and code go to the Text model; images go to the Vision model', () => {
  const s = settings();
  const t = R.route(s, getKey, { hasImages: false });
  assert.equal(t.slot, 'text');
  assert.equal(t.cfg.kind, 'local');
  assert.equal(t.cfg.model, 'qwen2.5');
  const v = R.route(s, getKey, { hasImages: true });
  assert.equal(v.slot, 'vision');
  assert.equal(v.cfg.kind, 'cloud');
  assert.equal(v.cfg.model, 'gemini-flash');
  assert.match(v.label, /Vision model gemini-flash \(Gemini\)/);
  assert.equal(v.usedTextForImages, false);
});

test('Text and Vision can live on different providers at the same time', () => {
  const s = settings({ vision: { provider: 'local', host: '192.168.1.9', port: '11434', model: 'qwen2.5vl:3b', mode: 'separate' } });
  assert.equal(R.route(s, getKey, { hasImages: true }).cfg.host, '192.168.1.9');
  assert.equal(R.route(s, getKey, { hasImages: false }).cfg.host, '127.0.0.1');
});

test('mode "same" or an empty vision model falls back to the Text model for images', () => {
  const same = settings({ vision: { mode: 'same', model: 'ignored' } });
  const r1 = R.route(same, getKey, { hasImages: true });
  assert.equal(r1.slot, 'text');
  assert.equal(r1.usedTextForImages, true);
  const empty = settings({ vision: { provider: 'local', model: '  ', mode: 'separate' } });
  assert.equal(R.route(empty, getKey, { hasImages: true }).slot, 'text');
});

test('the Vision slot reuses the Text key only for the same cloud endpoint', () => {
  const url = 'https://generativelanguage.googleapis.com/v1beta/openai/';
  const s = normalize({ models: { text: { provider: 'cloud', baseUrl: url, model: 'a' }, vision: { provider: 'cloud', baseUrl: url, model: 'b', mode: 'separate' } } });
  assert.equal(R.slotConfig(s, 'vision', getKey).apiKey, 'sk-text');
  const other = normalize({ models: { text: { provider: 'cloud', baseUrl: url, model: 'a' }, vision: { provider: 'cloud', baseUrl: 'https://other.test/v1', model: 'b', mode: 'separate' } } });
  assert.equal(R.slotConfig(other, 'vision', getKey).apiKey, '');
});

test('slotProblem explains what is missing', () => {
  assert.match(R.slotProblem(normalize({}), 'text', getKey), /No text model/);
  assert.equal(R.slotProblem(settings(), 'text', getKey), null);
  assert.match(R.slotProblem(settings(), 'vision', getKey), /API key/);   // Gemini vision slot has no key
});

// ---------------------------------------------------------------- end-to-end routing over HTTP
test('requests really reach different servers depending on the input type', async () => {
  const mk = (name) => new Promise((resolve) => {
    const seen = [];
    const s = http.createServer((req, res) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => { seen.push(JSON.parse(b)); res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: { content: name } })); }); });
    s.listen(0, '127.0.0.1', () => resolve({ s, seen, port: s.address().port }));
  });
  const textSrv = await mk('from-text');
  const visionSrv = await mk('from-vision');
  try {
    const s = normalize({ models: {
      text: { provider: 'local', host: '127.0.0.1', port: String(textSrv.port), model: 'qwen2.5' },
      vision: { provider: 'local', host: '127.0.0.1', port: String(visionSrv.port), model: 'qwen2.5vl', mode: 'separate' },
    } });
    const ask = async (hasImages, msg) => P.chat(R.route(s, getKey, { hasImages }).cfg, [msg]);
    assert.equal(await ask(false, { role: 'user', content: 'write a python loop' }), 'from-text');
    assert.equal(await ask(true, { role: 'user', content: 'ocr this', images: ['QUJD'] }), 'from-vision');
    assert.equal(textSrv.seen.length, 1);
    assert.equal(visionSrv.seen.length, 1);
    assert.equal(textSrv.seen[0].model, 'qwen2.5');
    assert.equal(visionSrv.seen[0].model, 'qwen2.5vl');
    assert.deepEqual(visionSrv.seen[0].messages[0].images, ['QUJD']);
  } finally { textSrv.s.close(); visionSrv.s.close(); }
});

// ---------------------------------------------------------------- behaviour rules
test('system prompt carries the output rules first, then the user instructions', () => {
  const p = rules.buildSystemPrompt('Call me Sam.', ['EXTRA BLOCK']);
  assert.ok(p.startsWith('You are Tachyon'));
  assert.match(p, /first sentence must answer/);
  assert.match(p, /Here is what I found/);
  assert.match(p, /table/);
  assert.match(p, /bullet points/);
  assert.match(p, /numbered steps/);
  assert.match(p, /Do not create, attach, offer or mention files/);
  assert.ok(p.indexOf('Call me Sam.') > p.indexOf('numbered steps'));
  assert.ok(p.endsWith('EXTRA BLOCK'));
  assert.equal(rules.buildSystemPrompt('', []), rules.OUTPUT_RULES);
});

// ---------------------------------------------------------------- explicit-export detection
test('files are only created for explicit export requests', () => {
  const yes = {
    'Export this to PDF': ['pdf', 'previous'], 'save that as a Word document': ['docx', 'previous'], 'Convert the above to markdown': ['md', 'previous'],
    'turn it into JSON': ['json', 'previous'], 'make a pdf of this': ['pdf', 'previous'], 'can you export this as csv': ['csv', 'previous'],
    'create a PDF report about solar panels': ['pdf', 'new'], 'write a word document about my week': ['docx', 'new'],
  };
  for (const [text, [format, scope]] of Object.entries(yes)) assert.deepEqual(Intent.parseExportIntent(text), { format, scope }, text);
  for (const text of ['what is a PDF?', 'summarize this pdf', 'how do I export to PDF in Word?', 'hello', 'Explain JSON to me', 'Compare these two phones in a table', 'Is this CSV valid?', '']) {
    assert.equal(Intent.parseExportIntent(text), null, text);
  }
  assert.equal(Intent.parseExportIntent('Please export '.padEnd(400, 'x') + ' to pdf'), null);
});

// ---------------------------------------------------------------- Markdown
test('markdown: tables, lists, steps, code and inline styles', () => {
  const md = 'Answer first.\n\n| Phone | Price |\n|---|--:|\n| A | **$10** |\n| B | $20 |\n\n- fast\n- cheap\n\n1. Open Settings\n2. Tap Save\n\n```py\nprint(1)\n```\n\nUse `code` and *emphasis*, snake_case stays.';
  const b = MD.parseMarkdown(md);
  assert.deepEqual(b.map((x) => x.type), ['p', 'table', 'ul', 'ol', 'code', 'p']);
  assert.equal(b[1].header.length, 2);
  assert.equal(b[1].rows.length, 2);
  assert.deepEqual(b[1].align, ['', 'right']);
  assert.equal(b[1].rows[0][1][0].t, 'b');
  assert.equal(b[2].items.length, 2);
  assert.equal(b[3].items.length, 2);
  assert.equal(b[4].lang, 'py');
  const inl = b[5].inline.map((n) => n.t);
  assert.ok(inl.includes('code') && inl.includes('i'));
  assert.ok(b[5].inline.some((n) => n.t === 'text' && n.v.includes('snake_case')));
});

test('markdown: headings, rules, links never become clickable, html stays text', () => {
  const b = MD.parseMarkdown('# Title\n\n---\n\n[site](https://x.test) <b>raw</b> <script>alert(1)</script>');
  assert.equal(b[0].type, 'heading');
  assert.equal(b[1].type, 'hr');
  const kinds = b[2].inline.map((n) => n.t);
  assert.ok(kinds.includes('link'));
  assert.ok(b[2].inline.some((n) => n.t === 'text' && n.v.includes('<script>')));
});

// ---------------------------------------------------------------- Gemini image backend (mock server)
test('Gemini image generation parses inline image data and reports text-only answers', async () => {
  const PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  let mode = 'image'; let seen;
  const s = http.createServer((req, res) => { let b = ''; req.on('data', (c) => (b += c)); req.on('end', () => {
    seen = { url: req.url, key: req.headers['x-goog-api-key'], body: b };
    res.writeHead(200, { 'Content-Type': 'application/json' });
    if (req.url.startsWith('/models?')) return res.end('{"models":[]}');
    res.end(JSON.stringify({ candidates: [{ content: { parts: mode === 'image' ? [{ text: 'ok' }, { inlineData: { mimeType: 'image/png', data: PNG } }] : [{ text: 'I cannot draw that.' }] } }] }));
  }); });
  await new Promise((r) => s.listen(0, '127.0.0.1', r));
  try {
    const cfg = { backend: 'gemini', url: `http://127.0.0.1:${s.address().port}`, apiKey: 'k1', model: 'img-model' };
    assert.equal(I.validate(cfg), null);
    assert.ok(I.validate({ ...cfg, apiKey: '' }));
    assert.ok(I.validate({ ...cfg, url: 'http://example.com' }));
    const img = await I.generate(cfg, 'a fox');
    assert.equal(img.ext, 'png');
    assert.equal(seen.url, '/models/img-model:generateContent');
    assert.equal(seen.key, 'k1');
    assert.equal(JSON.parse(seen.body).contents[0].parts[0].text, 'a fox');
    mode = 'text';
    await assert.rejects(I.generate(cfg, 'a fox'), /did not return an image: I cannot draw that/);
    assert.match(await I.test(cfg), /Connected to the Gemini API/);
  } finally { s.close(); }
});

test('image analysis paths never need an image-generation backend', () => {
  // OCR / screenshots only use chat completions: validate() of the chat config must not look at image settings.
  const s = normalize({ imageBackend: 'a1111', imageUrl: '', models: { text: { provider: 'local', model: 'm' } } });
  assert.equal(R.slotProblem(s, 'text', getKey), null);
  assert.ok(I.validate({ backend: s.imageBackend, url: s.imageUrl }));   // the image backend itself is invalid...
  assert.equal(R.route(s, getKey, { hasImages: true }).cfg.model, 'm'); // ...yet image questions still route to a chat model
});
