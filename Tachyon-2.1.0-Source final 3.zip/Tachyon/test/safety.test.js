'use strict';
// Stage 2: activity log, per-category permissions and personal memory.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { AuditLog } = require('../src/core/audit');
const Perm = require('../src/core/permissions');
const { Memory } = require('../src/core/memory');
const Intent = require('../src/renderer/intent');
const rules = require('../src/core/rules');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'tachyon-s-'));

test('activity log records actions newest first, filters, survives damage and clears', () => {
  const a = new AuditLog(tmp());
  assert.deepEqual(a.list(), []);
  a.log({ action: 'fs:write', category: 'files.edit', target: '/x/a.txt' });
  a.log({ action: 'ai.request', category: 'local', target: 'Text model', detail: 'x'.repeat(900) });
  fs.appendFileSync(a.file, 'not json\n');
  a.log({ action: 'files:open', category: 'files.open', target: '/x/b.pdf', ok: false });
  const rows = a.list();
  assert.deepEqual(rows.map((r) => r.action), ['files:open', 'ai.request', 'fs:write']);
  assert.equal(rows[0].ok, false);
  assert.equal(rows[1].detail.length, 500, 'long details are trimmed');
  assert.ok(rows.every((r) => typeof r.ts === 'number'));
  assert.deepEqual(a.list({ category: 'files.edit' }).map((r) => r.target), ['/x/a.txt']);
  assert.equal(a.list({ limit: 1 }).length, 1);
  a.clear();
  assert.deepEqual(a.list(), []);
});

test('permissions default to the 1.3 behaviour; delete and send always ask', () => {
  const e = Perm.effective({});
  assert.equal(e['files.read'], 'allow');
  assert.equal(e['files.edit'], 'allow');
  assert.equal(e['cloud.files'], 'allow');
  assert.equal(e['files.delete'], 'ask');
  assert.equal(e.send, 'ask');
  const u = Perm.effective({ permissions: { 'files.edit': 'deny', 'files.open': 'ask', 'files.delete': 'allow', send: 'deny', bogus: 'allow', 'files.read': 'maybe' } });
  assert.deepEqual([u['files.edit'], u['files.open'], u['files.delete'], u.send, u['files.read']], ['deny', 'ask', 'ask', 'deny', 'allow']);
  assert.deepEqual(Perm.sanitize({ 'files.edit': 'ask', 'files.delete': 'allow', nope: 'deny', 'files.read': 'x' }), { 'files.edit': 'ask', 'files.delete': 'ask' });
});

test('memory: add (no duplicates), forget by words, prompt block, delete and clear', () => {
  const m = new Memory(tmp());
  assert.equal(m.promptBlock(), '');
  const a = m.add('I prefer short answers');
  m.add('i prefer   SHORT answers');
  m.add('My name is Dhanu');
  m.add('I use Windows 11');
  assert.equal(m.list().length, 3);
  assert.match(m.promptBlock(), /^Things the user asked you to remember[\s\S]*- I prefer short answers\n- My name is Dhanu\n- I use Windows 11$/);
  assert.deepEqual(m.forget('my name').map((x) => x.text), ['My name is Dhanu']);
  assert.deepEqual(m.forget('the'), []);
  assert.equal(m.remove(a.id), 1);
  assert.deepEqual(m.list().map((x) => x.text), ['I use Windows 11']);
  assert.throws(() => m.add('   '), /Nothing to remember/);
  m.clear();
  assert.deepEqual(m.list(), []);
});

test('memory is added to the system prompt after the rules and custom instructions', () => {
  const p = rules.buildSystemPrompt('Be formal.', ['Things the user asked you to remember:\n- likes tea']);
  assert.ok(p.indexOf('Open with the answer') < p.indexOf('Be formal.') && p.indexOf('Be formal.') < p.indexOf('likes tea'));
  assert.equal(rules.buildSystemPrompt('', ['']), rules.buildSystemPrompt(''), 'an empty memory adds nothing');
});

test('memory commands in the chat', () => {
  const p = Intent.parseMemoryCommand;
  assert.deepEqual(p('remember that I prefer short answers'), { op: 'add', text: 'I prefer short answers' });
  assert.deepEqual(p('Please remember my exam is on Monday.'), { op: 'add', text: 'My exam is on Monday' });
  assert.deepEqual(p('keep in mind that I use Windows'), { op: 'add', text: 'I use Windows' });
  assert.deepEqual(p('forget my exam'), { op: 'forget', query: 'my exam' });
  assert.deepEqual(p('forget everything'), { op: 'forgetAll' });
  assert.deepEqual(p('What do you remember about me?'), { op: 'list' });
  assert.deepEqual(p('show my memories'), { op: 'list' });
  for (const t of ['do you remember the capital of France?', 'remember when we met?', 'how do I remember things better?', 'I forgot my password', 'remember?', 'What is memory?']) assert.equal(p(t), null, t);
});
