'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { Store } = require('../src/core/store');

const fakeSafe = {
  isEncryptionAvailable: () => true,
  encryptString: (s) => Buffer.from(s.split('').reverse().join('')),
  decryptString: (b) => b.toString().split('').reverse().join(''),
};
const mk = (safe = fakeSafe) => new Store(fs.mkdtempSync(path.join(os.tmpdir(), 'nova-st-')), safe);

test('settings persist and merge with defaults', () => {
  const s = mk();
  assert.equal(s.getSettings().overlayEnabled, true);
  s.saveSettings({ timeoutSec: 45, folders: ['/a'] });
  assert.equal(s.getSettings().timeoutSec, 45);
  assert.deepEqual(s.getSettings().folders, ['/a']);
});

test('settings: two model slots, defaults and merge', () => {
  const s = mk();
  const d = s.getSettings();
  assert.equal(d.models.text.port, '11434');
  assert.equal(d.models.vision.mode, 'same');
  s.saveSettings({ models: { text: { model: 'qwen2.5' }, vision: { mode: 'separate', model: 'qwen2.5vl:3b' } } });
  const g = s.getSettings();
  assert.equal(g.models.text.model, 'qwen2.5');
  assert.equal(g.models.text.host, '127.0.0.1');   // untouched fields survive the merge
  assert.equal(g.models.vision.model, 'qwen2.5vl:3b');
});

test('settings written by older versions are migrated', () => {
  const s = mk();
  fs.writeFileSync(s.settingsFile, JSON.stringify({ provider: 'local', host: '10.0.0.5', port: '11434', localModel: 'qwen2.5', visionModel: 'minicpm-v', folders: ['/a'], timeoutSec: 90 }));
  const g = s.getSettings();
  assert.equal(g.models.text.provider, 'local');
  assert.equal(g.models.text.model, 'qwen2.5');
  assert.equal(g.models.text.host, '10.0.0.5');
  assert.equal(g.models.vision.mode, 'separate');
  assert.equal(g.models.vision.model, 'minicpm-v');
  assert.deepEqual(g.folders, ['/a']);
  assert.equal(g.timeoutSec, 90);
  assert.equal(g.provider, undefined);
  fs.writeFileSync(s.settingsFile, JSON.stringify({ provider: 'cloud', cloudPreset: 'gemini', baseUrl: 'https://g.test/v1', model: 'flash' }));
  const c = s.getSettings();
  assert.deepEqual([c.models.text.provider, c.models.text.preset, c.models.text.model, c.models.vision.mode], ['cloud', 'gemini', 'flash', 'same']);
});

test('API keys are stored encrypted, per slot, and can be deleted', () => {
  const s = mk();
  s.setApiKey('text', 'sk-text-secret');
  s.setApiKey('vision', 'sk-vision-secret');
  assert.equal(s.getApiKey('text'), 'sk-text-secret');
  assert.equal(s.getApiKey('vision'), 'sk-vision-secret');
  assert.ok(!fs.readFileSync(s.keyFile('text')).toString().includes('sk-text-secret'));
  s.saveSettings({ timeoutSec: 30 });
  assert.ok(!fs.readFileSync(s.settingsFile, 'utf8').includes('secret'));
  s.deleteApiKey('text');
  assert.equal(s.hasApiKey('text'), false);
  assert.equal(s.hasApiKey('vision'), true);
  assert.throws(() => s.setApiKey('other', 'k'), /Unknown/);
});

test('without secure storage keys are kept in memory only', () => {
  const s = mk({ isEncryptionAvailable: () => false });
  assert.deepEqual(s.setApiKey('text', 'k'), { persisted: false });
  assert.equal(s.getApiKey('text'), 'k');
  assert.equal(fs.existsSync(s.keyFile('text')), false);
});

test('conversations: save, list, rename, delete', () => {
  const s = mk();
  const c = s.saveConversation({ title: 'Hello', messages: [{ role: 'user', content: 'hi' }] });
  assert.equal(s.listConversations().length, 1);
  assert.equal(s.getConversation(c.id).messages[0].content, 'hi');
  s.renameConversation(c.id, 'Renamed');
  assert.equal(s.listConversations()[0].title, 'Renamed');
  s.deleteConversation(c.id);
  assert.equal(s.listConversations().length, 0);
});
