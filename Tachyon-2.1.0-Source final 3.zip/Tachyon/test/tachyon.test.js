'use strict';
// Tests for the Tachyon 1.3 additions: files named in the chat, "save it to …", save targets, migration from NOVA AI.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const FI = require('../src/renderer/fileIntent');
const Intent = require('../src/renderer/intent');
const S = require('../src/core/saveTarget');
const { migrateUserData } = require('../src/core/migrate');
const { Store, DEFAULTS } = require('../src/core/store');
const rules = require('../src/core/rules');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'tachyon-'));
const req = (t) => FI.parseFileRequest(t);

// ---------------------------------------------------------------- files named in the chat
test('paths typed in the chat are found, including Windows paths with spaces', () => {
  assert.deepEqual(req('summarize C:\\Users\\Dhanu\\My Documents\\report final.pdf please').targets, [{ kind: 'path', value: 'C:\\Users\\Dhanu\\My Documents\\report final.pdf' }]);
  assert.deepEqual(req('read C:\\data\\notes.txt and then summarize').targets, [{ kind: 'path', value: 'C:\\data\\notes.txt' }]);
  assert.deepEqual(req('open ~/Documents/plan.docx').targets, [{ kind: 'path', value: '~/Documents/plan.docx' }]);
  assert.deepEqual(req('resize "/home/u/My Pics/b.jpg" to 800px').targets, [{ kind: 'path', value: '/home/u/My Pics/b.jpg' }]);
  assert.deepEqual(req('list the files in D:\\Projects').targets, [{ kind: 'path', value: 'D:\\Projects' }]);
  assert.deepEqual(req('what is in my downloads folder?').targets, [{ kind: 'known', value: 'downloads' }]);
  const n = req('fix the typos in notes.txt').targets[0];
  assert.equal(n.kind, 'name');
  assert.equal(n.value, 'notes.txt');
  assert.ok(req('summarize my budget 2024.xlsx').targets[0].alts.includes('budget 2024.xlsx'));
});

test('ordinary chat is not mistaken for a file request', () => {
  for (const t of ['What is node.js?', 'what does TCP/IP mean and/or http://x.com/y.pdf', '/image a cat on /home', 'hello there', 'What is a PDF?', 'Explain recursion', 'compare cats and dogs']) {
    assert.equal(req(t), null, t);
  }
});

test('the requested operation is detected', () => {
  assert.equal(req('list the files in D:\\Projects').op, 'list');
  assert.equal(req('what is in my downloads folder?').op, 'list');
  assert.equal(req('fix the typos in notes.txt').op, 'edit');
  assert.equal(req('add a header row to C:\\x\\data.csv').op, 'edit');
  assert.equal(req('summarize C:\\x\\a.pdf').op, 'ask');
  assert.equal(req('translate C:\\x\\a.docx to Spanish').op, 'ask');
  assert.deepEqual([req('convert /home/u/pics/a.png to jpg').op, req('convert /home/u/pics/a.png to jpg').format], ['convert', 'jpg']);
  assert.deepEqual([req('convert report.docx to a word document').op, req('convert report.docx to pdf').format], ['convert', 'pdf']);
  assert.deepEqual([req('resize "/home/u/My Pics/b.jpg" to 800px').op, req('resize "/home/u/My Pics/b.jpg" to 800px').width], ['resize', 800]);
  assert.deepEqual([req('organize my downloads folder by month').op, req('organize my downloads folder by month').mode], ['organize', 'month']);
  assert.equal(req('organize my downloads folder').mode, 'type');
  assert.equal(req('open ~/Documents/plan.docx').op, 'open');
  assert.equal(req('open ~/Documents/plan.docx and summarize it').op, 'ask');
  assert.equal(req('show /home/u/x/report.pdf in the folder').op, 'reveal');
});

test('follow-up edits that refer to the previous file are recognised', () => {
  assert.equal(FI.isEditFollowUp('now fix the typo in it'), true);
  assert.equal(FI.isEditFollowUp('update that file with a title'), true);
  assert.equal(FI.isEditFollowUp('what is it?'), false);
  assert.equal(FI.isEditFollowUp('fix notes.txt'), false); // names a file itself
  assert.equal(FI.isImagePath('/a/b.PNG'), true);
  assert.equal(FI.isImagePath('/a/b.pdf'), false);
});

// ---------------------------------------------------------------- "save it to …"
test('"save it to <place>" is understood', () => {
  const a = Intent.parseSaveIntent('save it to D:\\Reports');
  assert.deepEqual([a.mode, a.scope, a.location], ['once', 'previous', { kind: 'path', value: 'D:\\Reports' }]);
  assert.deepEqual(Intent.parseSaveIntent('save this to my desktop').location, { kind: 'known', value: 'desktop' });
  assert.deepEqual(Intent.parseSaveIntent('put it in the downloads folder').location, { kind: 'known', value: 'downloads' });
  assert.equal(Intent.parseSaveIntent('save the answer to C:\\Users\\Dhanu\\My Docs\\summary.docx').location.value, 'C:\\Users\\Dhanu\\My Docs\\summary.docx');
  assert.equal(Intent.parseSaveIntent('save it to /home/u/out/report.pdf please').location.value, '/home/u/out/report.pdf');
  const b = Intent.parseSaveIntent('save it as notes.md');
  assert.deepEqual([b.location, b.filename], [null, 'notes.md']);
  const c = Intent.parseSaveIntent('export this to PDF in D:\\Reports');
  assert.deepEqual([c.format, c.location.value, c.scope], ['pdf', 'D:\\Reports', 'previous']);
  assert.equal(Intent.parseSaveIntent('save to desktop as pdf').format, 'pdf');
});

test('"write X and save it to <place>" answers first, then saves', () => {
  const t = 'write a short poem about rain and save it to my desktop';
  const a = Intent.parseSaveIntent(t);
  assert.deepEqual([a.mode, a.scope], ['once', 'new']);
  assert.equal(t.slice(a.clause[0], a.clause[1]), 'save it to my desktop');
  const b = Intent.parseSaveIntent('create a PDF report about cats and save it in "D:\\My Reports"');
  assert.deepEqual([b.scope, b.location.value], ['new', 'D:\\My Reports']);
});

test('auto-save on and off', () => {
  const a = Intent.parseSaveIntent('from now on save answers to ~/tachyon-out');
  assert.deepEqual([a.mode, a.scope, a.location.value], ['always', 'previous', '~/tachyon-out']);
  const b = Intent.parseSaveIntent('auto-save to my documents folder as markdown');
  assert.deepEqual([b.mode, b.location.value, b.format], ['always', 'documents', 'md']);
  assert.equal(Intent.parseSaveIntent('stop auto-saving').mode, 'off');
  assert.equal(Intent.parseSaveIntent('turn off auto-save').mode, 'off');
});

test('existing export phrases and questions are left alone', () => {
  for (const t of ['Export this to PDF', 'save that as a Word document', 'What is a PDF?', 'how do I save a file to my desktop?', 'list the files in D:\\x', 'summarize this PDF', '']) {
    assert.equal(Intent.parseSaveIntent(t), null, t);
  }
  // the original export intent still behaves exactly as before
  assert.deepEqual(Intent.parseExportIntent('Export this to PDF'), { format: 'pdf', scope: 'previous' });
  assert.equal(Intent.parseExportIntent('What is a PDF?'), null);
});

// ---------------------------------------------------------------- save targets
const ctx = { home: '/home/u', known: { desktop: '/home/u/Desktop', documents: '/home/u/Documents', downloads: '/home/u/Downloads' } };

test('places are expanded: ~, known folders, absolute and relative paths', () => {
  assert.equal(S.expandUserPath({ kind: 'path', value: '~/out' }, ctx), path.join('/home/u', 'out'));
  assert.equal(S.expandUserPath({ kind: 'path', value: '~' }, ctx), '/home/u');
  assert.equal(S.expandUserPath({ kind: 'known', value: 'desktop' }, ctx), '/home/u/Desktop');
  assert.equal(S.expandUserPath({ kind: 'known', value: 'home' }, ctx), '/home/u');
  assert.equal(S.expandUserPath({ kind: 'path', value: '/srv/x.' }, ctx), path.normalize('/srv/x')); // Windows turns / into \
  assert.equal(S.expandUserPath({ kind: 'path', value: 'reports' }, ctx), path.join('/home/u/Documents', 'reports'));
  assert.equal(S.expandUserPath(null, ctx), '/home/u/Documents');
});

test('planSave picks the name and format and never overwrites', () => {
  const none = () => false;
  assert.deepEqual(S.planSave({ location: { kind: 'known', value: 'desktop' }, title: 'Rain poem', text: 'drops' }, ctx, none),
    { dir: '/home/u/Desktop', file: path.join('/home/u/Desktop', 'Rain poem.pdf'), format: 'pdf' });
  assert.equal(S.planSave({ location: { kind: 'path', value: '/x/out/sum.docx' }, title: 't', text: '' }, ctx, none).file, path.join('/x/out', 'sum.docx'));
  assert.equal(S.planSave({ location: null, filename: 'notes.md', title: 't', text: '' }, ctx, none).file, path.join('/home/u/Documents', 'notes.md'));
  assert.equal(S.planSave({ location: { kind: 'path', value: '/x' }, format: 'docx', title: 'A: b/c?', text: '' }, ctx, none).file, path.join('/x', 'A b c.docx'));
  assert.equal(S.planSave({ location: { kind: 'path', value: '/x' }, title: 'code', text: '```python\nprint(1)\n```' }, ctx, none).format, 'py');
  const taken = new Set([path.join('/x', 'Report.pdf'), path.join('/x', 'Report (1).pdf')]);
  assert.equal(S.planSave({ location: { kind: 'path', value: '/x' }, title: 'Report', text: '' }, ctx, (p) => taken.has(p)).file, path.join('/x', 'Report (2).pdf'));
  assert.equal(S.safeName('## **Title**: part 1/2'), 'Title part 1 2');
  assert.equal(S.safeName(''), 'Tachyon answer');
});

// ---------------------------------------------------------------- migration and settings
test('settings, chats and keys are copied from NOVA AI once, without overwriting', () => {
  const appData = tmp();
  const oldDir = path.join(appData, 'NOVA AI');
  const newDir = path.join(appData, 'Tachyon');
  fs.mkdirSync(path.join(oldDir, 'captures'), { recursive: true });
  fs.writeFileSync(path.join(oldDir, 'settings.json'), '{"folders":["/a"]}');
  fs.writeFileSync(path.join(oldDir, 'conversations.json'), '[]');
  fs.writeFileSync(path.join(oldDir, 'apikey.bin'), 'k');
  fs.writeFileSync(path.join(oldDir, 'captures', 's.jpg'), 'x');
  assert.equal(migrateUserData(newDir, appData), oldDir);
  assert.equal(fs.readFileSync(path.join(newDir, 'settings.json'), 'utf8'), '{"folders":["/a"]}');
  assert.ok(fs.existsSync(path.join(newDir, 'apikey.bin')) && fs.existsSync(path.join(newDir, 'captures', 's.jpg')));
  assert.ok(fs.existsSync(path.join(oldDir, 'settings.json')), 'the old folder is left untouched');
  fs.writeFileSync(path.join(newDir, 'settings.json'), '{"folders":["/new"]}');
  assert.equal(migrateUserData(newDir, appData), null, 'never runs twice');
  assert.equal(fs.readFileSync(path.join(newDir, 'settings.json'), 'utf8'), '{"folders":["/new"]}');
  assert.equal(migrateUserData(path.join(tmp(), 'Tachyon'), tmp()), null, 'nothing to migrate');
});

test('appearance settings have defaults and persist', () => {
  assert.equal(DEFAULTS.theme, 'dark');
  assert.equal(DEFAULTS.fontSize, 14);
  const s = new Store(tmp(), null);
  assert.equal(s.getSettings().theme, 'dark');
  s.saveSettings({ theme: 'light', fontSize: 16 });
  assert.deepEqual([s.getSettings().theme, s.getSettings().fontSize, s.getSettings().models.text.provider], ['light', 16, 'local']);
});

test('the app is called Tachyon everywhere the user can see', () => {
  const root = path.join(__dirname, '..');
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  assert.equal(pkg.name, 'tachyon');
  assert.equal(pkg.build.productName, 'Tachyon');
  // 2.1: the installer and the portable build get different file names (they used to share one and overwrote each other).
  assert.match(pkg.build.nsis.artifactName, /^Tachyon-Setup-/);
  assert.match(pkg.build.portable.artifactName, /^Tachyon-Portable-/);
  assert.notEqual(pkg.build.nsis.artifactName, pkg.build.portable.artifactName);
  assert.ok(rules.buildSystemPrompt('').startsWith('You are Tachyon'));
  const files = [];
  const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).forEach((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : /\.(js|html|css)$/.test(e.name) && files.push(path.join(d, e.name))));
  walk(path.join(root, 'src'));
  for (const f of files) {
    const t = fs.readFileSync(f, 'utf8').replace(/'NOVA AI', 'nova-ai-desktop'|formerly NOVA AI|from NOVA AI|copied from NOVA AI|called NOVA AI/g, '');
    assert.doesNotMatch(t, /NOVA AI|NOVA quick|Continue in NOVA|Hello, I’m NOVA/, f);
  }
});
