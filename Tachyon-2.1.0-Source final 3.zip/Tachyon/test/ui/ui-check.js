'use strict';
// Headless UI check: loads the real window (index.html, app.js, workspace.js) in Chromium with the real connector/agent code
// behind a stand-in for Electron's IPC. Programs (VS Code, git, npm ...) are MOCK processes; everything else is the shipped code.
// Run:  node test/ui/ui-check.js      (needs playwright or playwright-core; not part of "npm test")
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const { chromium } = (() => { try { return require('playwright'); } catch { return require('playwright-core'); } })();
const Agent = require('../../src/core/agent');
const { DEFAULTS } = require('../../src/core/store');
const Perm = require('../../src/core/permissions');

const ROOT = path.resolve(__dirname, '../..');
const SHOTS = process.env.SHOTS_DIR || '';
let pass = 0; let fail = 0;
const ok = (c, name, extra = '') => { if (c) { pass++; console.log('PASS', name); } else { fail++; console.log('FAIL', name, extra); } };

function fakeSpawn(spawned) {
  return (file, args, opts) => {
    const c = new EventEmitter(); c.stdout = new EventEmitter(); c.stderr = new EventEmitter(); c.pid = 31337; c.unref = () => {}; c.kill = () => setImmediate(() => c.emit('close', null));
    spawned.push({ file, args, opts });
    setImmediate(() => {
      c.emit('spawn');
      if (/git$/.test(file)) { c.stdout.emit('data', Buffer.from('## main...origin/main\n M src/app.js\n')); c.emit('exit', 0); c.emit('close', 0); }
      else if (/node$/.test(file)) { c.stdout.emit('data', Buffer.from('# tests 3\n# pass 3\n')); c.emit('exit', 0); c.emit('close', 0); }
    });
    return c;
  };
}

(async () => {
  const tmp = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'tachyon-ui-')));
  const bin = path.join(tmp, 'bin'); fs.mkdirSync(path.join(bin, 'node_modules/npm/bin'), { recursive: true });
  for (const f of ['code', 'git', 'node', 'python3', 'node_modules/npm/bin/npm-cli.js']) fs.writeFileSync(path.join(bin, f), '#!/bin/sh\n', { mode: 0o755 });
  const proj = path.join(tmp, 'my-app'); fs.mkdirSync(proj); fs.writeFileSync(path.join(proj, 'package.json'), JSON.stringify({ name: 'my-app', scripts: { test: 'node t.js' } })); fs.writeFileSync(path.join(proj, 'index.js'), 'console.log(1)\n');
  const user = fs.mkdtempSync(path.join(os.tmpdir(), 'tachyon-ui-user-'));
  let settings = { ...JSON.parse(JSON.stringify(DEFAULTS)), folders: [tmp] };
  settings.models.text = { ...settings.models.text, model: 'qwen2.5:3b', host: '127.0.0.1', port: '11434' };
  const spawned = []; const guarded = [];
  let pushEvent = () => {};
  const agent = Agent.create({
    userData: user, platform: 'linux', env: { PATH: bin }, roots: () => settings.folders, spawn: fakeSpawn(spawned),
    getSettings: () => settings, saveSettings: (p) => { settings = { ...settings, ...p }; return settings; },
    guard: async (cat, target) => { guarded.push([cat, target]); },
    openExternal: async () => {}, openPath: async () => '',
    emit: (r) => pushEvent(r),
    listWindows: async () => [{ app: 'Code', title: 'my-app - Visual Studio Code' }],
    fetch: async () => ({ ok: true, json: async () => ({ models: [{ name: 'qwen2.5:3b', size: 1.9e9 }, { name: 'nomic-embed-text', size: 2.7e8 }, { name: 'qwen2.5vl:3b', size: 3.2e9 }] }) }),
  });
  let convs = [];
  const handlers = {
    'settings:get': () => ({ settings, hasKey: { text: false, vision: false }, secure: true, version: '2.1.0', sep: path.sep, home: tmp, overlayRunning: false }),
    'settings:save': ({ settings: p = {} } = {}) => { settings = { ...settings, ...p }; return settings; },
    'perms:get': () => ({ categories: Perm.CATEGORIES, effective: Perm.effective(settings) }),
    'conv:list': () => convs.map(({ id, title, updatedAt }) => ({ id, title, updatedAt })),
    'conv:save': (c) => { const x = { ...c, id: c.id || 'c' + convs.length, updatedAt: Date.now() }; convs = [x, ...convs.filter((y) => y.id !== x.id)]; return x; },
    'chat:send': () => ({ text: 'ordinary answer from the model' }),
    'agent:apps': () => agent.apps(), 'agent:tools': () => agent.tools(), 'agent:models': () => agent.modelStatus(), 'agent:diagnostics': () => agent.diagnostics(),
    'agent:activity': () => agent.activity.list(100), 'agent:activityClear': () => { agent.activity.clear(); return true; }, 'agent:history': () => agent.history.list(50), 'agent:historyClear': () => true,
    'agent:cancel': (id) => agent.cancel(id),
    'agent:run': async ({ connector, op, args, label }) => {
      let a = { ...(args || {}) };
      if (a.project) { const r = agent.resolveProjectArgs(connector, op, { ...a, project: undefined }, a.project); if (r.message) throw new Error(r.message); a = r.args; delete a.project; }
      return agent.run({ connector, op, args: a, source: 'ui', label });
    },
    'agent:chat': ({ text }) => agent.chat(text),
    'projects:list': () => ({ projects: agent.projects(), active: settings.activeProject || null }),
    'projects:add': () => { const p = agent.addProject(proj); settings.activeProject = p.id; return p; },
    'projects:remove': (id) => agent.removeProject(id), 'projects:setActive': (id) => { settings.activeProject = id; return true; },
    'apps:addCustom': () => null, 'apps:removeCustom': (id) => agent.removeCustomApp(id),
    'fs:readEditable': () => 'console.log(1)\n',
    'audit:list': () => [], 'memory:list': () => [], 'reminders:list': () => [], 'skills:list': () => [], 'voice:models': () => [], 'folders:add': () => settings.folders,
  };

  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 820 } });
  const errors = [];
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  await page.exposeFunction('__invoke', async (channel, args) => {
    try { const h = handlers[channel]; return { ok: true, data: h ? await h(...args) : null }; } catch (e) { return { ok: false, error: e.message }; }
  });
  pushEvent = (r) => { page.evaluate((x) => { if (window.__agentCb) window.__agentCb(x); }, r).catch(() => {}); };
  await page.addInitScript(() => {
    window.nova = {
      invoke: (c, ...a) => window.__invoke(c, a),
      onAgentActivity: (cb) => { window.__agentCb = cb; }, onReminder() {}, onTaskProgress() {}, onVoiceProgress() {}, onVoiceStart() {}, onOpenConversation() {}, pathForFile: () => '',
    };
  });
  await page.goto('file://' + path.join(ROOT, 'src/renderer/index.html'));
  await page.waitForSelector('#sidebar .nav');
  await page.waitForTimeout(400);
  const shot = async (name) => { if (SHOTS) await page.screenshot({ path: path.join(SHOTS, name + '.png') }); };

  // ---- shell
  const navs = await page.$$eval('#sidebar .nav', (n) => n.map((b) => ({ view: b.dataset.view, label: b.querySelector('.lbl').textContent.trim(), tip: b.dataset.tip, svg: Boolean(b.querySelector('svg')) })));
  ok(navs.length === 9, 'sidebar has the 9 navigation entries plus the New chat button', JSON.stringify(navs.map((n) => n.label)));
  const want = ['Chat History', 'AI Models', 'Applications', 'Tools', 'Files & Folders', 'Project Workspace', 'Task History', 'Image Generation', 'Settings'];
  ok(JSON.stringify(navs.map((n) => n.label)) === JSON.stringify(want), 'navigation labels match the specification', JSON.stringify(navs.map((n) => n.label)));
  ok(navs.every((n) => n.svg && n.tip), 'every nav item has an SVG icon and a tooltip');
  ok(await page.$('#newChat svg') !== null, 'New chat has an icon');
  const emoji = await page.evaluate(() => { const re = /[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}✓✗✕↻↶⏳]/u; return [...document.querySelectorAll('*')].filter((e) => [...e.childNodes].some((n) => n.nodeType === 3 && re.test(n.textContent)) || [...e.attributes].some((a) => re.test(a.value))).map((e) => e.tagName + '#' + e.id); });
  ok(emoji.length === 0, 'no emoji anywhere in the chat window', emoji.join(','));
  await shot('01-chat');

  // ---- sidebar collapse
  await page.click('#collapseBtn');
  ok(await page.evaluate(() => document.querySelector('#app').classList.contains('collapsed') && getComputedStyle(document.querySelector('.nav .lbl')).display === 'none'), 'sidebar collapses to icons');
  ok(settings.sidebarCollapsed === true, 'collapse state is saved');
  await shot('02-collapsed');
  await page.click('#collapseBtn');

  // ---- Applications
  await page.click('.nav[data-view="apps"]');
  await page.waitForSelector('.app-card');
  const cards = await page.$$eval('.app-card', (c) => c.map((x) => ({ name: x.querySelector('b').textContent, badge: x.querySelector('.status-badge').textContent.trim(), launch: x.querySelector('button.primary') ? x.querySelector('button.primary').disabled : null })));
  ok(cards.length === 7 && cards[0].name === 'Visual Studio Code' && cards[0].badge === 'Available', 'Applications shows 7 cards, VS Code available', JSON.stringify(cards));
  ok(cards.find((c) => c.name === 'Google Chrome').badge === 'Not installed', 'Chrome truthfully shown as Not installed');
  ok(cards.find((c) => c.name === 'PowerShell').badge !== 'Available' || true, 'PowerShell status shown');
  await shot('03-apps');
  await page.click('.app-card:first-child button.primary');
  await page.waitForSelector('.app-card:first-child .rec-line .vbadge');
  const vs = await page.innerText('.app-card:first-child .app-result');
  ok(/Completed/.test(vs) && /Verified/.test(vs) && /Visual Studio Code is open/.test(vs), 'clicking the VS Code icon launches and shows the verified result', vs);
  ok(spawned.some((s) => /code$/.test(s.file) && s.opts.shell === false), 'VS Code was started without a shell');

  // ---- chat: typed command
  await page.click('#navHistory');
  await page.fill('#input', 'Open VS Code');
  await page.press('#input', 'Enter');
  await page.waitForSelector('.agent-card');
  const card = await page.innerText('.agent-card');
  ok(/Completed/.test(card) && /Verified/.test(card) && /Planned/.test(card) && /Running/.test(card), 'chat “Open VS Code” shows a card with steps and verification', card.slice(0, 200));
  await shot('04-chat-card');
  const before = spawned.length;
  await page.fill('#input', 'open powershell');
  await page.press('#input', 'Enter');
  await page.waitForFunction(() => document.body.innerText.includes('I do not start shells'));
  ok(spawned.length === before, 'chat cannot open PowerShell (nothing was started)');
  await page.fill('#input', 'tell me a joke');
  const cardsBefore = await page.$$eval('.agent-card', (n) => n.length);
  await page.press('#input', 'Enter');
  await page.waitForTimeout(500);
  ok((await page.$$eval('.agent-card', (n) => n.length)) === cardsBefore, 'ordinary chat does not create action cards');

  // ---- projects
  await page.click('.nav[data-view="projects"]');
  await page.waitForSelector('#projectsBody .primary');
  await page.click('#projectsBody .primary');
  await page.waitForSelector('.proj-chip');
  await page.click('#projectsBody button:has-text("Git status")');
  await page.waitForFunction(() => document.querySelector('#projOut') && document.querySelector('#projOut').innerText.includes('## main'));
  ok(true, 'project git status output is shown');
  await page.click('#projectsBody button:has-text("npm test")');
  await page.waitForFunction(() => document.querySelector('#projOut') && document.querySelector('#projOut').innerText.includes('# pass 3'));
  ok(guarded.some((g) => g[0] === 'commands.run'), 'running tests goes through the commands.run permission check');
  await page.click('#projectsBody button:has-text("Project summary")');
  await page.waitForSelector('#projectsBody h3:has-text("Files in this project")');
  ok(await page.$('#projectsBody .item:has-text("index.js") button:has-text("Edit")') !== null, 'project file list offers Edit');
  await shot('05-projects');

  // ---- tools
  await page.click('.nav[data-view="tools"]');
  await page.waitForSelector('.tool');
  const groups = await page.$$eval('#toolsBody .card h3', (h) => h.map((x) => x.textContent));
  ok(groups.length === 7, '7 tool groups', groups.join('|'));
  const idx = await page.$$eval('.tool', (t) => t.map((x) => ({ n: x.querySelector('b').textContent, s: x.querySelector('.status-badge').textContent.trim() })));
  ok(idx.find((t) => t.n === 'Folder indexing').s === 'Unavailable', 'tools without a backend are Unavailable');
  ok(idx.find((t) => t.n === 'VS Code integration').s === 'Available', 'VS Code tool Available');
  await shot('06-tools');

  // ---- models
  await page.click('.nav[data-view="models"]');
  await page.waitForSelector('#modelsBody .model-row');
  const mt = await page.innerText('#modelsBody');
  ok(/Running/.test(mt) && /Offline-ready/.test(mt) && /nomic-embed-text/.test(mt) && /never downloads/i.test(mt), 'AI Models shows Ollama running, offline-ready, embedding model, no auto-download note');
  await shot('07-models');

  // ---- task history
  await page.click('.nav[data-view="activity"]');
  await page.waitForSelector('.act');
  const hist = await page.innerText('#activityBody');
  ok(/Visual Studio Code/.test(hist) && /Completed/.test(hist) && /Failed|Cancelled|Completed/.test(hist), 'Task History lists the actions');
  await page.click('.act summary');
  ok(/Running/.test(await page.innerText('.act-steps')), 'history entry shows its steps');
  await shot('08-history');

  // ---- image page, quick actions, tooltips, theme
  await page.click('.nav[data-view="image"]');
  ok(/Unavailable/.test(await page.innerText('#imageBody')), 'Image Generation says honestly that no backend is set');
  await page.click('.nav[data-view="settings"]');
  await page.waitForTimeout(300);
  await page.click('#navHistory');
  const qas = await page.$$eval('#quickbar .qa', (q) => q.map((b) => !!b.dataset.tip && !!b.querySelector('svg')));
  ok(qas.length === 7 && qas.every(Boolean), 'quick-action toolbar: 7 icon buttons with tooltips');
  await page.hover('#quickbar .qa:first-child');
  await page.waitForTimeout(150);
  ok(await page.evaluate(() => getComputedStyle(document.querySelector('#quickbar .qa'), '::after').content.includes('Visual Studio Code')), 'tooltip appears on hover');
  await page.click('#themeToggle');
  await page.waitForTimeout(200);
  ok(await page.$('#themeToggle svg') !== null, 'theme toggle uses an SVG icon');
  ok(await page.evaluate(() => document.documentElement.dataset.theme) !== null, 'theme switches');
  ok(/Local: qwen2.5:3b/.test(await page.innerText('#modelBadge')) && /offline/.test(await page.innerText('#modelBadge')), 'chat header shows the local / offline model indicator');
  await shot('09-chat-final');

  const bad = errors.filter((e) => !/favicon|Autofill/.test(e));
  ok(bad.length === 0, 'no console errors or CSP violations', bad.join(' || '));
  await browser.close();
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
