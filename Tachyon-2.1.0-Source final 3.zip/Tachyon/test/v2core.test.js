'use strict';
// Tachyon 2.0 core: chat commands, reminders, apps, tasks, skills and speech models.
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const fflate = require('fflate');
const C = require('../src/renderer/commands');
const { Reminders } = require('../src/core/reminders');
const Computer = require('../src/core/computer');
const Tasks = require('../src/core/tasks');
const Skills = require('../src/core/skills');
const Voice = require('../src/core/voiceModels');
const Perm = require('../src/core/permissions');

const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'tachyon-v2-'));
const NOW = new Date(2026, 9, 23, 10, 0, 0); // Friday 23 Oct 2026, 10:00

test('reminders: relative, clock, day and missing times', () => {
  let r = C.parseReminder('remind me in 20 minutes to stretch', NOW);
  assert.deepStrictEqual(r, { text: 'Stretch', at: NOW.getTime() + 20 * 60000 });
  r = C.parseReminder('remind me in half an hour to check the oven', NOW);
  assert.strictEqual(r.at, NOW.getTime() + 30 * 60000);
  r = C.parseReminder('remind me to call mom at 6 pm', NOW);
  assert.strictEqual(r.text, 'Call mom');
  assert.strictEqual(new Date(r.at).getHours(), 18);
  r = C.parseReminder('remind me tomorrow at 9am to pay rent', NOW);
  assert.strictEqual(new Date(r.at).getDate(), 24);
  assert.strictEqual(new Date(r.at).getHours(), 9);
  assert.strictEqual(r.text, 'Pay rent');
  r = C.parseReminder('remind me at 5 to leave', NOW); // 5 am has passed -> 5 pm today
  assert.strictEqual(new Date(r.at).getHours(), 17);
  assert.strictEqual(new Date(r.at).getDate(), 23);
  r = C.parseReminder('set a reminder for monday at 8:30 to submit the form', NOW);
  assert.strictEqual(new Date(r.at).getDay(), 1);
  assert.strictEqual(new Date(r.at).getMinutes(), 30);
  r = C.parseReminder('set a reminder for tonight to call dad', NOW);
  assert.deepStrictEqual([r.text, new Date(r.at).getHours()], ['Call dad', 20]);
  assert.deepStrictEqual(C.parseReminder('remind me to buy milk', NOW), { text: 'Buy milk', at: null, needTime: true });
  assert.strictEqual(C.parseReminder('what is a reminder?', NOW), null);
});

test('reminders store: add, due, remove', () => {
  const R = new Reminders(tmp());
  const a = R.add('Stretch', Date.now() + 60000);
  R.add('Water', Date.now() - 1000);
  assert.strictEqual(R.pending().length, 2);
  const due = R.takeDue();
  assert.deepStrictEqual(due.map((x) => x.text), ['Water']);
  assert.strictEqual(R.takeDue().length, 0, 'a reminder fires once');
  assert.strictEqual(R.remove(a.id), 1);
  assert.strictEqual(R.pending().length, 0);
  assert.throws(() => R.add('', Date.now()), /What should I remind you about/);
});

test('computer commands: apps, windows and searches are recognized; files are left alone', () => {
  assert.deepStrictEqual(C.parseComputerCommand('open spotify'), { kind: 'app', name: 'spotify' });
  assert.deepStrictEqual(C.parseComputerCommand('please launch the calculator app'), { kind: 'app', name: 'calculator' });
  assert.strictEqual(C.parseComputerCommand('open notes.txt'), null);
  assert.strictEqual(C.parseComputerCommand('open C:\\Docs'), null);
  assert.strictEqual(C.parseComputerCommand('open it'), null);
  assert.deepStrictEqual(C.parseComputerCommand('minimise chrome'), { kind: 'window', action: 'minimize', target: 'chrome' });
  assert.deepStrictEqual(C.parseComputerCommand('switch to word'), { kind: 'window', action: 'focus', target: 'word' });
  assert.strictEqual(C.parseComputerCommand('show desktop').action, 'minimizeAll');
  assert.strictEqual(C.parseComputerCommand('list open windows').action, 'list');
  assert.deepStrictEqual(C.parseComputerCommand('find pdfs named invoice'), { kind: 'search', mode: 'name', query: 'invoice', fileKind: 'pdf' });
  assert.deepStrictEqual(C.parseComputerCommand('find files containing "total due"'), { kind: 'search', mode: 'inside', query: 'total due' });
});

test('apps: best Start Menu match, built-ins, and blocked shells', () => {
  const apps = [{ name: 'Google Chrome', path: 'chrome.lnk' }, { name: 'Uninstall Chrome', path: 'u.lnk' }, { name: 'Spotify', path: 's.lnk' },
    { name: 'Microsoft Word', path: 'w.lnk' }, { name: 'Windows PowerShell', path: 'ps.lnk' }];
  assert.strictEqual(Computer.resolveApp('chrome', { platform: 'win32', apps }).target, 'chrome.lnk');
  assert.strictEqual(Computer.resolveApp('word', { platform: 'win32', apps }).name, 'Microsoft Word');
  assert.deepStrictEqual(Computer.resolveApp('notepad', { platform: 'win32', apps }), { kind: 'exe', target: 'notepad.exe', name: 'notepad' });
  assert.strictEqual(Computer.resolveApp('calc', { platform: 'win32', apps }).target, 'calculator:');
  for (const bad of ['cmd', 'powershell', 'PowerShell.exe', 'regedit', 'wscript', 'terminal']) assert.throws(() => Computer.resolveApp(bad, { platform: 'win32', apps }), /does not open/);
  assert.throws(() => Computer.resolveApp('windows powershell', { platform: 'win32', apps }), /does not open/);
  assert.throws(() => Computer.resolveApp('zzz', { platform: 'win32', apps }), /could not find an app/);
});

test('windows: the target is passed in an environment variable, never in the script', async () => {
  let seen;
  const run = (cmd, args, opts, cb) => { seen = { cmd, args, env: opts.env }; cb(null, 'Untitled - Notepad', ''); };
  const out = await Computer.windowAction('focus', "x'; Remove-Item C:\\ -Recurse; '", { platform: 'win32', run });
  assert.strictEqual(out, 'Untitled - Notepad');
  assert.strictEqual(seen.cmd, 'powershell.exe');
  assert.ok(!seen.args.join(' ').includes('Remove-Item'));
  assert.strictEqual(seen.env.TACHYON_TARGET, "x'; Remove-Item C:\\ -Recurse; '");
  await assert.rejects(Computer.windowAction('close', 'x', { platform: 'win32', run }), /Unknown window action/);
  await assert.rejects(Computer.windowAction('list', '', { platform: 'linux', run }), /available on Windows/);
});

test('tasks: plans are validated; unknown tools, forward references and missing args are refused', () => {
  const p = Tasks.parsePlan('Sure!\n```json\n{"title":"T","steps":[{"tool":"read_file","args":{"path":"a.txt"}},{"tool":"ai_write","args":{"instruction":"sum","input":"$1"}}]}\n```');
  assert.strictEqual(p.steps.length, 2);
  assert.strictEqual(p.steps[0].category, 'files.read');
  assert.throws(() => Tasks.parsePlan({ steps: [{ tool: 'delete_file', args: { path: 'a' } }] }), /cannot do/);
  assert.throws(() => Tasks.parsePlan({ steps: [{ tool: 'ai_write', args: { instruction: 'x', input: '$2' } }, { tool: 'read_file', args: { path: 'a' } }] }), /does not come before/);
  assert.throws(() => Tasks.parsePlan({ steps: [{ tool: 'copy_file', args: { from: 'a' } }] }), /missing “to”/);
  assert.throws(() => Tasks.parsePlan({ steps: Array.from({ length: 13 }, () => ({ tool: 'list_folder', args: { path: 'a' } })) }), /limit is 12/);
  assert.throws(() => Tasks.parsePlan('no json here'), /did not return a plan/);
  assert.strictEqual(Tasks.fillRefs('Summary: $1', ['hello']), 'Summary: hello');
  assert.ok(Tasks.plannerPrompt({ folders: ['C:\\Work'], known: { desktop: 'C:\\Users\\a\\Desktop' } }).includes('C:\\Work'));
});

test('tasks: chained requests are detected, simple ones are not', () => {
  assert.ok(C.isTaskRequest('/task anything'));
  assert.ok(C.isTaskRequest('find my resume, convert it to PDF and then copy it to my desktop'));
  assert.ok(!C.isTaskRequest('write a poem and save it to my desktop'));
  assert.ok(!C.isTaskRequest('how do I find, convert and then save files?'));
  assert.ok(!C.isTaskRequest('summarize C:\\Docs\\a.pdf'));
});

test('skills: commands, drafts and validation', () => {
  assert.deepStrictEqual(C.parseSkillCall('/wc hello world'), { command: 'wc', input: 'hello world' });
  assert.strictEqual(C.parseSkillRequest('create a skill that counts words'), 'counts words');
  assert.strictEqual(C.parseSkillRequest('/skill translate to Tamil'), 'translate to Tamil');
  assert.strictEqual(C.parseSkillRequest('teach yourself to write haiku'), 'write haiku');
  assert.strictEqual(C.parseSkillRequest('what is a skill?'), null);
  const p = Skills.validateSkill({ name: 'Polite', command: 'Polite Rewrite', kind: 'prompt', prompt: 'Rewrite politely' });
  assert.strictEqual(p.command, 'polite-rewrite');
  assert.ok(p.prompt.endsWith('{{input}}'));
  assert.strictEqual(Skills.fillPrompt('A {{input}} B {{input}}', 'x'), 'A x B x');
  assert.throws(() => Skills.validateSkill({ command: 'task', kind: 'prompt', prompt: 'x' }), /built-in command/);
  assert.throws(() => Skills.validateSkill({ command: 'x', kind: 'prompt', prompt: 'x' }), /2–24/);
  assert.throws(() => Skills.validateSkill({ command: 'wc', kind: 'code', code: 'const a = 1;', tests: [{ input: 'a' }] }), /function run/);
  for (const bad of ['fetch(u)', 'require("fs")', 'new Function("x")', 'import("x")', 'process.exit()', 'new WebSocket(u)', 'eval(x)'])
    assert.throws(() => Skills.validateSkill({ command: 'wc', kind: 'code', code: `function run(i) { ${bad}; return i; }`, tests: [{ input: 'a' }] }), /not allowed/, bad);
  assert.throws(() => Skills.validateSkill({ command: 'wc', kind: 'code', code: 'function run(i) { return i; }', tests: [] }), /at least one test/);
});

test('skills store: install, update, rollback, disable, delete', async () => {
  const S = new Skills.Skills(tmp());
  const v1 = Skills.validateSkill({ name: 'WC', command: 'wc', kind: 'code', code: 'function run(i) { return "1"; }', tests: [{ input: 'a', expect: '1' }] });
  const tests = await Skills.runTests(v1, async (s, input) => (input === 'a' ? '1' : '0'));
  assert.deepStrictEqual(tests.map((t) => t.ok), [true]);
  const a = S.install(v1, tests);
  assert.strictEqual(a.version, 1);
  const b = S.install({ ...v1, code: 'function run(i) { return "2"; }' });
  assert.strictEqual(b.version, 2);
  assert.strictEqual(b.history.length, 1);
  const c = S.rollback(b.id);
  assert.strictEqual(c.version, 1);
  assert.ok(c.code.includes('"1"'));
  assert.throws(() => S.rollback(b.id), /no earlier version/);
  assert.strictEqual(S.setEnabled(b.id, false).enabled, false);
  assert.strictEqual(S.remove(b.id), 1);
  assert.strictEqual(S.list().length, 0);
});

test('speech models: any Vosk archive becomes a .tar.gz with one model/ folder', () => {
  const files = { 'vosk-model-small-en-us-0.15/am/final.mdl': new Uint8Array([1, 2, 3]), 'vosk-model-small-en-us-0.15/conf/model.conf': new TextEncoder().encode('--x\n'), 'vosk-model-small-en-us-0.15/graph/phones/word_boundary.int': new Uint8Array(700) };
  const tgz = Voice.toModelTarGz(fflate.zipSync(files), 'm.zip');
  const back = Voice.tarUnpack(fflate.gunzipSync(tgz));
  assert.deepStrictEqual(back.map((e) => e.name).sort(), ['model/am/final.mdl', 'model/conf/model.conf', 'model/graph/phones/word_boundary.int']);
  assert.deepStrictEqual([...back.find((e) => e.name === 'model/am/final.mdl').data], [1, 2, 3]);
  // directories are real entries (mode 755), the recognizer needs them
  const raw = fflate.gunzipSync(tgz);
  assert.strictEqual(String.fromCharCode(raw[156]), '5');
  assert.strictEqual(new TextDecoder().decode(raw.subarray(0, 6)), 'model/');
  // zips without a top folder, and .tar.gz input, work too
  const flat = Voice.toModelTarGz(fflate.zipSync({ 'am/final.mdl': new Uint8Array([9]), 'conf/model.conf': new Uint8Array([1]) }));
  assert.ok(Voice.tarUnpack(fflate.gunzipSync(flat)).some((e) => e.name === 'model/am/final.mdl'));
  assert.ok(Voice.tarUnpack(fflate.gunzipSync(Voice.toModelTarGz(tgz))).some((e) => e.name === 'model/conf/model.conf'));
  assert.throws(() => Voice.toModelTarGz(fflate.zipSync({ 'readme.txt': new Uint8Array([1]) })), /does not look like a Vosk/);
  assert.throws(() => Voice.toModelTarGz(new Uint8Array([1, 2, 3])), /not a \.zip or \.tar\.gz/);
});

test('speech models store: catalog, save, remove, ids are checked', () => {
  const M = new Voice.ModelStore(tmp());
  assert.deepStrictEqual(M.list().map((m) => m.id), ['en-us', 'en-in', 'hi']);
  assert.ok(M.list().every((m) => m.url.startsWith('https://alphacephei.com/vosk/models/')));
  M.save('custom-x', Buffer.from('x'), { label: 'X' });
  assert.ok(M.list().some((m) => m.id === 'custom-x' && m.installed && m.imported));
  M.remove('custom-x');
  assert.ok(!M.list().some((m) => m.id === 'custom-x'));
  assert.throws(() => M.file('../evil'), /Invalid model id/);
});

test('permissions: new categories have safe defaults', () => {
  const e = Perm.effective({});
  for (const k of ['apps.open', 'windows', 'reminders', 'skills']) assert.strictEqual(e[k], 'allow');
  assert.strictEqual(e['files.delete'], 'ask');
});
